package p3x;
import libx21.*;
import java.util.function.Function;
import java.util.List;
public class P3XMain extends GenericMainX21 {
	//
	// Code for input i
	//
	private ComputeNode<Integer,Integer> node_i = new InputNode<Integer>();
	public void inputI(Integer input) {
		node_i.put(input);
	}
	//
	// Code for parameter p
	//
	private Integer _p;
	public void setParameterP(Integer value) {
		_p = value;
	}
	//
	// Code for function x
	//
	private Integer fun_x(Integer arg) {
		return funimpl_x((Integer)arg);
	}
	private Integer funimpl_x(Integer _x){ return (let0(((_x)*(_p)))); }
	//
	// Code for node x
	//
	private ComputeNode <Integer,Integer> node_x = new AbstractComputeNode<Integer,Integer>() {
		protected Integer function(Integer input) {
			return fun_x(input);
		}
	};
	//
	// Code for node 2
	//
	private ComputeNode <Integer,Integer> node_2 = new AbstractComputeNode<Integer,Integer>() {
		protected Integer function(Integer input) {
			Function<Integer,Integer> f = (Integer _x) -> { return ((_x)+(_x)); };
			return f.apply((Integer)input);
		}
	};
	//
	// Code for node 1
	//
	private ComputeNode <Integer,Integer> node_1 = new AbstractComputeNode<Integer,Integer>() {
		protected Integer function(Integer input) {
			return fun_x(input);
		}
	};
	//
	// Output nodes
	//
	private OutputNode<Integer> node_y = new OutputNode<Integer>();
	public List<Integer> getY() { return node_y.getData(); }
	//
	// Helper methods (if any)
	//
	private static int let0(int _x) {
		return ((_x)+(_x)); // [_x]
	}
	//
	// Initialization of specific nodes
	//
	protected void initializeNodes() {
		super.addNode(node_i);
		super.addNode(node_x);
		super.addNode(node_2);
		super.addNode(node_1);
	}
	//
	// Initialize network as a whole
	//
	protected void initializeNetwork() {
		node_i.addOutputNode(node_x);
		// Integer
		node_x.addOutputNode(node_1);
		// Integer
		node_1.addOutputNode(node_2);
		// Integer
		node_2.addOutputNode(node_y);
	}
}
