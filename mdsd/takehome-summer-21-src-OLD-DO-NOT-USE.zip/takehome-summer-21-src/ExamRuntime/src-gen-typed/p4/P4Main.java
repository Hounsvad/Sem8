package p4;
import libx21.*;
import java.util.function.Function;
import java.util.List;
public class P4Main extends GenericMainX21 {
	//
	// Code for parameter z
	//
	private Integer _z;
	public void setParameterZ(Integer value) {
		_z = value;
	}
	//
	// Code for input number2
	//
	private ComputeNode<DataInt_pair,DataInt_pair> node_number2 = new InputNode<DataInt_pair>();
	public void inputNumber2(DataInt_pair input) {
		node_number2.put(input);
	}
	//
	// Code for input number
	//
	private ComputeNode<Integer,Integer> node_number = new InputNode<Integer>();
	public void inputNumber(Integer input) {
		node_number.put(input);
	}
	//
	// Code for function add_it
	//
	private Integer fun_add_it(DataInt_pair arg) {
		return funimpl_add_it((DataInt_pair)arg);
	}
	private Integer funimpl_add_it(DataInt_pair _t){ return ((_t.getI1())+(_t.getI2())); }
	//
	// Code for node 1
	//
	private ComputeNode <DataInt_pair,Integer> node_1 = new AbstractComputeNode<DataInt_pair,Integer>() {
		protected Integer function(DataInt_pair input) {
			return fun_add_it(input);
		}
	};
	//
	// Code for node 2
	//
	private ComputeNode <Integer,DataInt_pair> node_2 = new AbstractComputeNode<Integer,DataInt_pair>() {
		protected DataInt_pair function(Integer input) {
			Function<Integer,DataInt_pair> f = (Integer _x) -> { return ((_x).equals((_z))?(null):(new DataInt_pair().setI1((_x)).setI2((_z)))); };
			return f.apply((Integer)input);
		}
	};
	//
	// Output nodes
	//
	private OutputNode<Integer> node_number2added = new OutputNode<Integer>();
	public List<Integer> getNumber2added() { return node_number2added.getData(); }
	private OutputNode<DataInt_pair> node_not_duplicates = new OutputNode<DataInt_pair>();
	public List<DataInt_pair> getNot_duplicates() { return node_not_duplicates.getData(); }
	//
	// Helper methods (if any)
	//
	//
	// Initialization of specific nodes
	//
	protected void initializeNodes() {
		super.addNode(node_number2);
		super.addNode(node_number);
		super.addNode(node_1);
		super.addNode(node_2);
	}
	//
	// Initialize network as a whole
	//
	protected void initializeNetwork() {
		node_number2.addOutputNode(node_1);
		// Integer
		node_1.addOutputNode(node_number2added);
		node_number.addOutputNode(node_2);
		node_number.addOutputNode(node_2);
		// DataInt_pair
		node_2.addOutputNode(node_not_duplicates);
	}
}
