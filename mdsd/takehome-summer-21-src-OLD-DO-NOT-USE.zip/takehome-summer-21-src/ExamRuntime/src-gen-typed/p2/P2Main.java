package p2;
import libx21.*;
import java.util.function.Function;
import java.util.List;
public class P2Main extends GenericMainX21 {
	//
	// Code for parameter z
	//
	private Integer _z;
	public void setParameterZ(Integer value) {
		_z = value;
	}
	//
	// Code for parameter max
	//
	private Integer _max;
	public void setParameterMax(Integer value) {
		_max = value;
	}
	//
	// Code for function add1
	//
	private Integer fun_add1(Integer arg) {
		return funimpl_add1((Integer)arg);
	}
	private Integer funimpl_add1(Integer _x){ return ((_x)+(1)); }
	//
	// Code for function addzmul
	//
	private Integer fun_addzmul(Integer arg) {
		return funimpl_addzmul((Integer)arg);
	}
	private Integer funimpl_addzmul(Integer _x){ return (((_x)+(_z))*((_x)+(_z))); }
	//
	// Code for input number
	//
	private ComputeNode<Integer,Integer> node_number = new InputNode<Integer>();
	public void inputNumber(Integer input) {
		node_number.put(input);
	}
	//
	// Code for node add1node
	//
	private ComputeNode <Integer,Integer> node_add1node = new AbstractComputeNode<Integer,Integer>() {
		protected Integer function(Integer input) {
			return fun_add1(input);
		}
	};
	//
	// Code for node x
	//
	private ComputeNode <Integer,Integer> node_x = new AbstractComputeNode<Integer,Integer>() {
		protected Integer function(Integer input) {
			return fun_add1(input);
		}
	};
	//
	// Code for node y
	//
	private ComputeNode <Integer,Integer> node_y = new AbstractComputeNode<Integer,Integer>() {
		protected Integer function(Integer input) {
			return fun_add1(input);
		}
	};
	//
	// Code for node 0
	//
	private ComputeNode <Integer,Integer> node_0 = new AbstractComputeNode<Integer,Integer>() {
		protected Integer function(Integer input) {
			return fun_addzmul(input);
		}
	};
	//
	// Code for node 1
	//
	private ComputeNode <Integer,Integer> node_1 = new AbstractComputeNode<Integer,Integer>() {
		protected Integer function(Integer input) {
			Function<Integer,Integer> f = (Integer _x) -> { return ((_x)<=(_max)?(_x):(_max)); };
			return f.apply((Integer)input);
		}
	};
	//
	// Output nodes
	//
	private OutputNode<Integer> node_out = new OutputNode<Integer>();
	public List<Integer> getOut() { return node_out.getData(); }
	private OutputNode<Integer> node_ceiling = new OutputNode<Integer>();
	public List<Integer> getCeiling() { return node_ceiling.getData(); }
	//
	// Helper methods (if any)
	//
	//
	// Initialization of specific nodes
	//
	protected void initializeNodes() {
		super.addNode(node_number);
		super.addNode(node_add1node);
		super.addNode(node_x);
		super.addNode(node_y);
		super.addNode(node_0);
		super.addNode(node_1);
	}
	//
	// Initialize network as a whole
	//
	protected void initializeNetwork() {
		node_number.addOutputNode(node_x);
		node_number.addOutputNode(node_y);
		node_x.addOutputNode(node_0);
		node_y.addOutputNode(node_0);
		// Integer
		node_0.addOutputNode(node_out);
		node_number.addOutputNode(node_1);
		// Integer
		node_1.addOutputNode(node_ceiling);
	}
}
