package dk.sdu.mmmi.olnor18.x21.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import dk.sdu.mmmi.olnor18.x21.services.X21GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalX21Parser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'='", "'<'", "'>'", "'<='", "'>='", "'program'", "'parameter'", "':'", "'function'", "'('", "')'", "'{'", "'}'", "'input'", "'node'", "'['", "']'", "'to'", "','", "'stream'", "'output'", "'data'", "'-'", "'+'", "'/'", "'*'", "'none'", "'if'", "'then'", "'else'", "'end'", "'let'", "'in'", "'new'", "'.'", "'int'", "'string'"
    };
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=5;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalX21Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalX21Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalX21Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalX21.g"; }


    	private X21GrammarAccess grammarAccess;

    	public void setGrammarAccess(X21GrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleProgram"
    // InternalX21.g:53:1: entryRuleProgram : ruleProgram EOF ;
    public final void entryRuleProgram() throws RecognitionException {
        try {
            // InternalX21.g:54:1: ( ruleProgram EOF )
            // InternalX21.g:55:1: ruleProgram EOF
            {
             before(grammarAccess.getProgramRule()); 
            pushFollow(FOLLOW_1);
            ruleProgram();

            state._fsp--;

             after(grammarAccess.getProgramRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleProgram"


    // $ANTLR start "ruleProgram"
    // InternalX21.g:62:1: ruleProgram : ( ( rule__Program__Group__0 ) ) ;
    public final void ruleProgram() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:66:2: ( ( ( rule__Program__Group__0 ) ) )
            // InternalX21.g:67:2: ( ( rule__Program__Group__0 ) )
            {
            // InternalX21.g:67:2: ( ( rule__Program__Group__0 ) )
            // InternalX21.g:68:3: ( rule__Program__Group__0 )
            {
             before(grammarAccess.getProgramAccess().getGroup()); 
            // InternalX21.g:69:3: ( rule__Program__Group__0 )
            // InternalX21.g:69:4: rule__Program__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Program__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getProgramAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleProgram"


    // $ANTLR start "entryRuleDeclaration"
    // InternalX21.g:78:1: entryRuleDeclaration : ruleDeclaration EOF ;
    public final void entryRuleDeclaration() throws RecognitionException {
        try {
            // InternalX21.g:79:1: ( ruleDeclaration EOF )
            // InternalX21.g:80:1: ruleDeclaration EOF
            {
             before(grammarAccess.getDeclarationRule()); 
            pushFollow(FOLLOW_1);
            ruleDeclaration();

            state._fsp--;

             after(grammarAccess.getDeclarationRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDeclaration"


    // $ANTLR start "ruleDeclaration"
    // InternalX21.g:87:1: ruleDeclaration : ( ( rule__Declaration__Alternatives ) ) ;
    public final void ruleDeclaration() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:91:2: ( ( ( rule__Declaration__Alternatives ) ) )
            // InternalX21.g:92:2: ( ( rule__Declaration__Alternatives ) )
            {
            // InternalX21.g:92:2: ( ( rule__Declaration__Alternatives ) )
            // InternalX21.g:93:3: ( rule__Declaration__Alternatives )
            {
             before(grammarAccess.getDeclarationAccess().getAlternatives()); 
            // InternalX21.g:94:3: ( rule__Declaration__Alternatives )
            // InternalX21.g:94:4: rule__Declaration__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Declaration__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getDeclarationAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDeclaration"


    // $ANTLR start "entryRuleParameter"
    // InternalX21.g:103:1: entryRuleParameter : ruleParameter EOF ;
    public final void entryRuleParameter() throws RecognitionException {
        try {
            // InternalX21.g:104:1: ( ruleParameter EOF )
            // InternalX21.g:105:1: ruleParameter EOF
            {
             before(grammarAccess.getParameterRule()); 
            pushFollow(FOLLOW_1);
            ruleParameter();

            state._fsp--;

             after(grammarAccess.getParameterRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleParameter"


    // $ANTLR start "ruleParameter"
    // InternalX21.g:112:1: ruleParameter : ( ( rule__Parameter__Group__0 ) ) ;
    public final void ruleParameter() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:116:2: ( ( ( rule__Parameter__Group__0 ) ) )
            // InternalX21.g:117:2: ( ( rule__Parameter__Group__0 ) )
            {
            // InternalX21.g:117:2: ( ( rule__Parameter__Group__0 ) )
            // InternalX21.g:118:3: ( rule__Parameter__Group__0 )
            {
             before(grammarAccess.getParameterAccess().getGroup()); 
            // InternalX21.g:119:3: ( rule__Parameter__Group__0 )
            // InternalX21.g:119:4: rule__Parameter__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Parameter__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getParameterAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleParameter"


    // $ANTLR start "entryRuleInternalParameter"
    // InternalX21.g:128:1: entryRuleInternalParameter : ruleInternalParameter EOF ;
    public final void entryRuleInternalParameter() throws RecognitionException {
        try {
            // InternalX21.g:129:1: ( ruleInternalParameter EOF )
            // InternalX21.g:130:1: ruleInternalParameter EOF
            {
             before(grammarAccess.getInternalParameterRule()); 
            pushFollow(FOLLOW_1);
            ruleInternalParameter();

            state._fsp--;

             after(grammarAccess.getInternalParameterRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInternalParameter"


    // $ANTLR start "ruleInternalParameter"
    // InternalX21.g:137:1: ruleInternalParameter : ( ( rule__InternalParameter__Group__0 ) ) ;
    public final void ruleInternalParameter() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:141:2: ( ( ( rule__InternalParameter__Group__0 ) ) )
            // InternalX21.g:142:2: ( ( rule__InternalParameter__Group__0 ) )
            {
            // InternalX21.g:142:2: ( ( rule__InternalParameter__Group__0 ) )
            // InternalX21.g:143:3: ( rule__InternalParameter__Group__0 )
            {
             before(grammarAccess.getInternalParameterAccess().getGroup()); 
            // InternalX21.g:144:3: ( rule__InternalParameter__Group__0 )
            // InternalX21.g:144:4: rule__InternalParameter__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__InternalParameter__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getInternalParameterAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInternalParameter"


    // $ANTLR start "entryRuleFunction"
    // InternalX21.g:153:1: entryRuleFunction : ruleFunction EOF ;
    public final void entryRuleFunction() throws RecognitionException {
        try {
            // InternalX21.g:154:1: ( ruleFunction EOF )
            // InternalX21.g:155:1: ruleFunction EOF
            {
             before(grammarAccess.getFunctionRule()); 
            pushFollow(FOLLOW_1);
            ruleFunction();

            state._fsp--;

             after(grammarAccess.getFunctionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFunction"


    // $ANTLR start "ruleFunction"
    // InternalX21.g:162:1: ruleFunction : ( ( rule__Function__Group__0 ) ) ;
    public final void ruleFunction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:166:2: ( ( ( rule__Function__Group__0 ) ) )
            // InternalX21.g:167:2: ( ( rule__Function__Group__0 ) )
            {
            // InternalX21.g:167:2: ( ( rule__Function__Group__0 ) )
            // InternalX21.g:168:3: ( rule__Function__Group__0 )
            {
             before(grammarAccess.getFunctionAccess().getGroup()); 
            // InternalX21.g:169:3: ( rule__Function__Group__0 )
            // InternalX21.g:169:4: rule__Function__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Function__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFunctionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFunction"


    // $ANTLR start "entryRuleLambda"
    // InternalX21.g:178:1: entryRuleLambda : ruleLambda EOF ;
    public final void entryRuleLambda() throws RecognitionException {
        try {
            // InternalX21.g:179:1: ( ruleLambda EOF )
            // InternalX21.g:180:1: ruleLambda EOF
            {
             before(grammarAccess.getLambdaRule()); 
            pushFollow(FOLLOW_1);
            ruleLambda();

            state._fsp--;

             after(grammarAccess.getLambdaRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLambda"


    // $ANTLR start "ruleLambda"
    // InternalX21.g:187:1: ruleLambda : ( ( rule__Lambda__Group__0 ) ) ;
    public final void ruleLambda() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:191:2: ( ( ( rule__Lambda__Group__0 ) ) )
            // InternalX21.g:192:2: ( ( rule__Lambda__Group__0 ) )
            {
            // InternalX21.g:192:2: ( ( rule__Lambda__Group__0 ) )
            // InternalX21.g:193:3: ( rule__Lambda__Group__0 )
            {
             before(grammarAccess.getLambdaAccess().getGroup()); 
            // InternalX21.g:194:3: ( rule__Lambda__Group__0 )
            // InternalX21.g:194:4: rule__Lambda__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Lambda__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLambdaAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLambda"


    // $ANTLR start "entryRuleInput"
    // InternalX21.g:203:1: entryRuleInput : ruleInput EOF ;
    public final void entryRuleInput() throws RecognitionException {
        try {
            // InternalX21.g:204:1: ( ruleInput EOF )
            // InternalX21.g:205:1: ruleInput EOF
            {
             before(grammarAccess.getInputRule()); 
            pushFollow(FOLLOW_1);
            ruleInput();

            state._fsp--;

             after(grammarAccess.getInputRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInput"


    // $ANTLR start "ruleInput"
    // InternalX21.g:212:1: ruleInput : ( ( rule__Input__Group__0 ) ) ;
    public final void ruleInput() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:216:2: ( ( ( rule__Input__Group__0 ) ) )
            // InternalX21.g:217:2: ( ( rule__Input__Group__0 ) )
            {
            // InternalX21.g:217:2: ( ( rule__Input__Group__0 ) )
            // InternalX21.g:218:3: ( rule__Input__Group__0 )
            {
             before(grammarAccess.getInputAccess().getGroup()); 
            // InternalX21.g:219:3: ( rule__Input__Group__0 )
            // InternalX21.g:219:4: rule__Input__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Input__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getInputAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInput"


    // $ANTLR start "entryRuleNode"
    // InternalX21.g:228:1: entryRuleNode : ruleNode EOF ;
    public final void entryRuleNode() throws RecognitionException {
        try {
            // InternalX21.g:229:1: ( ruleNode EOF )
            // InternalX21.g:230:1: ruleNode EOF
            {
             before(grammarAccess.getNodeRule()); 
            pushFollow(FOLLOW_1);
            ruleNode();

            state._fsp--;

             after(grammarAccess.getNodeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNode"


    // $ANTLR start "ruleNode"
    // InternalX21.g:237:1: ruleNode : ( ( rule__Node__Group__0 ) ) ;
    public final void ruleNode() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:241:2: ( ( ( rule__Node__Group__0 ) ) )
            // InternalX21.g:242:2: ( ( rule__Node__Group__0 ) )
            {
            // InternalX21.g:242:2: ( ( rule__Node__Group__0 ) )
            // InternalX21.g:243:3: ( rule__Node__Group__0 )
            {
             before(grammarAccess.getNodeAccess().getGroup()); 
            // InternalX21.g:244:3: ( rule__Node__Group__0 )
            // InternalX21.g:244:4: rule__Node__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Node__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getNodeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNode"


    // $ANTLR start "entryRuleStreamOutput"
    // InternalX21.g:253:1: entryRuleStreamOutput : ruleStreamOutput EOF ;
    public final void entryRuleStreamOutput() throws RecognitionException {
        try {
            // InternalX21.g:254:1: ( ruleStreamOutput EOF )
            // InternalX21.g:255:1: ruleStreamOutput EOF
            {
             before(grammarAccess.getStreamOutputRule()); 
            pushFollow(FOLLOW_1);
            ruleStreamOutput();

            state._fsp--;

             after(grammarAccess.getStreamOutputRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStreamOutput"


    // $ANTLR start "ruleStreamOutput"
    // InternalX21.g:262:1: ruleStreamOutput : ( ( rule__StreamOutput__Group__0 ) ) ;
    public final void ruleStreamOutput() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:266:2: ( ( ( rule__StreamOutput__Group__0 ) ) )
            // InternalX21.g:267:2: ( ( rule__StreamOutput__Group__0 ) )
            {
            // InternalX21.g:267:2: ( ( rule__StreamOutput__Group__0 ) )
            // InternalX21.g:268:3: ( rule__StreamOutput__Group__0 )
            {
             before(grammarAccess.getStreamOutputAccess().getGroup()); 
            // InternalX21.g:269:3: ( rule__StreamOutput__Group__0 )
            // InternalX21.g:269:4: rule__StreamOutput__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__StreamOutput__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStreamOutputAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStreamOutput"


    // $ANTLR start "entryRuleStream"
    // InternalX21.g:278:1: entryRuleStream : ruleStream EOF ;
    public final void entryRuleStream() throws RecognitionException {
        try {
            // InternalX21.g:279:1: ( ruleStream EOF )
            // InternalX21.g:280:1: ruleStream EOF
            {
             before(grammarAccess.getStreamRule()); 
            pushFollow(FOLLOW_1);
            ruleStream();

            state._fsp--;

             after(grammarAccess.getStreamRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStream"


    // $ANTLR start "ruleStream"
    // InternalX21.g:287:1: ruleStream : ( ( rule__Stream__Group__0 ) ) ;
    public final void ruleStream() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:291:2: ( ( ( rule__Stream__Group__0 ) ) )
            // InternalX21.g:292:2: ( ( rule__Stream__Group__0 ) )
            {
            // InternalX21.g:292:2: ( ( rule__Stream__Group__0 ) )
            // InternalX21.g:293:3: ( rule__Stream__Group__0 )
            {
             before(grammarAccess.getStreamAccess().getGroup()); 
            // InternalX21.g:294:3: ( rule__Stream__Group__0 )
            // InternalX21.g:294:4: rule__Stream__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Stream__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStreamAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStream"


    // $ANTLR start "entryRuleElement"
    // InternalX21.g:303:1: entryRuleElement : ruleElement EOF ;
    public final void entryRuleElement() throws RecognitionException {
        try {
            // InternalX21.g:304:1: ( ruleElement EOF )
            // InternalX21.g:305:1: ruleElement EOF
            {
             before(grammarAccess.getElementRule()); 
            pushFollow(FOLLOW_1);
            ruleElement();

            state._fsp--;

             after(grammarAccess.getElementRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleElement"


    // $ANTLR start "ruleElement"
    // InternalX21.g:312:1: ruleElement : ( ( rule__Element__Alternatives ) ) ;
    public final void ruleElement() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:316:2: ( ( ( rule__Element__Alternatives ) ) )
            // InternalX21.g:317:2: ( ( rule__Element__Alternatives ) )
            {
            // InternalX21.g:317:2: ( ( rule__Element__Alternatives ) )
            // InternalX21.g:318:3: ( rule__Element__Alternatives )
            {
             before(grammarAccess.getElementAccess().getAlternatives()); 
            // InternalX21.g:319:3: ( rule__Element__Alternatives )
            // InternalX21.g:319:4: rule__Element__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Element__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getElementAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleElement"


    // $ANTLR start "entryRuleDataDecl"
    // InternalX21.g:328:1: entryRuleDataDecl : ruleDataDecl EOF ;
    public final void entryRuleDataDecl() throws RecognitionException {
        try {
            // InternalX21.g:329:1: ( ruleDataDecl EOF )
            // InternalX21.g:330:1: ruleDataDecl EOF
            {
             before(grammarAccess.getDataDeclRule()); 
            pushFollow(FOLLOW_1);
            ruleDataDecl();

            state._fsp--;

             after(grammarAccess.getDataDeclRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDataDecl"


    // $ANTLR start "ruleDataDecl"
    // InternalX21.g:337:1: ruleDataDecl : ( ( rule__DataDecl__Group__0 ) ) ;
    public final void ruleDataDecl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:341:2: ( ( ( rule__DataDecl__Group__0 ) ) )
            // InternalX21.g:342:2: ( ( rule__DataDecl__Group__0 ) )
            {
            // InternalX21.g:342:2: ( ( rule__DataDecl__Group__0 ) )
            // InternalX21.g:343:3: ( rule__DataDecl__Group__0 )
            {
             before(grammarAccess.getDataDeclAccess().getGroup()); 
            // InternalX21.g:344:3: ( rule__DataDecl__Group__0 )
            // InternalX21.g:344:4: rule__DataDecl__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__DataDecl__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDataDeclAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDataDecl"


    // $ANTLR start "entryRuleType"
    // InternalX21.g:353:1: entryRuleType : ruleType EOF ;
    public final void entryRuleType() throws RecognitionException {
        try {
            // InternalX21.g:354:1: ( ruleType EOF )
            // InternalX21.g:355:1: ruleType EOF
            {
             before(grammarAccess.getTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleType();

            state._fsp--;

             after(grammarAccess.getTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleType"


    // $ANTLR start "ruleType"
    // InternalX21.g:362:1: ruleType : ( ( rule__Type__Alternatives ) ) ;
    public final void ruleType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:366:2: ( ( ( rule__Type__Alternatives ) ) )
            // InternalX21.g:367:2: ( ( rule__Type__Alternatives ) )
            {
            // InternalX21.g:367:2: ( ( rule__Type__Alternatives ) )
            // InternalX21.g:368:3: ( rule__Type__Alternatives )
            {
             before(grammarAccess.getTypeAccess().getAlternatives()); 
            // InternalX21.g:369:3: ( rule__Type__Alternatives )
            // InternalX21.g:369:4: rule__Type__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Type__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleType"


    // $ANTLR start "entryRuleExp"
    // InternalX21.g:378:1: entryRuleExp : ruleExp EOF ;
    public final void entryRuleExp() throws RecognitionException {
        try {
            // InternalX21.g:379:1: ( ruleExp EOF )
            // InternalX21.g:380:1: ruleExp EOF
            {
             before(grammarAccess.getExpRule()); 
            pushFollow(FOLLOW_1);
            ruleExp();

            state._fsp--;

             after(grammarAccess.getExpRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleExp"


    // $ANTLR start "ruleExp"
    // InternalX21.g:387:1: ruleExp : ( ruleSubAddExp ) ;
    public final void ruleExp() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:391:2: ( ( ruleSubAddExp ) )
            // InternalX21.g:392:2: ( ruleSubAddExp )
            {
            // InternalX21.g:392:2: ( ruleSubAddExp )
            // InternalX21.g:393:3: ruleSubAddExp
            {
             before(grammarAccess.getExpAccess().getSubAddExpParserRuleCall()); 
            pushFollow(FOLLOW_2);
            ruleSubAddExp();

            state._fsp--;

             after(grammarAccess.getExpAccess().getSubAddExpParserRuleCall()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleExp"


    // $ANTLR start "entryRuleSubAddExp"
    // InternalX21.g:403:1: entryRuleSubAddExp : ruleSubAddExp EOF ;
    public final void entryRuleSubAddExp() throws RecognitionException {
        try {
            // InternalX21.g:404:1: ( ruleSubAddExp EOF )
            // InternalX21.g:405:1: ruleSubAddExp EOF
            {
             before(grammarAccess.getSubAddExpRule()); 
            pushFollow(FOLLOW_1);
            ruleSubAddExp();

            state._fsp--;

             after(grammarAccess.getSubAddExpRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSubAddExp"


    // $ANTLR start "ruleSubAddExp"
    // InternalX21.g:412:1: ruleSubAddExp : ( ( rule__SubAddExp__Group__0 ) ) ;
    public final void ruleSubAddExp() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:416:2: ( ( ( rule__SubAddExp__Group__0 ) ) )
            // InternalX21.g:417:2: ( ( rule__SubAddExp__Group__0 ) )
            {
            // InternalX21.g:417:2: ( ( rule__SubAddExp__Group__0 ) )
            // InternalX21.g:418:3: ( rule__SubAddExp__Group__0 )
            {
             before(grammarAccess.getSubAddExpAccess().getGroup()); 
            // InternalX21.g:419:3: ( rule__SubAddExp__Group__0 )
            // InternalX21.g:419:4: rule__SubAddExp__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__SubAddExp__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSubAddExpAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSubAddExp"


    // $ANTLR start "entryRuleDivMultExp"
    // InternalX21.g:428:1: entryRuleDivMultExp : ruleDivMultExp EOF ;
    public final void entryRuleDivMultExp() throws RecognitionException {
        try {
            // InternalX21.g:429:1: ( ruleDivMultExp EOF )
            // InternalX21.g:430:1: ruleDivMultExp EOF
            {
             before(grammarAccess.getDivMultExpRule()); 
            pushFollow(FOLLOW_1);
            ruleDivMultExp();

            state._fsp--;

             after(grammarAccess.getDivMultExpRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDivMultExp"


    // $ANTLR start "ruleDivMultExp"
    // InternalX21.g:437:1: ruleDivMultExp : ( ( rule__DivMultExp__Group__0 ) ) ;
    public final void ruleDivMultExp() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:441:2: ( ( ( rule__DivMultExp__Group__0 ) ) )
            // InternalX21.g:442:2: ( ( rule__DivMultExp__Group__0 ) )
            {
            // InternalX21.g:442:2: ( ( rule__DivMultExp__Group__0 ) )
            // InternalX21.g:443:3: ( rule__DivMultExp__Group__0 )
            {
             before(grammarAccess.getDivMultExpAccess().getGroup()); 
            // InternalX21.g:444:3: ( rule__DivMultExp__Group__0 )
            // InternalX21.g:444:4: rule__DivMultExp__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__DivMultExp__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDivMultExpAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDivMultExp"


    // $ANTLR start "entryRulePrimary"
    // InternalX21.g:453:1: entryRulePrimary : rulePrimary EOF ;
    public final void entryRulePrimary() throws RecognitionException {
        try {
            // InternalX21.g:454:1: ( rulePrimary EOF )
            // InternalX21.g:455:1: rulePrimary EOF
            {
             before(grammarAccess.getPrimaryRule()); 
            pushFollow(FOLLOW_1);
            rulePrimary();

            state._fsp--;

             after(grammarAccess.getPrimaryRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePrimary"


    // $ANTLR start "rulePrimary"
    // InternalX21.g:462:1: rulePrimary : ( ( rule__Primary__Alternatives ) ) ;
    public final void rulePrimary() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:466:2: ( ( ( rule__Primary__Alternatives ) ) )
            // InternalX21.g:467:2: ( ( rule__Primary__Alternatives ) )
            {
            // InternalX21.g:467:2: ( ( rule__Primary__Alternatives ) )
            // InternalX21.g:468:3: ( rule__Primary__Alternatives )
            {
             before(grammarAccess.getPrimaryAccess().getAlternatives()); 
            // InternalX21.g:469:3: ( rule__Primary__Alternatives )
            // InternalX21.g:469:4: rule__Primary__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Primary__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getPrimaryAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePrimary"


    // $ANTLR start "entryRuleNone"
    // InternalX21.g:478:1: entryRuleNone : ruleNone EOF ;
    public final void entryRuleNone() throws RecognitionException {
        try {
            // InternalX21.g:479:1: ( ruleNone EOF )
            // InternalX21.g:480:1: ruleNone EOF
            {
             before(grammarAccess.getNoneRule()); 
            pushFollow(FOLLOW_1);
            ruleNone();

            state._fsp--;

             after(grammarAccess.getNoneRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNone"


    // $ANTLR start "ruleNone"
    // InternalX21.g:487:1: ruleNone : ( ( rule__None__Group__0 ) ) ;
    public final void ruleNone() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:491:2: ( ( ( rule__None__Group__0 ) ) )
            // InternalX21.g:492:2: ( ( rule__None__Group__0 ) )
            {
            // InternalX21.g:492:2: ( ( rule__None__Group__0 ) )
            // InternalX21.g:493:3: ( rule__None__Group__0 )
            {
             before(grammarAccess.getNoneAccess().getGroup()); 
            // InternalX21.g:494:3: ( rule__None__Group__0 )
            // InternalX21.g:494:4: rule__None__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__None__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getNoneAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNone"


    // $ANTLR start "entryRuleIfstatement"
    // InternalX21.g:503:1: entryRuleIfstatement : ruleIfstatement EOF ;
    public final void entryRuleIfstatement() throws RecognitionException {
        try {
            // InternalX21.g:504:1: ( ruleIfstatement EOF )
            // InternalX21.g:505:1: ruleIfstatement EOF
            {
             before(grammarAccess.getIfstatementRule()); 
            pushFollow(FOLLOW_1);
            ruleIfstatement();

            state._fsp--;

             after(grammarAccess.getIfstatementRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleIfstatement"


    // $ANTLR start "ruleIfstatement"
    // InternalX21.g:512:1: ruleIfstatement : ( ( rule__Ifstatement__Group__0 ) ) ;
    public final void ruleIfstatement() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:516:2: ( ( ( rule__Ifstatement__Group__0 ) ) )
            // InternalX21.g:517:2: ( ( rule__Ifstatement__Group__0 ) )
            {
            // InternalX21.g:517:2: ( ( rule__Ifstatement__Group__0 ) )
            // InternalX21.g:518:3: ( rule__Ifstatement__Group__0 )
            {
             before(grammarAccess.getIfstatementAccess().getGroup()); 
            // InternalX21.g:519:3: ( rule__Ifstatement__Group__0 )
            // InternalX21.g:519:4: rule__Ifstatement__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Ifstatement__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getIfstatementAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleIfstatement"


    // $ANTLR start "entryRuleParenthesis"
    // InternalX21.g:528:1: entryRuleParenthesis : ruleParenthesis EOF ;
    public final void entryRuleParenthesis() throws RecognitionException {
        try {
            // InternalX21.g:529:1: ( ruleParenthesis EOF )
            // InternalX21.g:530:1: ruleParenthesis EOF
            {
             before(grammarAccess.getParenthesisRule()); 
            pushFollow(FOLLOW_1);
            ruleParenthesis();

            state._fsp--;

             after(grammarAccess.getParenthesisRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleParenthesis"


    // $ANTLR start "ruleParenthesis"
    // InternalX21.g:537:1: ruleParenthesis : ( ( rule__Parenthesis__Group__0 ) ) ;
    public final void ruleParenthesis() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:541:2: ( ( ( rule__Parenthesis__Group__0 ) ) )
            // InternalX21.g:542:2: ( ( rule__Parenthesis__Group__0 ) )
            {
            // InternalX21.g:542:2: ( ( rule__Parenthesis__Group__0 ) )
            // InternalX21.g:543:3: ( rule__Parenthesis__Group__0 )
            {
             before(grammarAccess.getParenthesisAccess().getGroup()); 
            // InternalX21.g:544:3: ( rule__Parenthesis__Group__0 )
            // InternalX21.g:544:4: rule__Parenthesis__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Parenthesis__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getParenthesisAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleParenthesis"


    // $ANTLR start "entryRuleNumber"
    // InternalX21.g:553:1: entryRuleNumber : ruleNumber EOF ;
    public final void entryRuleNumber() throws RecognitionException {
        try {
            // InternalX21.g:554:1: ( ruleNumber EOF )
            // InternalX21.g:555:1: ruleNumber EOF
            {
             before(grammarAccess.getNumberRule()); 
            pushFollow(FOLLOW_1);
            ruleNumber();

            state._fsp--;

             after(grammarAccess.getNumberRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNumber"


    // $ANTLR start "ruleNumber"
    // InternalX21.g:562:1: ruleNumber : ( ( rule__Number__Group__0 ) ) ;
    public final void ruleNumber() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:566:2: ( ( ( rule__Number__Group__0 ) ) )
            // InternalX21.g:567:2: ( ( rule__Number__Group__0 ) )
            {
            // InternalX21.g:567:2: ( ( rule__Number__Group__0 ) )
            // InternalX21.g:568:3: ( rule__Number__Group__0 )
            {
             before(grammarAccess.getNumberAccess().getGroup()); 
            // InternalX21.g:569:3: ( rule__Number__Group__0 )
            // InternalX21.g:569:4: rule__Number__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Number__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getNumberAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNumber"


    // $ANTLR start "entryRuleLet"
    // InternalX21.g:578:1: entryRuleLet : ruleLet EOF ;
    public final void entryRuleLet() throws RecognitionException {
        try {
            // InternalX21.g:579:1: ( ruleLet EOF )
            // InternalX21.g:580:1: ruleLet EOF
            {
             before(grammarAccess.getLetRule()); 
            pushFollow(FOLLOW_1);
            ruleLet();

            state._fsp--;

             after(grammarAccess.getLetRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLet"


    // $ANTLR start "ruleLet"
    // InternalX21.g:587:1: ruleLet : ( ( rule__Let__Group__0 ) ) ;
    public final void ruleLet() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:591:2: ( ( ( rule__Let__Group__0 ) ) )
            // InternalX21.g:592:2: ( ( rule__Let__Group__0 ) )
            {
            // InternalX21.g:592:2: ( ( rule__Let__Group__0 ) )
            // InternalX21.g:593:3: ( rule__Let__Group__0 )
            {
             before(grammarAccess.getLetAccess().getGroup()); 
            // InternalX21.g:594:3: ( rule__Let__Group__0 )
            // InternalX21.g:594:4: rule__Let__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Let__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLetAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLet"


    // $ANTLR start "entryRuleVariableAssignment"
    // InternalX21.g:603:1: entryRuleVariableAssignment : ruleVariableAssignment EOF ;
    public final void entryRuleVariableAssignment() throws RecognitionException {
        try {
            // InternalX21.g:604:1: ( ruleVariableAssignment EOF )
            // InternalX21.g:605:1: ruleVariableAssignment EOF
            {
             before(grammarAccess.getVariableAssignmentRule()); 
            pushFollow(FOLLOW_1);
            ruleVariableAssignment();

            state._fsp--;

             after(grammarAccess.getVariableAssignmentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleVariableAssignment"


    // $ANTLR start "ruleVariableAssignment"
    // InternalX21.g:612:1: ruleVariableAssignment : ( ( rule__VariableAssignment__Group__0 ) ) ;
    public final void ruleVariableAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:616:2: ( ( ( rule__VariableAssignment__Group__0 ) ) )
            // InternalX21.g:617:2: ( ( rule__VariableAssignment__Group__0 ) )
            {
            // InternalX21.g:617:2: ( ( rule__VariableAssignment__Group__0 ) )
            // InternalX21.g:618:3: ( rule__VariableAssignment__Group__0 )
            {
             before(grammarAccess.getVariableAssignmentAccess().getGroup()); 
            // InternalX21.g:619:3: ( rule__VariableAssignment__Group__0 )
            // InternalX21.g:619:4: rule__VariableAssignment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getVariableAssignmentAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVariableAssignment"


    // $ANTLR start "entryRuleVariableUse"
    // InternalX21.g:628:1: entryRuleVariableUse : ruleVariableUse EOF ;
    public final void entryRuleVariableUse() throws RecognitionException {
        try {
            // InternalX21.g:629:1: ( ruleVariableUse EOF )
            // InternalX21.g:630:1: ruleVariableUse EOF
            {
             before(grammarAccess.getVariableUseRule()); 
            pushFollow(FOLLOW_1);
            ruleVariableUse();

            state._fsp--;

             after(grammarAccess.getVariableUseRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleVariableUse"


    // $ANTLR start "ruleVariableUse"
    // InternalX21.g:637:1: ruleVariableUse : ( ( rule__VariableUse__RefAssignment ) ) ;
    public final void ruleVariableUse() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:641:2: ( ( ( rule__VariableUse__RefAssignment ) ) )
            // InternalX21.g:642:2: ( ( rule__VariableUse__RefAssignment ) )
            {
            // InternalX21.g:642:2: ( ( rule__VariableUse__RefAssignment ) )
            // InternalX21.g:643:3: ( rule__VariableUse__RefAssignment )
            {
             before(grammarAccess.getVariableUseAccess().getRefAssignment()); 
            // InternalX21.g:644:3: ( rule__VariableUse__RefAssignment )
            // InternalX21.g:644:4: rule__VariableUse__RefAssignment
            {
            pushFollow(FOLLOW_2);
            rule__VariableUse__RefAssignment();

            state._fsp--;


            }

             after(grammarAccess.getVariableUseAccess().getRefAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVariableUse"


    // $ANTLR start "entryRuleDataTypeAttribute"
    // InternalX21.g:653:1: entryRuleDataTypeAttribute : ruleDataTypeAttribute EOF ;
    public final void entryRuleDataTypeAttribute() throws RecognitionException {
        try {
            // InternalX21.g:654:1: ( ruleDataTypeAttribute EOF )
            // InternalX21.g:655:1: ruleDataTypeAttribute EOF
            {
             before(grammarAccess.getDataTypeAttributeRule()); 
            pushFollow(FOLLOW_1);
            ruleDataTypeAttribute();

            state._fsp--;

             after(grammarAccess.getDataTypeAttributeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDataTypeAttribute"


    // $ANTLR start "ruleDataTypeAttribute"
    // InternalX21.g:662:1: ruleDataTypeAttribute : ( ( rule__DataTypeAttribute__Group__0 ) ) ;
    public final void ruleDataTypeAttribute() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:666:2: ( ( ( rule__DataTypeAttribute__Group__0 ) ) )
            // InternalX21.g:667:2: ( ( rule__DataTypeAttribute__Group__0 ) )
            {
            // InternalX21.g:667:2: ( ( rule__DataTypeAttribute__Group__0 ) )
            // InternalX21.g:668:3: ( rule__DataTypeAttribute__Group__0 )
            {
             before(grammarAccess.getDataTypeAttributeAccess().getGroup()); 
            // InternalX21.g:669:3: ( rule__DataTypeAttribute__Group__0 )
            // InternalX21.g:669:4: rule__DataTypeAttribute__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__DataTypeAttribute__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDataTypeAttributeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDataTypeAttribute"


    // $ANTLR start "entryRuleComparison"
    // InternalX21.g:678:1: entryRuleComparison : ruleComparison EOF ;
    public final void entryRuleComparison() throws RecognitionException {
        try {
            // InternalX21.g:679:1: ( ruleComparison EOF )
            // InternalX21.g:680:1: ruleComparison EOF
            {
             before(grammarAccess.getComparisonRule()); 
            pushFollow(FOLLOW_1);
            ruleComparison();

            state._fsp--;

             after(grammarAccess.getComparisonRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleComparison"


    // $ANTLR start "ruleComparison"
    // InternalX21.g:687:1: ruleComparison : ( ( rule__Comparison__Alternatives ) ) ;
    public final void ruleComparison() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:691:2: ( ( ( rule__Comparison__Alternatives ) ) )
            // InternalX21.g:692:2: ( ( rule__Comparison__Alternatives ) )
            {
            // InternalX21.g:692:2: ( ( rule__Comparison__Alternatives ) )
            // InternalX21.g:693:3: ( rule__Comparison__Alternatives )
            {
             before(grammarAccess.getComparisonAccess().getAlternatives()); 
            // InternalX21.g:694:3: ( rule__Comparison__Alternatives )
            // InternalX21.g:694:4: rule__Comparison__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Comparison__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getComparisonAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComparison"


    // $ANTLR start "entryRuleLogicExp"
    // InternalX21.g:703:1: entryRuleLogicExp : ruleLogicExp EOF ;
    public final void entryRuleLogicExp() throws RecognitionException {
        try {
            // InternalX21.g:704:1: ( ruleLogicExp EOF )
            // InternalX21.g:705:1: ruleLogicExp EOF
            {
             before(grammarAccess.getLogicExpRule()); 
            pushFollow(FOLLOW_1);
            ruleLogicExp();

            state._fsp--;

             after(grammarAccess.getLogicExpRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLogicExp"


    // $ANTLR start "ruleLogicExp"
    // InternalX21.g:712:1: ruleLogicExp : ( ( rule__LogicExp__Group__0 ) ) ;
    public final void ruleLogicExp() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:716:2: ( ( ( rule__LogicExp__Group__0 ) ) )
            // InternalX21.g:717:2: ( ( rule__LogicExp__Group__0 ) )
            {
            // InternalX21.g:717:2: ( ( rule__LogicExp__Group__0 ) )
            // InternalX21.g:718:3: ( rule__LogicExp__Group__0 )
            {
             before(grammarAccess.getLogicExpAccess().getGroup()); 
            // InternalX21.g:719:3: ( rule__LogicExp__Group__0 )
            // InternalX21.g:719:4: rule__LogicExp__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__LogicExp__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLogicExpAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLogicExp"


    // $ANTLR start "rule__Declaration__Alternatives"
    // InternalX21.g:727:1: rule__Declaration__Alternatives : ( ( ruleFunction ) | ( ruleInput ) | ( ruleNode ) | ( ruleStream ) | ( ruleDataDecl ) | ( ruleParameter ) );
    public final void rule__Declaration__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:731:1: ( ( ruleFunction ) | ( ruleInput ) | ( ruleNode ) | ( ruleStream ) | ( ruleDataDecl ) | ( ruleParameter ) )
            int alt1=6;
            switch ( input.LA(1) ) {
            case 19:
                {
                alt1=1;
                }
                break;
            case 24:
                {
                alt1=2;
                }
                break;
            case 25:
                {
                alt1=3;
                }
                break;
            case 30:
                {
                alt1=4;
                }
                break;
            case 32:
                {
                alt1=5;
                }
                break;
            case 17:
                {
                alt1=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // InternalX21.g:732:2: ( ruleFunction )
                    {
                    // InternalX21.g:732:2: ( ruleFunction )
                    // InternalX21.g:733:3: ruleFunction
                    {
                     before(grammarAccess.getDeclarationAccess().getFunctionParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleFunction();

                    state._fsp--;

                     after(grammarAccess.getDeclarationAccess().getFunctionParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalX21.g:738:2: ( ruleInput )
                    {
                    // InternalX21.g:738:2: ( ruleInput )
                    // InternalX21.g:739:3: ruleInput
                    {
                     before(grammarAccess.getDeclarationAccess().getInputParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleInput();

                    state._fsp--;

                     after(grammarAccess.getDeclarationAccess().getInputParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalX21.g:744:2: ( ruleNode )
                    {
                    // InternalX21.g:744:2: ( ruleNode )
                    // InternalX21.g:745:3: ruleNode
                    {
                     before(grammarAccess.getDeclarationAccess().getNodeParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleNode();

                    state._fsp--;

                     after(grammarAccess.getDeclarationAccess().getNodeParserRuleCall_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalX21.g:750:2: ( ruleStream )
                    {
                    // InternalX21.g:750:2: ( ruleStream )
                    // InternalX21.g:751:3: ruleStream
                    {
                     before(grammarAccess.getDeclarationAccess().getStreamParserRuleCall_3()); 
                    pushFollow(FOLLOW_2);
                    ruleStream();

                    state._fsp--;

                     after(grammarAccess.getDeclarationAccess().getStreamParserRuleCall_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalX21.g:756:2: ( ruleDataDecl )
                    {
                    // InternalX21.g:756:2: ( ruleDataDecl )
                    // InternalX21.g:757:3: ruleDataDecl
                    {
                     before(grammarAccess.getDeclarationAccess().getDataDeclParserRuleCall_4()); 
                    pushFollow(FOLLOW_2);
                    ruleDataDecl();

                    state._fsp--;

                     after(grammarAccess.getDeclarationAccess().getDataDeclParserRuleCall_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalX21.g:762:2: ( ruleParameter )
                    {
                    // InternalX21.g:762:2: ( ruleParameter )
                    // InternalX21.g:763:3: ruleParameter
                    {
                     before(grammarAccess.getDeclarationAccess().getParameterParserRuleCall_5()); 
                    pushFollow(FOLLOW_2);
                    ruleParameter();

                    state._fsp--;

                     after(grammarAccess.getDeclarationAccess().getParameterParserRuleCall_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Declaration__Alternatives"


    // $ANTLR start "rule__Node__Alternatives_3"
    // InternalX21.g:772:1: rule__Node__Alternatives_3 : ( ( ( rule__Node__RefbodyAssignment_3_0 ) ) | ( ( rule__Node__BodyAssignment_3_1 ) ) );
    public final void rule__Node__Alternatives_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:776:1: ( ( ( rule__Node__RefbodyAssignment_3_0 ) ) | ( ( rule__Node__BodyAssignment_3_1 ) ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==RULE_ID) ) {
                alt2=1;
            }
            else if ( (LA2_0==20) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalX21.g:777:2: ( ( rule__Node__RefbodyAssignment_3_0 ) )
                    {
                    // InternalX21.g:777:2: ( ( rule__Node__RefbodyAssignment_3_0 ) )
                    // InternalX21.g:778:3: ( rule__Node__RefbodyAssignment_3_0 )
                    {
                     before(grammarAccess.getNodeAccess().getRefbodyAssignment_3_0()); 
                    // InternalX21.g:779:3: ( rule__Node__RefbodyAssignment_3_0 )
                    // InternalX21.g:779:4: rule__Node__RefbodyAssignment_3_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Node__RefbodyAssignment_3_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getNodeAccess().getRefbodyAssignment_3_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalX21.g:783:2: ( ( rule__Node__BodyAssignment_3_1 ) )
                    {
                    // InternalX21.g:783:2: ( ( rule__Node__BodyAssignment_3_1 ) )
                    // InternalX21.g:784:3: ( rule__Node__BodyAssignment_3_1 )
                    {
                     before(grammarAccess.getNodeAccess().getBodyAssignment_3_1()); 
                    // InternalX21.g:785:3: ( rule__Node__BodyAssignment_3_1 )
                    // InternalX21.g:785:4: rule__Node__BodyAssignment_3_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Node__BodyAssignment_3_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getNodeAccess().getBodyAssignment_3_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__Alternatives_3"


    // $ANTLR start "rule__Element__Alternatives"
    // InternalX21.g:793:1: rule__Element__Alternatives : ( ( ( rule__Element__Group_0__0 ) ) | ( ( rule__Element__Group_1__0 ) ) | ( ( rule__Element__Group_2__0 ) ) );
    public final void rule__Element__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:797:1: ( ( ( rule__Element__Group_0__0 ) ) | ( ( rule__Element__Group_1__0 ) ) | ( ( rule__Element__Group_2__0 ) ) )
            int alt3=3;
            switch ( input.LA(1) ) {
            case RULE_ID:
                {
                alt3=1;
                }
                break;
            case 26:
                {
                alt3=2;
                }
                break;
            case 31:
                {
                alt3=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalX21.g:798:2: ( ( rule__Element__Group_0__0 ) )
                    {
                    // InternalX21.g:798:2: ( ( rule__Element__Group_0__0 ) )
                    // InternalX21.g:799:3: ( rule__Element__Group_0__0 )
                    {
                     before(grammarAccess.getElementAccess().getGroup_0()); 
                    // InternalX21.g:800:3: ( rule__Element__Group_0__0 )
                    // InternalX21.g:800:4: rule__Element__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Element__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getElementAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalX21.g:804:2: ( ( rule__Element__Group_1__0 ) )
                    {
                    // InternalX21.g:804:2: ( ( rule__Element__Group_1__0 ) )
                    // InternalX21.g:805:3: ( rule__Element__Group_1__0 )
                    {
                     before(grammarAccess.getElementAccess().getGroup_1()); 
                    // InternalX21.g:806:3: ( rule__Element__Group_1__0 )
                    // InternalX21.g:806:4: rule__Element__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Element__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getElementAccess().getGroup_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalX21.g:810:2: ( ( rule__Element__Group_2__0 ) )
                    {
                    // InternalX21.g:810:2: ( ( rule__Element__Group_2__0 ) )
                    // InternalX21.g:811:3: ( rule__Element__Group_2__0 )
                    {
                     before(grammarAccess.getElementAccess().getGroup_2()); 
                    // InternalX21.g:812:3: ( rule__Element__Group_2__0 )
                    // InternalX21.g:812:4: rule__Element__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Element__Group_2__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getElementAccess().getGroup_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Alternatives"


    // $ANTLR start "rule__Element__Alternatives_1_2"
    // InternalX21.g:820:1: rule__Element__Alternatives_1_2 : ( ( ( rule__Element__RefBodyAssignment_1_2_0 ) ) | ( ( rule__Element__BodyAssignment_1_2_1 ) ) );
    public final void rule__Element__Alternatives_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:824:1: ( ( ( rule__Element__RefBodyAssignment_1_2_0 ) ) | ( ( rule__Element__BodyAssignment_1_2_1 ) ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==RULE_ID) ) {
                alt4=1;
            }
            else if ( (LA4_0==20) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalX21.g:825:2: ( ( rule__Element__RefBodyAssignment_1_2_0 ) )
                    {
                    // InternalX21.g:825:2: ( ( rule__Element__RefBodyAssignment_1_2_0 ) )
                    // InternalX21.g:826:3: ( rule__Element__RefBodyAssignment_1_2_0 )
                    {
                     before(grammarAccess.getElementAccess().getRefBodyAssignment_1_2_0()); 
                    // InternalX21.g:827:3: ( rule__Element__RefBodyAssignment_1_2_0 )
                    // InternalX21.g:827:4: rule__Element__RefBodyAssignment_1_2_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Element__RefBodyAssignment_1_2_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getElementAccess().getRefBodyAssignment_1_2_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalX21.g:831:2: ( ( rule__Element__BodyAssignment_1_2_1 ) )
                    {
                    // InternalX21.g:831:2: ( ( rule__Element__BodyAssignment_1_2_1 ) )
                    // InternalX21.g:832:3: ( rule__Element__BodyAssignment_1_2_1 )
                    {
                     before(grammarAccess.getElementAccess().getBodyAssignment_1_2_1()); 
                    // InternalX21.g:833:3: ( rule__Element__BodyAssignment_1_2_1 )
                    // InternalX21.g:833:4: rule__Element__BodyAssignment_1_2_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Element__BodyAssignment_1_2_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getElementAccess().getBodyAssignment_1_2_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Alternatives_1_2"


    // $ANTLR start "rule__Type__Alternatives"
    // InternalX21.g:841:1: rule__Type__Alternatives : ( ( ( rule__Type__Group_0__0 ) ) | ( ( rule__Type__Group_1__0 ) ) | ( ( rule__Type__RefAssignment_2 ) ) );
    public final void rule__Type__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:845:1: ( ( ( rule__Type__Group_0__0 ) ) | ( ( rule__Type__Group_1__0 ) ) | ( ( rule__Type__RefAssignment_2 ) ) )
            int alt5=3;
            switch ( input.LA(1) ) {
            case 46:
                {
                alt5=1;
                }
                break;
            case 47:
                {
                alt5=2;
                }
                break;
            case RULE_ID:
                {
                alt5=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalX21.g:846:2: ( ( rule__Type__Group_0__0 ) )
                    {
                    // InternalX21.g:846:2: ( ( rule__Type__Group_0__0 ) )
                    // InternalX21.g:847:3: ( rule__Type__Group_0__0 )
                    {
                     before(grammarAccess.getTypeAccess().getGroup_0()); 
                    // InternalX21.g:848:3: ( rule__Type__Group_0__0 )
                    // InternalX21.g:848:4: rule__Type__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Type__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getTypeAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalX21.g:852:2: ( ( rule__Type__Group_1__0 ) )
                    {
                    // InternalX21.g:852:2: ( ( rule__Type__Group_1__0 ) )
                    // InternalX21.g:853:3: ( rule__Type__Group_1__0 )
                    {
                     before(grammarAccess.getTypeAccess().getGroup_1()); 
                    // InternalX21.g:854:3: ( rule__Type__Group_1__0 )
                    // InternalX21.g:854:4: rule__Type__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Type__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getTypeAccess().getGroup_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalX21.g:858:2: ( ( rule__Type__RefAssignment_2 ) )
                    {
                    // InternalX21.g:858:2: ( ( rule__Type__RefAssignment_2 ) )
                    // InternalX21.g:859:3: ( rule__Type__RefAssignment_2 )
                    {
                     before(grammarAccess.getTypeAccess().getRefAssignment_2()); 
                    // InternalX21.g:860:3: ( rule__Type__RefAssignment_2 )
                    // InternalX21.g:860:4: rule__Type__RefAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__Type__RefAssignment_2();

                    state._fsp--;


                    }

                     after(grammarAccess.getTypeAccess().getRefAssignment_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__Alternatives"


    // $ANTLR start "rule__SubAddExp__Alternatives_1_0"
    // InternalX21.g:868:1: rule__SubAddExp__Alternatives_1_0 : ( ( ( rule__SubAddExp__Group_1_0_0__0 ) ) | ( ( rule__SubAddExp__Group_1_0_1__0 ) ) );
    public final void rule__SubAddExp__Alternatives_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:872:1: ( ( ( rule__SubAddExp__Group_1_0_0__0 ) ) | ( ( rule__SubAddExp__Group_1_0_1__0 ) ) )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==33) ) {
                alt6=1;
            }
            else if ( (LA6_0==34) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalX21.g:873:2: ( ( rule__SubAddExp__Group_1_0_0__0 ) )
                    {
                    // InternalX21.g:873:2: ( ( rule__SubAddExp__Group_1_0_0__0 ) )
                    // InternalX21.g:874:3: ( rule__SubAddExp__Group_1_0_0__0 )
                    {
                     before(grammarAccess.getSubAddExpAccess().getGroup_1_0_0()); 
                    // InternalX21.g:875:3: ( rule__SubAddExp__Group_1_0_0__0 )
                    // InternalX21.g:875:4: rule__SubAddExp__Group_1_0_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SubAddExp__Group_1_0_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSubAddExpAccess().getGroup_1_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalX21.g:879:2: ( ( rule__SubAddExp__Group_1_0_1__0 ) )
                    {
                    // InternalX21.g:879:2: ( ( rule__SubAddExp__Group_1_0_1__0 ) )
                    // InternalX21.g:880:3: ( rule__SubAddExp__Group_1_0_1__0 )
                    {
                     before(grammarAccess.getSubAddExpAccess().getGroup_1_0_1()); 
                    // InternalX21.g:881:3: ( rule__SubAddExp__Group_1_0_1__0 )
                    // InternalX21.g:881:4: rule__SubAddExp__Group_1_0_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SubAddExp__Group_1_0_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSubAddExpAccess().getGroup_1_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Alternatives_1_0"


    // $ANTLR start "rule__DivMultExp__Alternatives_1_0"
    // InternalX21.g:889:1: rule__DivMultExp__Alternatives_1_0 : ( ( ( rule__DivMultExp__Group_1_0_0__0 ) ) | ( ( rule__DivMultExp__Group_1_0_1__0 ) ) );
    public final void rule__DivMultExp__Alternatives_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:893:1: ( ( ( rule__DivMultExp__Group_1_0_0__0 ) ) | ( ( rule__DivMultExp__Group_1_0_1__0 ) ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==35) ) {
                alt7=1;
            }
            else if ( (LA7_0==36) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalX21.g:894:2: ( ( rule__DivMultExp__Group_1_0_0__0 ) )
                    {
                    // InternalX21.g:894:2: ( ( rule__DivMultExp__Group_1_0_0__0 ) )
                    // InternalX21.g:895:3: ( rule__DivMultExp__Group_1_0_0__0 )
                    {
                     before(grammarAccess.getDivMultExpAccess().getGroup_1_0_0()); 
                    // InternalX21.g:896:3: ( rule__DivMultExp__Group_1_0_0__0 )
                    // InternalX21.g:896:4: rule__DivMultExp__Group_1_0_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__DivMultExp__Group_1_0_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getDivMultExpAccess().getGroup_1_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalX21.g:900:2: ( ( rule__DivMultExp__Group_1_0_1__0 ) )
                    {
                    // InternalX21.g:900:2: ( ( rule__DivMultExp__Group_1_0_1__0 ) )
                    // InternalX21.g:901:3: ( rule__DivMultExp__Group_1_0_1__0 )
                    {
                     before(grammarAccess.getDivMultExpAccess().getGroup_1_0_1()); 
                    // InternalX21.g:902:3: ( rule__DivMultExp__Group_1_0_1__0 )
                    // InternalX21.g:902:4: rule__DivMultExp__Group_1_0_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__DivMultExp__Group_1_0_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getDivMultExpAccess().getGroup_1_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Alternatives_1_0"


    // $ANTLR start "rule__Primary__Alternatives"
    // InternalX21.g:910:1: rule__Primary__Alternatives : ( ( ruleNumber ) | ( ruleParenthesis ) | ( ruleVariableUse ) | ( ruleLet ) | ( ruleVariableAssignment ) | ( ruleIfstatement ) | ( ruleNone ) | ( ruleDataTypeAttribute ) );
    public final void rule__Primary__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:914:1: ( ( ruleNumber ) | ( ruleParenthesis ) | ( ruleVariableUse ) | ( ruleLet ) | ( ruleVariableAssignment ) | ( ruleIfstatement ) | ( ruleNone ) | ( ruleDataTypeAttribute ) )
            int alt8=8;
            alt8 = dfa8.predict(input);
            switch (alt8) {
                case 1 :
                    // InternalX21.g:915:2: ( ruleNumber )
                    {
                    // InternalX21.g:915:2: ( ruleNumber )
                    // InternalX21.g:916:3: ruleNumber
                    {
                     before(grammarAccess.getPrimaryAccess().getNumberParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleNumber();

                    state._fsp--;

                     after(grammarAccess.getPrimaryAccess().getNumberParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalX21.g:921:2: ( ruleParenthesis )
                    {
                    // InternalX21.g:921:2: ( ruleParenthesis )
                    // InternalX21.g:922:3: ruleParenthesis
                    {
                     before(grammarAccess.getPrimaryAccess().getParenthesisParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleParenthesis();

                    state._fsp--;

                     after(grammarAccess.getPrimaryAccess().getParenthesisParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalX21.g:927:2: ( ruleVariableUse )
                    {
                    // InternalX21.g:927:2: ( ruleVariableUse )
                    // InternalX21.g:928:3: ruleVariableUse
                    {
                     before(grammarAccess.getPrimaryAccess().getVariableUseParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleVariableUse();

                    state._fsp--;

                     after(grammarAccess.getPrimaryAccess().getVariableUseParserRuleCall_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalX21.g:933:2: ( ruleLet )
                    {
                    // InternalX21.g:933:2: ( ruleLet )
                    // InternalX21.g:934:3: ruleLet
                    {
                     before(grammarAccess.getPrimaryAccess().getLetParserRuleCall_3()); 
                    pushFollow(FOLLOW_2);
                    ruleLet();

                    state._fsp--;

                     after(grammarAccess.getPrimaryAccess().getLetParserRuleCall_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalX21.g:939:2: ( ruleVariableAssignment )
                    {
                    // InternalX21.g:939:2: ( ruleVariableAssignment )
                    // InternalX21.g:940:3: ruleVariableAssignment
                    {
                     before(grammarAccess.getPrimaryAccess().getVariableAssignmentParserRuleCall_4()); 
                    pushFollow(FOLLOW_2);
                    ruleVariableAssignment();

                    state._fsp--;

                     after(grammarAccess.getPrimaryAccess().getVariableAssignmentParserRuleCall_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalX21.g:945:2: ( ruleIfstatement )
                    {
                    // InternalX21.g:945:2: ( ruleIfstatement )
                    // InternalX21.g:946:3: ruleIfstatement
                    {
                     before(grammarAccess.getPrimaryAccess().getIfstatementParserRuleCall_5()); 
                    pushFollow(FOLLOW_2);
                    ruleIfstatement();

                    state._fsp--;

                     after(grammarAccess.getPrimaryAccess().getIfstatementParserRuleCall_5()); 

                    }


                    }
                    break;
                case 7 :
                    // InternalX21.g:951:2: ( ruleNone )
                    {
                    // InternalX21.g:951:2: ( ruleNone )
                    // InternalX21.g:952:3: ruleNone
                    {
                     before(grammarAccess.getPrimaryAccess().getNoneParserRuleCall_6()); 
                    pushFollow(FOLLOW_2);
                    ruleNone();

                    state._fsp--;

                     after(grammarAccess.getPrimaryAccess().getNoneParserRuleCall_6()); 

                    }


                    }
                    break;
                case 8 :
                    // InternalX21.g:957:2: ( ruleDataTypeAttribute )
                    {
                    // InternalX21.g:957:2: ( ruleDataTypeAttribute )
                    // InternalX21.g:958:3: ruleDataTypeAttribute
                    {
                     before(grammarAccess.getPrimaryAccess().getDataTypeAttributeParserRuleCall_7()); 
                    pushFollow(FOLLOW_2);
                    ruleDataTypeAttribute();

                    state._fsp--;

                     after(grammarAccess.getPrimaryAccess().getDataTypeAttributeParserRuleCall_7()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Primary__Alternatives"


    // $ANTLR start "rule__Comparison__Alternatives"
    // InternalX21.g:967:1: rule__Comparison__Alternatives : ( ( '=' ) | ( '<' ) | ( '>' ) | ( '<=' ) | ( '>=' ) );
    public final void rule__Comparison__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:971:1: ( ( '=' ) | ( '<' ) | ( '>' ) | ( '<=' ) | ( '>=' ) )
            int alt9=5;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt9=1;
                }
                break;
            case 12:
                {
                alt9=2;
                }
                break;
            case 13:
                {
                alt9=3;
                }
                break;
            case 14:
                {
                alt9=4;
                }
                break;
            case 15:
                {
                alt9=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalX21.g:972:2: ( '=' )
                    {
                    // InternalX21.g:972:2: ( '=' )
                    // InternalX21.g:973:3: '='
                    {
                     before(grammarAccess.getComparisonAccess().getEqualsSignKeyword_0()); 
                    match(input,11,FOLLOW_2); 
                     after(grammarAccess.getComparisonAccess().getEqualsSignKeyword_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalX21.g:978:2: ( '<' )
                    {
                    // InternalX21.g:978:2: ( '<' )
                    // InternalX21.g:979:3: '<'
                    {
                     before(grammarAccess.getComparisonAccess().getLessThanSignKeyword_1()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getComparisonAccess().getLessThanSignKeyword_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalX21.g:984:2: ( '>' )
                    {
                    // InternalX21.g:984:2: ( '>' )
                    // InternalX21.g:985:3: '>'
                    {
                     before(grammarAccess.getComparisonAccess().getGreaterThanSignKeyword_2()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getComparisonAccess().getGreaterThanSignKeyword_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalX21.g:990:2: ( '<=' )
                    {
                    // InternalX21.g:990:2: ( '<=' )
                    // InternalX21.g:991:3: '<='
                    {
                     before(grammarAccess.getComparisonAccess().getLessThanSignEqualsSignKeyword_3()); 
                    match(input,14,FOLLOW_2); 
                     after(grammarAccess.getComparisonAccess().getLessThanSignEqualsSignKeyword_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalX21.g:996:2: ( '>=' )
                    {
                    // InternalX21.g:996:2: ( '>=' )
                    // InternalX21.g:997:3: '>='
                    {
                     before(grammarAccess.getComparisonAccess().getGreaterThanSignEqualsSignKeyword_4()); 
                    match(input,15,FOLLOW_2); 
                     after(grammarAccess.getComparisonAccess().getGreaterThanSignEqualsSignKeyword_4()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Comparison__Alternatives"


    // $ANTLR start "rule__Program__Group__0"
    // InternalX21.g:1006:1: rule__Program__Group__0 : rule__Program__Group__0__Impl rule__Program__Group__1 ;
    public final void rule__Program__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1010:1: ( rule__Program__Group__0__Impl rule__Program__Group__1 )
            // InternalX21.g:1011:2: rule__Program__Group__0__Impl rule__Program__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Program__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Program__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__Group__0"


    // $ANTLR start "rule__Program__Group__0__Impl"
    // InternalX21.g:1018:1: rule__Program__Group__0__Impl : ( () ) ;
    public final void rule__Program__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1022:1: ( ( () ) )
            // InternalX21.g:1023:1: ( () )
            {
            // InternalX21.g:1023:1: ( () )
            // InternalX21.g:1024:2: ()
            {
             before(grammarAccess.getProgramAccess().getProgramAction_0()); 
            // InternalX21.g:1025:2: ()
            // InternalX21.g:1025:3: 
            {
            }

             after(grammarAccess.getProgramAccess().getProgramAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__Group__0__Impl"


    // $ANTLR start "rule__Program__Group__1"
    // InternalX21.g:1033:1: rule__Program__Group__1 : rule__Program__Group__1__Impl rule__Program__Group__2 ;
    public final void rule__Program__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1037:1: ( rule__Program__Group__1__Impl rule__Program__Group__2 )
            // InternalX21.g:1038:2: rule__Program__Group__1__Impl rule__Program__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Program__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Program__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__Group__1"


    // $ANTLR start "rule__Program__Group__1__Impl"
    // InternalX21.g:1045:1: rule__Program__Group__1__Impl : ( 'program' ) ;
    public final void rule__Program__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1049:1: ( ( 'program' ) )
            // InternalX21.g:1050:1: ( 'program' )
            {
            // InternalX21.g:1050:1: ( 'program' )
            // InternalX21.g:1051:2: 'program'
            {
             before(grammarAccess.getProgramAccess().getProgramKeyword_1()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getProgramAccess().getProgramKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__Group__1__Impl"


    // $ANTLR start "rule__Program__Group__2"
    // InternalX21.g:1060:1: rule__Program__Group__2 : rule__Program__Group__2__Impl rule__Program__Group__3 ;
    public final void rule__Program__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1064:1: ( rule__Program__Group__2__Impl rule__Program__Group__3 )
            // InternalX21.g:1065:2: rule__Program__Group__2__Impl rule__Program__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Program__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Program__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__Group__2"


    // $ANTLR start "rule__Program__Group__2__Impl"
    // InternalX21.g:1072:1: rule__Program__Group__2__Impl : ( ( rule__Program__NameAssignment_2 ) ) ;
    public final void rule__Program__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1076:1: ( ( ( rule__Program__NameAssignment_2 ) ) )
            // InternalX21.g:1077:1: ( ( rule__Program__NameAssignment_2 ) )
            {
            // InternalX21.g:1077:1: ( ( rule__Program__NameAssignment_2 ) )
            // InternalX21.g:1078:2: ( rule__Program__NameAssignment_2 )
            {
             before(grammarAccess.getProgramAccess().getNameAssignment_2()); 
            // InternalX21.g:1079:2: ( rule__Program__NameAssignment_2 )
            // InternalX21.g:1079:3: rule__Program__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Program__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getProgramAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__Group__2__Impl"


    // $ANTLR start "rule__Program__Group__3"
    // InternalX21.g:1087:1: rule__Program__Group__3 : rule__Program__Group__3__Impl ;
    public final void rule__Program__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1091:1: ( rule__Program__Group__3__Impl )
            // InternalX21.g:1092:2: rule__Program__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Program__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__Group__3"


    // $ANTLR start "rule__Program__Group__3__Impl"
    // InternalX21.g:1098:1: rule__Program__Group__3__Impl : ( ( rule__Program__DeclarationsAssignment_3 )* ) ;
    public final void rule__Program__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1102:1: ( ( ( rule__Program__DeclarationsAssignment_3 )* ) )
            // InternalX21.g:1103:1: ( ( rule__Program__DeclarationsAssignment_3 )* )
            {
            // InternalX21.g:1103:1: ( ( rule__Program__DeclarationsAssignment_3 )* )
            // InternalX21.g:1104:2: ( rule__Program__DeclarationsAssignment_3 )*
            {
             before(grammarAccess.getProgramAccess().getDeclarationsAssignment_3()); 
            // InternalX21.g:1105:2: ( rule__Program__DeclarationsAssignment_3 )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==17||LA10_0==19||(LA10_0>=24 && LA10_0<=25)||LA10_0==30||LA10_0==32) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalX21.g:1105:3: rule__Program__DeclarationsAssignment_3
            	    {
            	    pushFollow(FOLLOW_6);
            	    rule__Program__DeclarationsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

             after(grammarAccess.getProgramAccess().getDeclarationsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__Group__3__Impl"


    // $ANTLR start "rule__Parameter__Group__0"
    // InternalX21.g:1114:1: rule__Parameter__Group__0 : rule__Parameter__Group__0__Impl rule__Parameter__Group__1 ;
    public final void rule__Parameter__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1118:1: ( rule__Parameter__Group__0__Impl rule__Parameter__Group__1 )
            // InternalX21.g:1119:2: rule__Parameter__Group__0__Impl rule__Parameter__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Parameter__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Parameter__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parameter__Group__0"


    // $ANTLR start "rule__Parameter__Group__0__Impl"
    // InternalX21.g:1126:1: rule__Parameter__Group__0__Impl : ( 'parameter' ) ;
    public final void rule__Parameter__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1130:1: ( ( 'parameter' ) )
            // InternalX21.g:1131:1: ( 'parameter' )
            {
            // InternalX21.g:1131:1: ( 'parameter' )
            // InternalX21.g:1132:2: 'parameter'
            {
             before(grammarAccess.getParameterAccess().getParameterKeyword_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getParameterAccess().getParameterKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parameter__Group__0__Impl"


    // $ANTLR start "rule__Parameter__Group__1"
    // InternalX21.g:1141:1: rule__Parameter__Group__1 : rule__Parameter__Group__1__Impl rule__Parameter__Group__2 ;
    public final void rule__Parameter__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1145:1: ( rule__Parameter__Group__1__Impl rule__Parameter__Group__2 )
            // InternalX21.g:1146:2: rule__Parameter__Group__1__Impl rule__Parameter__Group__2
            {
            pushFollow(FOLLOW_7);
            rule__Parameter__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Parameter__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parameter__Group__1"


    // $ANTLR start "rule__Parameter__Group__1__Impl"
    // InternalX21.g:1153:1: rule__Parameter__Group__1__Impl : ( ( rule__Parameter__NameAssignment_1 ) ) ;
    public final void rule__Parameter__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1157:1: ( ( ( rule__Parameter__NameAssignment_1 ) ) )
            // InternalX21.g:1158:1: ( ( rule__Parameter__NameAssignment_1 ) )
            {
            // InternalX21.g:1158:1: ( ( rule__Parameter__NameAssignment_1 ) )
            // InternalX21.g:1159:2: ( rule__Parameter__NameAssignment_1 )
            {
             before(grammarAccess.getParameterAccess().getNameAssignment_1()); 
            // InternalX21.g:1160:2: ( rule__Parameter__NameAssignment_1 )
            // InternalX21.g:1160:3: rule__Parameter__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Parameter__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getParameterAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parameter__Group__1__Impl"


    // $ANTLR start "rule__Parameter__Group__2"
    // InternalX21.g:1168:1: rule__Parameter__Group__2 : rule__Parameter__Group__2__Impl rule__Parameter__Group__3 ;
    public final void rule__Parameter__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1172:1: ( rule__Parameter__Group__2__Impl rule__Parameter__Group__3 )
            // InternalX21.g:1173:2: rule__Parameter__Group__2__Impl rule__Parameter__Group__3
            {
            pushFollow(FOLLOW_8);
            rule__Parameter__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Parameter__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parameter__Group__2"


    // $ANTLR start "rule__Parameter__Group__2__Impl"
    // InternalX21.g:1180:1: rule__Parameter__Group__2__Impl : ( ':' ) ;
    public final void rule__Parameter__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1184:1: ( ( ':' ) )
            // InternalX21.g:1185:1: ( ':' )
            {
            // InternalX21.g:1185:1: ( ':' )
            // InternalX21.g:1186:2: ':'
            {
             before(grammarAccess.getParameterAccess().getColonKeyword_2()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getParameterAccess().getColonKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parameter__Group__2__Impl"


    // $ANTLR start "rule__Parameter__Group__3"
    // InternalX21.g:1195:1: rule__Parameter__Group__3 : rule__Parameter__Group__3__Impl ;
    public final void rule__Parameter__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1199:1: ( rule__Parameter__Group__3__Impl )
            // InternalX21.g:1200:2: rule__Parameter__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Parameter__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parameter__Group__3"


    // $ANTLR start "rule__Parameter__Group__3__Impl"
    // InternalX21.g:1206:1: rule__Parameter__Group__3__Impl : ( ( rule__Parameter__TypeAssignment_3 ) ) ;
    public final void rule__Parameter__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1210:1: ( ( ( rule__Parameter__TypeAssignment_3 ) ) )
            // InternalX21.g:1211:1: ( ( rule__Parameter__TypeAssignment_3 ) )
            {
            // InternalX21.g:1211:1: ( ( rule__Parameter__TypeAssignment_3 ) )
            // InternalX21.g:1212:2: ( rule__Parameter__TypeAssignment_3 )
            {
             before(grammarAccess.getParameterAccess().getTypeAssignment_3()); 
            // InternalX21.g:1213:2: ( rule__Parameter__TypeAssignment_3 )
            // InternalX21.g:1213:3: rule__Parameter__TypeAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Parameter__TypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getParameterAccess().getTypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parameter__Group__3__Impl"


    // $ANTLR start "rule__InternalParameter__Group__0"
    // InternalX21.g:1222:1: rule__InternalParameter__Group__0 : rule__InternalParameter__Group__0__Impl rule__InternalParameter__Group__1 ;
    public final void rule__InternalParameter__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1226:1: ( rule__InternalParameter__Group__0__Impl rule__InternalParameter__Group__1 )
            // InternalX21.g:1227:2: rule__InternalParameter__Group__0__Impl rule__InternalParameter__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__InternalParameter__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InternalParameter__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InternalParameter__Group__0"


    // $ANTLR start "rule__InternalParameter__Group__0__Impl"
    // InternalX21.g:1234:1: rule__InternalParameter__Group__0__Impl : ( () ) ;
    public final void rule__InternalParameter__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1238:1: ( ( () ) )
            // InternalX21.g:1239:1: ( () )
            {
            // InternalX21.g:1239:1: ( () )
            // InternalX21.g:1240:2: ()
            {
             before(grammarAccess.getInternalParameterAccess().getInternalParameterAction_0()); 
            // InternalX21.g:1241:2: ()
            // InternalX21.g:1241:3: 
            {
            }

             after(grammarAccess.getInternalParameterAccess().getInternalParameterAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InternalParameter__Group__0__Impl"


    // $ANTLR start "rule__InternalParameter__Group__1"
    // InternalX21.g:1249:1: rule__InternalParameter__Group__1 : rule__InternalParameter__Group__1__Impl rule__InternalParameter__Group__2 ;
    public final void rule__InternalParameter__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1253:1: ( rule__InternalParameter__Group__1__Impl rule__InternalParameter__Group__2 )
            // InternalX21.g:1254:2: rule__InternalParameter__Group__1__Impl rule__InternalParameter__Group__2
            {
            pushFollow(FOLLOW_7);
            rule__InternalParameter__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InternalParameter__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InternalParameter__Group__1"


    // $ANTLR start "rule__InternalParameter__Group__1__Impl"
    // InternalX21.g:1261:1: rule__InternalParameter__Group__1__Impl : ( ( rule__InternalParameter__NameAssignment_1 ) ) ;
    public final void rule__InternalParameter__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1265:1: ( ( ( rule__InternalParameter__NameAssignment_1 ) ) )
            // InternalX21.g:1266:1: ( ( rule__InternalParameter__NameAssignment_1 ) )
            {
            // InternalX21.g:1266:1: ( ( rule__InternalParameter__NameAssignment_1 ) )
            // InternalX21.g:1267:2: ( rule__InternalParameter__NameAssignment_1 )
            {
             before(grammarAccess.getInternalParameterAccess().getNameAssignment_1()); 
            // InternalX21.g:1268:2: ( rule__InternalParameter__NameAssignment_1 )
            // InternalX21.g:1268:3: rule__InternalParameter__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__InternalParameter__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getInternalParameterAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InternalParameter__Group__1__Impl"


    // $ANTLR start "rule__InternalParameter__Group__2"
    // InternalX21.g:1276:1: rule__InternalParameter__Group__2 : rule__InternalParameter__Group__2__Impl rule__InternalParameter__Group__3 ;
    public final void rule__InternalParameter__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1280:1: ( rule__InternalParameter__Group__2__Impl rule__InternalParameter__Group__3 )
            // InternalX21.g:1281:2: rule__InternalParameter__Group__2__Impl rule__InternalParameter__Group__3
            {
            pushFollow(FOLLOW_8);
            rule__InternalParameter__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InternalParameter__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InternalParameter__Group__2"


    // $ANTLR start "rule__InternalParameter__Group__2__Impl"
    // InternalX21.g:1288:1: rule__InternalParameter__Group__2__Impl : ( ':' ) ;
    public final void rule__InternalParameter__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1292:1: ( ( ':' ) )
            // InternalX21.g:1293:1: ( ':' )
            {
            // InternalX21.g:1293:1: ( ':' )
            // InternalX21.g:1294:2: ':'
            {
             before(grammarAccess.getInternalParameterAccess().getColonKeyword_2()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getInternalParameterAccess().getColonKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InternalParameter__Group__2__Impl"


    // $ANTLR start "rule__InternalParameter__Group__3"
    // InternalX21.g:1303:1: rule__InternalParameter__Group__3 : rule__InternalParameter__Group__3__Impl ;
    public final void rule__InternalParameter__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1307:1: ( rule__InternalParameter__Group__3__Impl )
            // InternalX21.g:1308:2: rule__InternalParameter__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InternalParameter__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InternalParameter__Group__3"


    // $ANTLR start "rule__InternalParameter__Group__3__Impl"
    // InternalX21.g:1314:1: rule__InternalParameter__Group__3__Impl : ( ( rule__InternalParameter__TypeAssignment_3 ) ) ;
    public final void rule__InternalParameter__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1318:1: ( ( ( rule__InternalParameter__TypeAssignment_3 ) ) )
            // InternalX21.g:1319:1: ( ( rule__InternalParameter__TypeAssignment_3 ) )
            {
            // InternalX21.g:1319:1: ( ( rule__InternalParameter__TypeAssignment_3 ) )
            // InternalX21.g:1320:2: ( rule__InternalParameter__TypeAssignment_3 )
            {
             before(grammarAccess.getInternalParameterAccess().getTypeAssignment_3()); 
            // InternalX21.g:1321:2: ( rule__InternalParameter__TypeAssignment_3 )
            // InternalX21.g:1321:3: rule__InternalParameter__TypeAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__InternalParameter__TypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getInternalParameterAccess().getTypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InternalParameter__Group__3__Impl"


    // $ANTLR start "rule__Function__Group__0"
    // InternalX21.g:1330:1: rule__Function__Group__0 : rule__Function__Group__0__Impl rule__Function__Group__1 ;
    public final void rule__Function__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1334:1: ( rule__Function__Group__0__Impl rule__Function__Group__1 )
            // InternalX21.g:1335:2: rule__Function__Group__0__Impl rule__Function__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Function__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Function__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__0"


    // $ANTLR start "rule__Function__Group__0__Impl"
    // InternalX21.g:1342:1: rule__Function__Group__0__Impl : ( 'function' ) ;
    public final void rule__Function__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1346:1: ( ( 'function' ) )
            // InternalX21.g:1347:1: ( 'function' )
            {
            // InternalX21.g:1347:1: ( 'function' )
            // InternalX21.g:1348:2: 'function'
            {
             before(grammarAccess.getFunctionAccess().getFunctionKeyword_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFunctionAccess().getFunctionKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__0__Impl"


    // $ANTLR start "rule__Function__Group__1"
    // InternalX21.g:1357:1: rule__Function__Group__1 : rule__Function__Group__1__Impl rule__Function__Group__2 ;
    public final void rule__Function__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1361:1: ( rule__Function__Group__1__Impl rule__Function__Group__2 )
            // InternalX21.g:1362:2: rule__Function__Group__1__Impl rule__Function__Group__2
            {
            pushFollow(FOLLOW_9);
            rule__Function__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Function__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__1"


    // $ANTLR start "rule__Function__Group__1__Impl"
    // InternalX21.g:1369:1: rule__Function__Group__1__Impl : ( ( rule__Function__NameAssignment_1 ) ) ;
    public final void rule__Function__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1373:1: ( ( ( rule__Function__NameAssignment_1 ) ) )
            // InternalX21.g:1374:1: ( ( rule__Function__NameAssignment_1 ) )
            {
            // InternalX21.g:1374:1: ( ( rule__Function__NameAssignment_1 ) )
            // InternalX21.g:1375:2: ( rule__Function__NameAssignment_1 )
            {
             before(grammarAccess.getFunctionAccess().getNameAssignment_1()); 
            // InternalX21.g:1376:2: ( rule__Function__NameAssignment_1 )
            // InternalX21.g:1376:3: rule__Function__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Function__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getFunctionAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__1__Impl"


    // $ANTLR start "rule__Function__Group__2"
    // InternalX21.g:1384:1: rule__Function__Group__2 : rule__Function__Group__2__Impl ;
    public final void rule__Function__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1388:1: ( rule__Function__Group__2__Impl )
            // InternalX21.g:1389:2: rule__Function__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Function__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__2"


    // $ANTLR start "rule__Function__Group__2__Impl"
    // InternalX21.g:1395:1: rule__Function__Group__2__Impl : ( ( rule__Function__LambdaAssignment_2 ) ) ;
    public final void rule__Function__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1399:1: ( ( ( rule__Function__LambdaAssignment_2 ) ) )
            // InternalX21.g:1400:1: ( ( rule__Function__LambdaAssignment_2 ) )
            {
            // InternalX21.g:1400:1: ( ( rule__Function__LambdaAssignment_2 ) )
            // InternalX21.g:1401:2: ( rule__Function__LambdaAssignment_2 )
            {
             before(grammarAccess.getFunctionAccess().getLambdaAssignment_2()); 
            // InternalX21.g:1402:2: ( rule__Function__LambdaAssignment_2 )
            // InternalX21.g:1402:3: rule__Function__LambdaAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Function__LambdaAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getFunctionAccess().getLambdaAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__2__Impl"


    // $ANTLR start "rule__Lambda__Group__0"
    // InternalX21.g:1411:1: rule__Lambda__Group__0 : rule__Lambda__Group__0__Impl rule__Lambda__Group__1 ;
    public final void rule__Lambda__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1415:1: ( rule__Lambda__Group__0__Impl rule__Lambda__Group__1 )
            // InternalX21.g:1416:2: rule__Lambda__Group__0__Impl rule__Lambda__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Lambda__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Lambda__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__Group__0"


    // $ANTLR start "rule__Lambda__Group__0__Impl"
    // InternalX21.g:1423:1: rule__Lambda__Group__0__Impl : ( '(' ) ;
    public final void rule__Lambda__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1427:1: ( ( '(' ) )
            // InternalX21.g:1428:1: ( '(' )
            {
            // InternalX21.g:1428:1: ( '(' )
            // InternalX21.g:1429:2: '('
            {
             before(grammarAccess.getLambdaAccess().getLeftParenthesisKeyword_0()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getLambdaAccess().getLeftParenthesisKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__Group__0__Impl"


    // $ANTLR start "rule__Lambda__Group__1"
    // InternalX21.g:1438:1: rule__Lambda__Group__1 : rule__Lambda__Group__1__Impl rule__Lambda__Group__2 ;
    public final void rule__Lambda__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1442:1: ( rule__Lambda__Group__1__Impl rule__Lambda__Group__2 )
            // InternalX21.g:1443:2: rule__Lambda__Group__1__Impl rule__Lambda__Group__2
            {
            pushFollow(FOLLOW_10);
            rule__Lambda__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Lambda__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__Group__1"


    // $ANTLR start "rule__Lambda__Group__1__Impl"
    // InternalX21.g:1450:1: rule__Lambda__Group__1__Impl : ( ( rule__Lambda__ParameterAssignment_1 ) ) ;
    public final void rule__Lambda__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1454:1: ( ( ( rule__Lambda__ParameterAssignment_1 ) ) )
            // InternalX21.g:1455:1: ( ( rule__Lambda__ParameterAssignment_1 ) )
            {
            // InternalX21.g:1455:1: ( ( rule__Lambda__ParameterAssignment_1 ) )
            // InternalX21.g:1456:2: ( rule__Lambda__ParameterAssignment_1 )
            {
             before(grammarAccess.getLambdaAccess().getParameterAssignment_1()); 
            // InternalX21.g:1457:2: ( rule__Lambda__ParameterAssignment_1 )
            // InternalX21.g:1457:3: rule__Lambda__ParameterAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Lambda__ParameterAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getLambdaAccess().getParameterAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__Group__1__Impl"


    // $ANTLR start "rule__Lambda__Group__2"
    // InternalX21.g:1465:1: rule__Lambda__Group__2 : rule__Lambda__Group__2__Impl rule__Lambda__Group__3 ;
    public final void rule__Lambda__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1469:1: ( rule__Lambda__Group__2__Impl rule__Lambda__Group__3 )
            // InternalX21.g:1470:2: rule__Lambda__Group__2__Impl rule__Lambda__Group__3
            {
            pushFollow(FOLLOW_11);
            rule__Lambda__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Lambda__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__Group__2"


    // $ANTLR start "rule__Lambda__Group__2__Impl"
    // InternalX21.g:1477:1: rule__Lambda__Group__2__Impl : ( ')' ) ;
    public final void rule__Lambda__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1481:1: ( ( ')' ) )
            // InternalX21.g:1482:1: ( ')' )
            {
            // InternalX21.g:1482:1: ( ')' )
            // InternalX21.g:1483:2: ')'
            {
             before(grammarAccess.getLambdaAccess().getRightParenthesisKeyword_2()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getLambdaAccess().getRightParenthesisKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__Group__2__Impl"


    // $ANTLR start "rule__Lambda__Group__3"
    // InternalX21.g:1492:1: rule__Lambda__Group__3 : rule__Lambda__Group__3__Impl rule__Lambda__Group__4 ;
    public final void rule__Lambda__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1496:1: ( rule__Lambda__Group__3__Impl rule__Lambda__Group__4 )
            // InternalX21.g:1497:2: rule__Lambda__Group__3__Impl rule__Lambda__Group__4
            {
            pushFollow(FOLLOW_12);
            rule__Lambda__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Lambda__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__Group__3"


    // $ANTLR start "rule__Lambda__Group__3__Impl"
    // InternalX21.g:1504:1: rule__Lambda__Group__3__Impl : ( '{' ) ;
    public final void rule__Lambda__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1508:1: ( ( '{' ) )
            // InternalX21.g:1509:1: ( '{' )
            {
            // InternalX21.g:1509:1: ( '{' )
            // InternalX21.g:1510:2: '{'
            {
             before(grammarAccess.getLambdaAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getLambdaAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__Group__3__Impl"


    // $ANTLR start "rule__Lambda__Group__4"
    // InternalX21.g:1519:1: rule__Lambda__Group__4 : rule__Lambda__Group__4__Impl rule__Lambda__Group__5 ;
    public final void rule__Lambda__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1523:1: ( rule__Lambda__Group__4__Impl rule__Lambda__Group__5 )
            // InternalX21.g:1524:2: rule__Lambda__Group__4__Impl rule__Lambda__Group__5
            {
            pushFollow(FOLLOW_13);
            rule__Lambda__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Lambda__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__Group__4"


    // $ANTLR start "rule__Lambda__Group__4__Impl"
    // InternalX21.g:1531:1: rule__Lambda__Group__4__Impl : ( ( rule__Lambda__ExpAssignment_4 ) ) ;
    public final void rule__Lambda__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1535:1: ( ( ( rule__Lambda__ExpAssignment_4 ) ) )
            // InternalX21.g:1536:1: ( ( rule__Lambda__ExpAssignment_4 ) )
            {
            // InternalX21.g:1536:1: ( ( rule__Lambda__ExpAssignment_4 ) )
            // InternalX21.g:1537:2: ( rule__Lambda__ExpAssignment_4 )
            {
             before(grammarAccess.getLambdaAccess().getExpAssignment_4()); 
            // InternalX21.g:1538:2: ( rule__Lambda__ExpAssignment_4 )
            // InternalX21.g:1538:3: rule__Lambda__ExpAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Lambda__ExpAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getLambdaAccess().getExpAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__Group__4__Impl"


    // $ANTLR start "rule__Lambda__Group__5"
    // InternalX21.g:1546:1: rule__Lambda__Group__5 : rule__Lambda__Group__5__Impl ;
    public final void rule__Lambda__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1550:1: ( rule__Lambda__Group__5__Impl )
            // InternalX21.g:1551:2: rule__Lambda__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Lambda__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__Group__5"


    // $ANTLR start "rule__Lambda__Group__5__Impl"
    // InternalX21.g:1557:1: rule__Lambda__Group__5__Impl : ( '}' ) ;
    public final void rule__Lambda__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1561:1: ( ( '}' ) )
            // InternalX21.g:1562:1: ( '}' )
            {
            // InternalX21.g:1562:1: ( '}' )
            // InternalX21.g:1563:2: '}'
            {
             before(grammarAccess.getLambdaAccess().getRightCurlyBracketKeyword_5()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getLambdaAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__Group__5__Impl"


    // $ANTLR start "rule__Input__Group__0"
    // InternalX21.g:1573:1: rule__Input__Group__0 : rule__Input__Group__0__Impl rule__Input__Group__1 ;
    public final void rule__Input__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1577:1: ( rule__Input__Group__0__Impl rule__Input__Group__1 )
            // InternalX21.g:1578:2: rule__Input__Group__0__Impl rule__Input__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Input__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Input__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__Group__0"


    // $ANTLR start "rule__Input__Group__0__Impl"
    // InternalX21.g:1585:1: rule__Input__Group__0__Impl : ( 'input' ) ;
    public final void rule__Input__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1589:1: ( ( 'input' ) )
            // InternalX21.g:1590:1: ( 'input' )
            {
            // InternalX21.g:1590:1: ( 'input' )
            // InternalX21.g:1591:2: 'input'
            {
             before(grammarAccess.getInputAccess().getInputKeyword_0()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getInputAccess().getInputKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__Group__0__Impl"


    // $ANTLR start "rule__Input__Group__1"
    // InternalX21.g:1600:1: rule__Input__Group__1 : rule__Input__Group__1__Impl rule__Input__Group__2 ;
    public final void rule__Input__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1604:1: ( rule__Input__Group__1__Impl rule__Input__Group__2 )
            // InternalX21.g:1605:2: rule__Input__Group__1__Impl rule__Input__Group__2
            {
            pushFollow(FOLLOW_7);
            rule__Input__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Input__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__Group__1"


    // $ANTLR start "rule__Input__Group__1__Impl"
    // InternalX21.g:1612:1: rule__Input__Group__1__Impl : ( ( rule__Input__NameAssignment_1 ) ) ;
    public final void rule__Input__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1616:1: ( ( ( rule__Input__NameAssignment_1 ) ) )
            // InternalX21.g:1617:1: ( ( rule__Input__NameAssignment_1 ) )
            {
            // InternalX21.g:1617:1: ( ( rule__Input__NameAssignment_1 ) )
            // InternalX21.g:1618:2: ( rule__Input__NameAssignment_1 )
            {
             before(grammarAccess.getInputAccess().getNameAssignment_1()); 
            // InternalX21.g:1619:2: ( rule__Input__NameAssignment_1 )
            // InternalX21.g:1619:3: rule__Input__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Input__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getInputAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__Group__1__Impl"


    // $ANTLR start "rule__Input__Group__2"
    // InternalX21.g:1627:1: rule__Input__Group__2 : rule__Input__Group__2__Impl rule__Input__Group__3 ;
    public final void rule__Input__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1631:1: ( rule__Input__Group__2__Impl rule__Input__Group__3 )
            // InternalX21.g:1632:2: rule__Input__Group__2__Impl rule__Input__Group__3
            {
            pushFollow(FOLLOW_8);
            rule__Input__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Input__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__Group__2"


    // $ANTLR start "rule__Input__Group__2__Impl"
    // InternalX21.g:1639:1: rule__Input__Group__2__Impl : ( ':' ) ;
    public final void rule__Input__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1643:1: ( ( ':' ) )
            // InternalX21.g:1644:1: ( ':' )
            {
            // InternalX21.g:1644:1: ( ':' )
            // InternalX21.g:1645:2: ':'
            {
             before(grammarAccess.getInputAccess().getColonKeyword_2()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getInputAccess().getColonKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__Group__2__Impl"


    // $ANTLR start "rule__Input__Group__3"
    // InternalX21.g:1654:1: rule__Input__Group__3 : rule__Input__Group__3__Impl ;
    public final void rule__Input__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1658:1: ( rule__Input__Group__3__Impl )
            // InternalX21.g:1659:2: rule__Input__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Input__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__Group__3"


    // $ANTLR start "rule__Input__Group__3__Impl"
    // InternalX21.g:1665:1: rule__Input__Group__3__Impl : ( ( rule__Input__TypeAssignment_3 ) ) ;
    public final void rule__Input__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1669:1: ( ( ( rule__Input__TypeAssignment_3 ) ) )
            // InternalX21.g:1670:1: ( ( rule__Input__TypeAssignment_3 ) )
            {
            // InternalX21.g:1670:1: ( ( rule__Input__TypeAssignment_3 ) )
            // InternalX21.g:1671:2: ( rule__Input__TypeAssignment_3 )
            {
             before(grammarAccess.getInputAccess().getTypeAssignment_3()); 
            // InternalX21.g:1672:2: ( rule__Input__TypeAssignment_3 )
            // InternalX21.g:1672:3: rule__Input__TypeAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Input__TypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getInputAccess().getTypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__Group__3__Impl"


    // $ANTLR start "rule__Node__Group__0"
    // InternalX21.g:1681:1: rule__Node__Group__0 : rule__Node__Group__0__Impl rule__Node__Group__1 ;
    public final void rule__Node__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1685:1: ( rule__Node__Group__0__Impl rule__Node__Group__1 )
            // InternalX21.g:1686:2: rule__Node__Group__0__Impl rule__Node__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Node__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Node__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__Group__0"


    // $ANTLR start "rule__Node__Group__0__Impl"
    // InternalX21.g:1693:1: rule__Node__Group__0__Impl : ( 'node' ) ;
    public final void rule__Node__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1697:1: ( ( 'node' ) )
            // InternalX21.g:1698:1: ( 'node' )
            {
            // InternalX21.g:1698:1: ( 'node' )
            // InternalX21.g:1699:2: 'node'
            {
             before(grammarAccess.getNodeAccess().getNodeKeyword_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getNodeAccess().getNodeKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__Group__0__Impl"


    // $ANTLR start "rule__Node__Group__1"
    // InternalX21.g:1708:1: rule__Node__Group__1 : rule__Node__Group__1__Impl rule__Node__Group__2 ;
    public final void rule__Node__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1712:1: ( rule__Node__Group__1__Impl rule__Node__Group__2 )
            // InternalX21.g:1713:2: rule__Node__Group__1__Impl rule__Node__Group__2
            {
            pushFollow(FOLLOW_14);
            rule__Node__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Node__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__Group__1"


    // $ANTLR start "rule__Node__Group__1__Impl"
    // InternalX21.g:1720:1: rule__Node__Group__1__Impl : ( ( rule__Node__NameAssignment_1 ) ) ;
    public final void rule__Node__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1724:1: ( ( ( rule__Node__NameAssignment_1 ) ) )
            // InternalX21.g:1725:1: ( ( rule__Node__NameAssignment_1 ) )
            {
            // InternalX21.g:1725:1: ( ( rule__Node__NameAssignment_1 ) )
            // InternalX21.g:1726:2: ( rule__Node__NameAssignment_1 )
            {
             before(grammarAccess.getNodeAccess().getNameAssignment_1()); 
            // InternalX21.g:1727:2: ( rule__Node__NameAssignment_1 )
            // InternalX21.g:1727:3: rule__Node__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Node__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getNodeAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__Group__1__Impl"


    // $ANTLR start "rule__Node__Group__2"
    // InternalX21.g:1735:1: rule__Node__Group__2 : rule__Node__Group__2__Impl rule__Node__Group__3 ;
    public final void rule__Node__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1739:1: ( rule__Node__Group__2__Impl rule__Node__Group__3 )
            // InternalX21.g:1740:2: rule__Node__Group__2__Impl rule__Node__Group__3
            {
            pushFollow(FOLLOW_15);
            rule__Node__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Node__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__Group__2"


    // $ANTLR start "rule__Node__Group__2__Impl"
    // InternalX21.g:1747:1: rule__Node__Group__2__Impl : ( '[' ) ;
    public final void rule__Node__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1751:1: ( ( '[' ) )
            // InternalX21.g:1752:1: ( '[' )
            {
            // InternalX21.g:1752:1: ( '[' )
            // InternalX21.g:1753:2: '['
            {
             before(grammarAccess.getNodeAccess().getLeftSquareBracketKeyword_2()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getNodeAccess().getLeftSquareBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__Group__2__Impl"


    // $ANTLR start "rule__Node__Group__3"
    // InternalX21.g:1762:1: rule__Node__Group__3 : rule__Node__Group__3__Impl rule__Node__Group__4 ;
    public final void rule__Node__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1766:1: ( rule__Node__Group__3__Impl rule__Node__Group__4 )
            // InternalX21.g:1767:2: rule__Node__Group__3__Impl rule__Node__Group__4
            {
            pushFollow(FOLLOW_16);
            rule__Node__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Node__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__Group__3"


    // $ANTLR start "rule__Node__Group__3__Impl"
    // InternalX21.g:1774:1: rule__Node__Group__3__Impl : ( ( rule__Node__Alternatives_3 ) ) ;
    public final void rule__Node__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1778:1: ( ( ( rule__Node__Alternatives_3 ) ) )
            // InternalX21.g:1779:1: ( ( rule__Node__Alternatives_3 ) )
            {
            // InternalX21.g:1779:1: ( ( rule__Node__Alternatives_3 ) )
            // InternalX21.g:1780:2: ( rule__Node__Alternatives_3 )
            {
             before(grammarAccess.getNodeAccess().getAlternatives_3()); 
            // InternalX21.g:1781:2: ( rule__Node__Alternatives_3 )
            // InternalX21.g:1781:3: rule__Node__Alternatives_3
            {
            pushFollow(FOLLOW_2);
            rule__Node__Alternatives_3();

            state._fsp--;


            }

             after(grammarAccess.getNodeAccess().getAlternatives_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__Group__3__Impl"


    // $ANTLR start "rule__Node__Group__4"
    // InternalX21.g:1789:1: rule__Node__Group__4 : rule__Node__Group__4__Impl ;
    public final void rule__Node__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1793:1: ( rule__Node__Group__4__Impl )
            // InternalX21.g:1794:2: rule__Node__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Node__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__Group__4"


    // $ANTLR start "rule__Node__Group__4__Impl"
    // InternalX21.g:1800:1: rule__Node__Group__4__Impl : ( ']' ) ;
    public final void rule__Node__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1804:1: ( ( ']' ) )
            // InternalX21.g:1805:1: ( ']' )
            {
            // InternalX21.g:1805:1: ( ']' )
            // InternalX21.g:1806:2: ']'
            {
             before(grammarAccess.getNodeAccess().getRightSquareBracketKeyword_4()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getNodeAccess().getRightSquareBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__Group__4__Impl"


    // $ANTLR start "rule__StreamOutput__Group__0"
    // InternalX21.g:1816:1: rule__StreamOutput__Group__0 : rule__StreamOutput__Group__0__Impl rule__StreamOutput__Group__1 ;
    public final void rule__StreamOutput__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1820:1: ( rule__StreamOutput__Group__0__Impl rule__StreamOutput__Group__1 )
            // InternalX21.g:1821:2: rule__StreamOutput__Group__0__Impl rule__StreamOutput__Group__1
            {
            pushFollow(FOLLOW_17);
            rule__StreamOutput__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StreamOutput__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__Group__0"


    // $ANTLR start "rule__StreamOutput__Group__0__Impl"
    // InternalX21.g:1828:1: rule__StreamOutput__Group__0__Impl : ( () ) ;
    public final void rule__StreamOutput__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1832:1: ( ( () ) )
            // InternalX21.g:1833:1: ( () )
            {
            // InternalX21.g:1833:1: ( () )
            // InternalX21.g:1834:2: ()
            {
             before(grammarAccess.getStreamOutputAccess().getStreamOutputAction_0()); 
            // InternalX21.g:1835:2: ()
            // InternalX21.g:1835:3: 
            {
            }

             after(grammarAccess.getStreamOutputAccess().getStreamOutputAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__Group__0__Impl"


    // $ANTLR start "rule__StreamOutput__Group__1"
    // InternalX21.g:1843:1: rule__StreamOutput__Group__1 : rule__StreamOutput__Group__1__Impl rule__StreamOutput__Group__2 ;
    public final void rule__StreamOutput__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1847:1: ( rule__StreamOutput__Group__1__Impl rule__StreamOutput__Group__2 )
            // InternalX21.g:1848:2: rule__StreamOutput__Group__1__Impl rule__StreamOutput__Group__2
            {
            pushFollow(FOLLOW_18);
            rule__StreamOutput__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StreamOutput__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__Group__1"


    // $ANTLR start "rule__StreamOutput__Group__1__Impl"
    // InternalX21.g:1855:1: rule__StreamOutput__Group__1__Impl : ( 'to' ) ;
    public final void rule__StreamOutput__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1859:1: ( ( 'to' ) )
            // InternalX21.g:1860:1: ( 'to' )
            {
            // InternalX21.g:1860:1: ( 'to' )
            // InternalX21.g:1861:2: 'to'
            {
             before(grammarAccess.getStreamOutputAccess().getToKeyword_1()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getStreamOutputAccess().getToKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__Group__1__Impl"


    // $ANTLR start "rule__StreamOutput__Group__2"
    // InternalX21.g:1870:1: rule__StreamOutput__Group__2 : rule__StreamOutput__Group__2__Impl rule__StreamOutput__Group__3 ;
    public final void rule__StreamOutput__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1874:1: ( rule__StreamOutput__Group__2__Impl rule__StreamOutput__Group__3 )
            // InternalX21.g:1875:2: rule__StreamOutput__Group__2__Impl rule__StreamOutput__Group__3
            {
            pushFollow(FOLLOW_19);
            rule__StreamOutput__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StreamOutput__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__Group__2"


    // $ANTLR start "rule__StreamOutput__Group__2__Impl"
    // InternalX21.g:1882:1: rule__StreamOutput__Group__2__Impl : ( ( rule__StreamOutput__TargetsAssignment_2 ) ) ;
    public final void rule__StreamOutput__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1886:1: ( ( ( rule__StreamOutput__TargetsAssignment_2 ) ) )
            // InternalX21.g:1887:1: ( ( rule__StreamOutput__TargetsAssignment_2 ) )
            {
            // InternalX21.g:1887:1: ( ( rule__StreamOutput__TargetsAssignment_2 ) )
            // InternalX21.g:1888:2: ( rule__StreamOutput__TargetsAssignment_2 )
            {
             before(grammarAccess.getStreamOutputAccess().getTargetsAssignment_2()); 
            // InternalX21.g:1889:2: ( rule__StreamOutput__TargetsAssignment_2 )
            // InternalX21.g:1889:3: rule__StreamOutput__TargetsAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__StreamOutput__TargetsAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getStreamOutputAccess().getTargetsAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__Group__2__Impl"


    // $ANTLR start "rule__StreamOutput__Group__3"
    // InternalX21.g:1897:1: rule__StreamOutput__Group__3 : rule__StreamOutput__Group__3__Impl ;
    public final void rule__StreamOutput__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1901:1: ( rule__StreamOutput__Group__3__Impl )
            // InternalX21.g:1902:2: rule__StreamOutput__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StreamOutput__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__Group__3"


    // $ANTLR start "rule__StreamOutput__Group__3__Impl"
    // InternalX21.g:1908:1: rule__StreamOutput__Group__3__Impl : ( ( rule__StreamOutput__Group_3__0 )* ) ;
    public final void rule__StreamOutput__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1912:1: ( ( ( rule__StreamOutput__Group_3__0 )* ) )
            // InternalX21.g:1913:1: ( ( rule__StreamOutput__Group_3__0 )* )
            {
            // InternalX21.g:1913:1: ( ( rule__StreamOutput__Group_3__0 )* )
            // InternalX21.g:1914:2: ( rule__StreamOutput__Group_3__0 )*
            {
             before(grammarAccess.getStreamOutputAccess().getGroup_3()); 
            // InternalX21.g:1915:2: ( rule__StreamOutput__Group_3__0 )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==29) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalX21.g:1915:3: rule__StreamOutput__Group_3__0
            	    {
            	    pushFollow(FOLLOW_20);
            	    rule__StreamOutput__Group_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

             after(grammarAccess.getStreamOutputAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__Group__3__Impl"


    // $ANTLR start "rule__StreamOutput__Group_3__0"
    // InternalX21.g:1924:1: rule__StreamOutput__Group_3__0 : rule__StreamOutput__Group_3__0__Impl rule__StreamOutput__Group_3__1 ;
    public final void rule__StreamOutput__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1928:1: ( rule__StreamOutput__Group_3__0__Impl rule__StreamOutput__Group_3__1 )
            // InternalX21.g:1929:2: rule__StreamOutput__Group_3__0__Impl rule__StreamOutput__Group_3__1
            {
            pushFollow(FOLLOW_18);
            rule__StreamOutput__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StreamOutput__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__Group_3__0"


    // $ANTLR start "rule__StreamOutput__Group_3__0__Impl"
    // InternalX21.g:1936:1: rule__StreamOutput__Group_3__0__Impl : ( ',' ) ;
    public final void rule__StreamOutput__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1940:1: ( ( ',' ) )
            // InternalX21.g:1941:1: ( ',' )
            {
            // InternalX21.g:1941:1: ( ',' )
            // InternalX21.g:1942:2: ','
            {
             before(grammarAccess.getStreamOutputAccess().getCommaKeyword_3_0()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getStreamOutputAccess().getCommaKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__Group_3__0__Impl"


    // $ANTLR start "rule__StreamOutput__Group_3__1"
    // InternalX21.g:1951:1: rule__StreamOutput__Group_3__1 : rule__StreamOutput__Group_3__1__Impl ;
    public final void rule__StreamOutput__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1955:1: ( rule__StreamOutput__Group_3__1__Impl )
            // InternalX21.g:1956:2: rule__StreamOutput__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StreamOutput__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__Group_3__1"


    // $ANTLR start "rule__StreamOutput__Group_3__1__Impl"
    // InternalX21.g:1962:1: rule__StreamOutput__Group_3__1__Impl : ( ( rule__StreamOutput__TargetsAssignment_3_1 ) ) ;
    public final void rule__StreamOutput__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1966:1: ( ( ( rule__StreamOutput__TargetsAssignment_3_1 ) ) )
            // InternalX21.g:1967:1: ( ( rule__StreamOutput__TargetsAssignment_3_1 ) )
            {
            // InternalX21.g:1967:1: ( ( rule__StreamOutput__TargetsAssignment_3_1 ) )
            // InternalX21.g:1968:2: ( rule__StreamOutput__TargetsAssignment_3_1 )
            {
             before(grammarAccess.getStreamOutputAccess().getTargetsAssignment_3_1()); 
            // InternalX21.g:1969:2: ( rule__StreamOutput__TargetsAssignment_3_1 )
            // InternalX21.g:1969:3: rule__StreamOutput__TargetsAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__StreamOutput__TargetsAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getStreamOutputAccess().getTargetsAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__Group_3__1__Impl"


    // $ANTLR start "rule__Stream__Group__0"
    // InternalX21.g:1978:1: rule__Stream__Group__0 : rule__Stream__Group__0__Impl rule__Stream__Group__1 ;
    public final void rule__Stream__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1982:1: ( rule__Stream__Group__0__Impl rule__Stream__Group__1 )
            // InternalX21.g:1983:2: rule__Stream__Group__0__Impl rule__Stream__Group__1
            {
            pushFollow(FOLLOW_21);
            rule__Stream__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Stream__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group__0"


    // $ANTLR start "rule__Stream__Group__0__Impl"
    // InternalX21.g:1990:1: rule__Stream__Group__0__Impl : ( () ) ;
    public final void rule__Stream__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:1994:1: ( ( () ) )
            // InternalX21.g:1995:1: ( () )
            {
            // InternalX21.g:1995:1: ( () )
            // InternalX21.g:1996:2: ()
            {
             before(grammarAccess.getStreamAccess().getStreamAction_0()); 
            // InternalX21.g:1997:2: ()
            // InternalX21.g:1997:3: 
            {
            }

             after(grammarAccess.getStreamAccess().getStreamAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group__0__Impl"


    // $ANTLR start "rule__Stream__Group__1"
    // InternalX21.g:2005:1: rule__Stream__Group__1 : rule__Stream__Group__1__Impl rule__Stream__Group__2 ;
    public final void rule__Stream__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2009:1: ( rule__Stream__Group__1__Impl rule__Stream__Group__2 )
            // InternalX21.g:2010:2: rule__Stream__Group__1__Impl rule__Stream__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Stream__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Stream__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group__1"


    // $ANTLR start "rule__Stream__Group__1__Impl"
    // InternalX21.g:2017:1: rule__Stream__Group__1__Impl : ( 'stream' ) ;
    public final void rule__Stream__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2021:1: ( ( 'stream' ) )
            // InternalX21.g:2022:1: ( 'stream' )
            {
            // InternalX21.g:2022:1: ( 'stream' )
            // InternalX21.g:2023:2: 'stream'
            {
             before(grammarAccess.getStreamAccess().getStreamKeyword_1()); 
            match(input,30,FOLLOW_2); 
             after(grammarAccess.getStreamAccess().getStreamKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group__1__Impl"


    // $ANTLR start "rule__Stream__Group__2"
    // InternalX21.g:2032:1: rule__Stream__Group__2 : rule__Stream__Group__2__Impl rule__Stream__Group__3 ;
    public final void rule__Stream__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2036:1: ( rule__Stream__Group__2__Impl rule__Stream__Group__3 )
            // InternalX21.g:2037:2: rule__Stream__Group__2__Impl rule__Stream__Group__3
            {
            pushFollow(FOLLOW_22);
            rule__Stream__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Stream__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group__2"


    // $ANTLR start "rule__Stream__Group__2__Impl"
    // InternalX21.g:2044:1: rule__Stream__Group__2__Impl : ( ( rule__Stream__OriginsAssignment_2 ) ) ;
    public final void rule__Stream__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2048:1: ( ( ( rule__Stream__OriginsAssignment_2 ) ) )
            // InternalX21.g:2049:1: ( ( rule__Stream__OriginsAssignment_2 ) )
            {
            // InternalX21.g:2049:1: ( ( rule__Stream__OriginsAssignment_2 ) )
            // InternalX21.g:2050:2: ( rule__Stream__OriginsAssignment_2 )
            {
             before(grammarAccess.getStreamAccess().getOriginsAssignment_2()); 
            // InternalX21.g:2051:2: ( rule__Stream__OriginsAssignment_2 )
            // InternalX21.g:2051:3: rule__Stream__OriginsAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Stream__OriginsAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getStreamAccess().getOriginsAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group__2__Impl"


    // $ANTLR start "rule__Stream__Group__3"
    // InternalX21.g:2059:1: rule__Stream__Group__3 : rule__Stream__Group__3__Impl rule__Stream__Group__4 ;
    public final void rule__Stream__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2063:1: ( rule__Stream__Group__3__Impl rule__Stream__Group__4 )
            // InternalX21.g:2064:2: rule__Stream__Group__3__Impl rule__Stream__Group__4
            {
            pushFollow(FOLLOW_22);
            rule__Stream__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Stream__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group__3"


    // $ANTLR start "rule__Stream__Group__3__Impl"
    // InternalX21.g:2071:1: rule__Stream__Group__3__Impl : ( ( rule__Stream__Group_3__0 )* ) ;
    public final void rule__Stream__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2075:1: ( ( ( rule__Stream__Group_3__0 )* ) )
            // InternalX21.g:2076:1: ( ( rule__Stream__Group_3__0 )* )
            {
            // InternalX21.g:2076:1: ( ( rule__Stream__Group_3__0 )* )
            // InternalX21.g:2077:2: ( rule__Stream__Group_3__0 )*
            {
             before(grammarAccess.getStreamAccess().getGroup_3()); 
            // InternalX21.g:2078:2: ( rule__Stream__Group_3__0 )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==29) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalX21.g:2078:3: rule__Stream__Group_3__0
            	    {
            	    pushFollow(FOLLOW_20);
            	    rule__Stream__Group_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

             after(grammarAccess.getStreamAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group__3__Impl"


    // $ANTLR start "rule__Stream__Group__4"
    // InternalX21.g:2086:1: rule__Stream__Group__4 : rule__Stream__Group__4__Impl ;
    public final void rule__Stream__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2090:1: ( rule__Stream__Group__4__Impl )
            // InternalX21.g:2091:2: rule__Stream__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Stream__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group__4"


    // $ANTLR start "rule__Stream__Group__4__Impl"
    // InternalX21.g:2097:1: rule__Stream__Group__4__Impl : ( ( ( rule__Stream__OutputsAssignment_4 ) ) ( ( rule__Stream__OutputsAssignment_4 )* ) ) ;
    public final void rule__Stream__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2101:1: ( ( ( ( rule__Stream__OutputsAssignment_4 ) ) ( ( rule__Stream__OutputsAssignment_4 )* ) ) )
            // InternalX21.g:2102:1: ( ( ( rule__Stream__OutputsAssignment_4 ) ) ( ( rule__Stream__OutputsAssignment_4 )* ) )
            {
            // InternalX21.g:2102:1: ( ( ( rule__Stream__OutputsAssignment_4 ) ) ( ( rule__Stream__OutputsAssignment_4 )* ) )
            // InternalX21.g:2103:2: ( ( rule__Stream__OutputsAssignment_4 ) ) ( ( rule__Stream__OutputsAssignment_4 )* )
            {
            // InternalX21.g:2103:2: ( ( rule__Stream__OutputsAssignment_4 ) )
            // InternalX21.g:2104:3: ( rule__Stream__OutputsAssignment_4 )
            {
             before(grammarAccess.getStreamAccess().getOutputsAssignment_4()); 
            // InternalX21.g:2105:3: ( rule__Stream__OutputsAssignment_4 )
            // InternalX21.g:2105:4: rule__Stream__OutputsAssignment_4
            {
            pushFollow(FOLLOW_23);
            rule__Stream__OutputsAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getStreamAccess().getOutputsAssignment_4()); 

            }

            // InternalX21.g:2108:2: ( ( rule__Stream__OutputsAssignment_4 )* )
            // InternalX21.g:2109:3: ( rule__Stream__OutputsAssignment_4 )*
            {
             before(grammarAccess.getStreamAccess().getOutputsAssignment_4()); 
            // InternalX21.g:2110:3: ( rule__Stream__OutputsAssignment_4 )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==28) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalX21.g:2110:4: rule__Stream__OutputsAssignment_4
            	    {
            	    pushFollow(FOLLOW_23);
            	    rule__Stream__OutputsAssignment_4();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

             after(grammarAccess.getStreamAccess().getOutputsAssignment_4()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group__4__Impl"


    // $ANTLR start "rule__Stream__Group_3__0"
    // InternalX21.g:2120:1: rule__Stream__Group_3__0 : rule__Stream__Group_3__0__Impl rule__Stream__Group_3__1 ;
    public final void rule__Stream__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2124:1: ( rule__Stream__Group_3__0__Impl rule__Stream__Group_3__1 )
            // InternalX21.g:2125:2: rule__Stream__Group_3__0__Impl rule__Stream__Group_3__1
            {
            pushFollow(FOLLOW_4);
            rule__Stream__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Stream__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group_3__0"


    // $ANTLR start "rule__Stream__Group_3__0__Impl"
    // InternalX21.g:2132:1: rule__Stream__Group_3__0__Impl : ( ',' ) ;
    public final void rule__Stream__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2136:1: ( ( ',' ) )
            // InternalX21.g:2137:1: ( ',' )
            {
            // InternalX21.g:2137:1: ( ',' )
            // InternalX21.g:2138:2: ','
            {
             before(grammarAccess.getStreamAccess().getCommaKeyword_3_0()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getStreamAccess().getCommaKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group_3__0__Impl"


    // $ANTLR start "rule__Stream__Group_3__1"
    // InternalX21.g:2147:1: rule__Stream__Group_3__1 : rule__Stream__Group_3__1__Impl ;
    public final void rule__Stream__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2151:1: ( rule__Stream__Group_3__1__Impl )
            // InternalX21.g:2152:2: rule__Stream__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Stream__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group_3__1"


    // $ANTLR start "rule__Stream__Group_3__1__Impl"
    // InternalX21.g:2158:1: rule__Stream__Group_3__1__Impl : ( ( rule__Stream__OriginsAssignment_3_1 ) ) ;
    public final void rule__Stream__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2162:1: ( ( ( rule__Stream__OriginsAssignment_3_1 ) ) )
            // InternalX21.g:2163:1: ( ( rule__Stream__OriginsAssignment_3_1 ) )
            {
            // InternalX21.g:2163:1: ( ( rule__Stream__OriginsAssignment_3_1 ) )
            // InternalX21.g:2164:2: ( rule__Stream__OriginsAssignment_3_1 )
            {
             before(grammarAccess.getStreamAccess().getOriginsAssignment_3_1()); 
            // InternalX21.g:2165:2: ( rule__Stream__OriginsAssignment_3_1 )
            // InternalX21.g:2165:3: rule__Stream__OriginsAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Stream__OriginsAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getStreamAccess().getOriginsAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__Group_3__1__Impl"


    // $ANTLR start "rule__Element__Group_0__0"
    // InternalX21.g:2174:1: rule__Element__Group_0__0 : rule__Element__Group_0__0__Impl rule__Element__Group_0__1 ;
    public final void rule__Element__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2178:1: ( rule__Element__Group_0__0__Impl rule__Element__Group_0__1 )
            // InternalX21.g:2179:2: rule__Element__Group_0__0__Impl rule__Element__Group_0__1
            {
            pushFollow(FOLLOW_4);
            rule__Element__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Element__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_0__0"


    // $ANTLR start "rule__Element__Group_0__0__Impl"
    // InternalX21.g:2186:1: rule__Element__Group_0__0__Impl : ( () ) ;
    public final void rule__Element__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2190:1: ( ( () ) )
            // InternalX21.g:2191:1: ( () )
            {
            // InternalX21.g:2191:1: ( () )
            // InternalX21.g:2192:2: ()
            {
             before(grammarAccess.getElementAccess().getElementAction_0_0()); 
            // InternalX21.g:2193:2: ()
            // InternalX21.g:2193:3: 
            {
            }

             after(grammarAccess.getElementAccess().getElementAction_0_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_0__0__Impl"


    // $ANTLR start "rule__Element__Group_0__1"
    // InternalX21.g:2201:1: rule__Element__Group_0__1 : rule__Element__Group_0__1__Impl ;
    public final void rule__Element__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2205:1: ( rule__Element__Group_0__1__Impl )
            // InternalX21.g:2206:2: rule__Element__Group_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Element__Group_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_0__1"


    // $ANTLR start "rule__Element__Group_0__1__Impl"
    // InternalX21.g:2212:1: rule__Element__Group_0__1__Impl : ( ( rule__Element__NodeAssignment_0_1 ) ) ;
    public final void rule__Element__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2216:1: ( ( ( rule__Element__NodeAssignment_0_1 ) ) )
            // InternalX21.g:2217:1: ( ( rule__Element__NodeAssignment_0_1 ) )
            {
            // InternalX21.g:2217:1: ( ( rule__Element__NodeAssignment_0_1 ) )
            // InternalX21.g:2218:2: ( rule__Element__NodeAssignment_0_1 )
            {
             before(grammarAccess.getElementAccess().getNodeAssignment_0_1()); 
            // InternalX21.g:2219:2: ( rule__Element__NodeAssignment_0_1 )
            // InternalX21.g:2219:3: rule__Element__NodeAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__Element__NodeAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getElementAccess().getNodeAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_0__1__Impl"


    // $ANTLR start "rule__Element__Group_1__0"
    // InternalX21.g:2228:1: rule__Element__Group_1__0 : rule__Element__Group_1__0__Impl rule__Element__Group_1__1 ;
    public final void rule__Element__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2232:1: ( rule__Element__Group_1__0__Impl rule__Element__Group_1__1 )
            // InternalX21.g:2233:2: rule__Element__Group_1__0__Impl rule__Element__Group_1__1
            {
            pushFollow(FOLLOW_14);
            rule__Element__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Element__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_1__0"


    // $ANTLR start "rule__Element__Group_1__0__Impl"
    // InternalX21.g:2240:1: rule__Element__Group_1__0__Impl : ( () ) ;
    public final void rule__Element__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2244:1: ( ( () ) )
            // InternalX21.g:2245:1: ( () )
            {
            // InternalX21.g:2245:1: ( () )
            // InternalX21.g:2246:2: ()
            {
             before(grammarAccess.getElementAccess().getElementAction_1_0()); 
            // InternalX21.g:2247:2: ()
            // InternalX21.g:2247:3: 
            {
            }

             after(grammarAccess.getElementAccess().getElementAction_1_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_1__0__Impl"


    // $ANTLR start "rule__Element__Group_1__1"
    // InternalX21.g:2255:1: rule__Element__Group_1__1 : rule__Element__Group_1__1__Impl rule__Element__Group_1__2 ;
    public final void rule__Element__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2259:1: ( rule__Element__Group_1__1__Impl rule__Element__Group_1__2 )
            // InternalX21.g:2260:2: rule__Element__Group_1__1__Impl rule__Element__Group_1__2
            {
            pushFollow(FOLLOW_15);
            rule__Element__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Element__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_1__1"


    // $ANTLR start "rule__Element__Group_1__1__Impl"
    // InternalX21.g:2267:1: rule__Element__Group_1__1__Impl : ( '[' ) ;
    public final void rule__Element__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2271:1: ( ( '[' ) )
            // InternalX21.g:2272:1: ( '[' )
            {
            // InternalX21.g:2272:1: ( '[' )
            // InternalX21.g:2273:2: '['
            {
             before(grammarAccess.getElementAccess().getLeftSquareBracketKeyword_1_1()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getElementAccess().getLeftSquareBracketKeyword_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_1__1__Impl"


    // $ANTLR start "rule__Element__Group_1__2"
    // InternalX21.g:2282:1: rule__Element__Group_1__2 : rule__Element__Group_1__2__Impl rule__Element__Group_1__3 ;
    public final void rule__Element__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2286:1: ( rule__Element__Group_1__2__Impl rule__Element__Group_1__3 )
            // InternalX21.g:2287:2: rule__Element__Group_1__2__Impl rule__Element__Group_1__3
            {
            pushFollow(FOLLOW_16);
            rule__Element__Group_1__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Element__Group_1__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_1__2"


    // $ANTLR start "rule__Element__Group_1__2__Impl"
    // InternalX21.g:2294:1: rule__Element__Group_1__2__Impl : ( ( rule__Element__Alternatives_1_2 ) ) ;
    public final void rule__Element__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2298:1: ( ( ( rule__Element__Alternatives_1_2 ) ) )
            // InternalX21.g:2299:1: ( ( rule__Element__Alternatives_1_2 ) )
            {
            // InternalX21.g:2299:1: ( ( rule__Element__Alternatives_1_2 ) )
            // InternalX21.g:2300:2: ( rule__Element__Alternatives_1_2 )
            {
             before(grammarAccess.getElementAccess().getAlternatives_1_2()); 
            // InternalX21.g:2301:2: ( rule__Element__Alternatives_1_2 )
            // InternalX21.g:2301:3: rule__Element__Alternatives_1_2
            {
            pushFollow(FOLLOW_2);
            rule__Element__Alternatives_1_2();

            state._fsp--;


            }

             after(grammarAccess.getElementAccess().getAlternatives_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_1__2__Impl"


    // $ANTLR start "rule__Element__Group_1__3"
    // InternalX21.g:2309:1: rule__Element__Group_1__3 : rule__Element__Group_1__3__Impl ;
    public final void rule__Element__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2313:1: ( rule__Element__Group_1__3__Impl )
            // InternalX21.g:2314:2: rule__Element__Group_1__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Element__Group_1__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_1__3"


    // $ANTLR start "rule__Element__Group_1__3__Impl"
    // InternalX21.g:2320:1: rule__Element__Group_1__3__Impl : ( ']' ) ;
    public final void rule__Element__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2324:1: ( ( ']' ) )
            // InternalX21.g:2325:1: ( ']' )
            {
            // InternalX21.g:2325:1: ( ']' )
            // InternalX21.g:2326:2: ']'
            {
             before(grammarAccess.getElementAccess().getRightSquareBracketKeyword_1_3()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getElementAccess().getRightSquareBracketKeyword_1_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_1__3__Impl"


    // $ANTLR start "rule__Element__Group_2__0"
    // InternalX21.g:2336:1: rule__Element__Group_2__0 : rule__Element__Group_2__0__Impl rule__Element__Group_2__1 ;
    public final void rule__Element__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2340:1: ( rule__Element__Group_2__0__Impl rule__Element__Group_2__1 )
            // InternalX21.g:2341:2: rule__Element__Group_2__0__Impl rule__Element__Group_2__1
            {
            pushFollow(FOLLOW_18);
            rule__Element__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Element__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_2__0"


    // $ANTLR start "rule__Element__Group_2__0__Impl"
    // InternalX21.g:2348:1: rule__Element__Group_2__0__Impl : ( () ) ;
    public final void rule__Element__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2352:1: ( ( () ) )
            // InternalX21.g:2353:1: ( () )
            {
            // InternalX21.g:2353:1: ( () )
            // InternalX21.g:2354:2: ()
            {
             before(grammarAccess.getElementAccess().getElementAction_2_0()); 
            // InternalX21.g:2355:2: ()
            // InternalX21.g:2355:3: 
            {
            }

             after(grammarAccess.getElementAccess().getElementAction_2_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_2__0__Impl"


    // $ANTLR start "rule__Element__Group_2__1"
    // InternalX21.g:2363:1: rule__Element__Group_2__1 : rule__Element__Group_2__1__Impl rule__Element__Group_2__2 ;
    public final void rule__Element__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2367:1: ( rule__Element__Group_2__1__Impl rule__Element__Group_2__2 )
            // InternalX21.g:2368:2: rule__Element__Group_2__1__Impl rule__Element__Group_2__2
            {
            pushFollow(FOLLOW_4);
            rule__Element__Group_2__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Element__Group_2__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_2__1"


    // $ANTLR start "rule__Element__Group_2__1__Impl"
    // InternalX21.g:2375:1: rule__Element__Group_2__1__Impl : ( 'output' ) ;
    public final void rule__Element__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2379:1: ( ( 'output' ) )
            // InternalX21.g:2380:1: ( 'output' )
            {
            // InternalX21.g:2380:1: ( 'output' )
            // InternalX21.g:2381:2: 'output'
            {
             before(grammarAccess.getElementAccess().getOutputKeyword_2_1()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getElementAccess().getOutputKeyword_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_2__1__Impl"


    // $ANTLR start "rule__Element__Group_2__2"
    // InternalX21.g:2390:1: rule__Element__Group_2__2 : rule__Element__Group_2__2__Impl ;
    public final void rule__Element__Group_2__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2394:1: ( rule__Element__Group_2__2__Impl )
            // InternalX21.g:2395:2: rule__Element__Group_2__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Element__Group_2__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_2__2"


    // $ANTLR start "rule__Element__Group_2__2__Impl"
    // InternalX21.g:2401:1: rule__Element__Group_2__2__Impl : ( ( rule__Element__OutputNameAssignment_2_2 ) ) ;
    public final void rule__Element__Group_2__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2405:1: ( ( ( rule__Element__OutputNameAssignment_2_2 ) ) )
            // InternalX21.g:2406:1: ( ( rule__Element__OutputNameAssignment_2_2 ) )
            {
            // InternalX21.g:2406:1: ( ( rule__Element__OutputNameAssignment_2_2 ) )
            // InternalX21.g:2407:2: ( rule__Element__OutputNameAssignment_2_2 )
            {
             before(grammarAccess.getElementAccess().getOutputNameAssignment_2_2()); 
            // InternalX21.g:2408:2: ( rule__Element__OutputNameAssignment_2_2 )
            // InternalX21.g:2408:3: rule__Element__OutputNameAssignment_2_2
            {
            pushFollow(FOLLOW_2);
            rule__Element__OutputNameAssignment_2_2();

            state._fsp--;


            }

             after(grammarAccess.getElementAccess().getOutputNameAssignment_2_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group_2__2__Impl"


    // $ANTLR start "rule__DataDecl__Group__0"
    // InternalX21.g:2417:1: rule__DataDecl__Group__0 : rule__DataDecl__Group__0__Impl rule__DataDecl__Group__1 ;
    public final void rule__DataDecl__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2421:1: ( rule__DataDecl__Group__0__Impl rule__DataDecl__Group__1 )
            // InternalX21.g:2422:2: rule__DataDecl__Group__0__Impl rule__DataDecl__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__DataDecl__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataDecl__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group__0"


    // $ANTLR start "rule__DataDecl__Group__0__Impl"
    // InternalX21.g:2429:1: rule__DataDecl__Group__0__Impl : ( 'data' ) ;
    public final void rule__DataDecl__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2433:1: ( ( 'data' ) )
            // InternalX21.g:2434:1: ( 'data' )
            {
            // InternalX21.g:2434:1: ( 'data' )
            // InternalX21.g:2435:2: 'data'
            {
             before(grammarAccess.getDataDeclAccess().getDataKeyword_0()); 
            match(input,32,FOLLOW_2); 
             after(grammarAccess.getDataDeclAccess().getDataKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group__0__Impl"


    // $ANTLR start "rule__DataDecl__Group__1"
    // InternalX21.g:2444:1: rule__DataDecl__Group__1 : rule__DataDecl__Group__1__Impl rule__DataDecl__Group__2 ;
    public final void rule__DataDecl__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2448:1: ( rule__DataDecl__Group__1__Impl rule__DataDecl__Group__2 )
            // InternalX21.g:2449:2: rule__DataDecl__Group__1__Impl rule__DataDecl__Group__2
            {
            pushFollow(FOLLOW_11);
            rule__DataDecl__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataDecl__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group__1"


    // $ANTLR start "rule__DataDecl__Group__1__Impl"
    // InternalX21.g:2456:1: rule__DataDecl__Group__1__Impl : ( ( rule__DataDecl__NameAssignment_1 ) ) ;
    public final void rule__DataDecl__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2460:1: ( ( ( rule__DataDecl__NameAssignment_1 ) ) )
            // InternalX21.g:2461:1: ( ( rule__DataDecl__NameAssignment_1 ) )
            {
            // InternalX21.g:2461:1: ( ( rule__DataDecl__NameAssignment_1 ) )
            // InternalX21.g:2462:2: ( rule__DataDecl__NameAssignment_1 )
            {
             before(grammarAccess.getDataDeclAccess().getNameAssignment_1()); 
            // InternalX21.g:2463:2: ( rule__DataDecl__NameAssignment_1 )
            // InternalX21.g:2463:3: rule__DataDecl__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__DataDecl__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getDataDeclAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group__1__Impl"


    // $ANTLR start "rule__DataDecl__Group__2"
    // InternalX21.g:2471:1: rule__DataDecl__Group__2 : rule__DataDecl__Group__2__Impl rule__DataDecl__Group__3 ;
    public final void rule__DataDecl__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2475:1: ( rule__DataDecl__Group__2__Impl rule__DataDecl__Group__3 )
            // InternalX21.g:2476:2: rule__DataDecl__Group__2__Impl rule__DataDecl__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__DataDecl__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataDecl__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group__2"


    // $ANTLR start "rule__DataDecl__Group__2__Impl"
    // InternalX21.g:2483:1: rule__DataDecl__Group__2__Impl : ( '{' ) ;
    public final void rule__DataDecl__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2487:1: ( ( '{' ) )
            // InternalX21.g:2488:1: ( '{' )
            {
            // InternalX21.g:2488:1: ( '{' )
            // InternalX21.g:2489:2: '{'
            {
             before(grammarAccess.getDataDeclAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getDataDeclAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group__2__Impl"


    // $ANTLR start "rule__DataDecl__Group__3"
    // InternalX21.g:2498:1: rule__DataDecl__Group__3 : rule__DataDecl__Group__3__Impl rule__DataDecl__Group__4 ;
    public final void rule__DataDecl__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2502:1: ( rule__DataDecl__Group__3__Impl rule__DataDecl__Group__4 )
            // InternalX21.g:2503:2: rule__DataDecl__Group__3__Impl rule__DataDecl__Group__4
            {
            pushFollow(FOLLOW_24);
            rule__DataDecl__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataDecl__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group__3"


    // $ANTLR start "rule__DataDecl__Group__3__Impl"
    // InternalX21.g:2510:1: rule__DataDecl__Group__3__Impl : ( ( rule__DataDecl__ParamsAssignment_3 ) ) ;
    public final void rule__DataDecl__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2514:1: ( ( ( rule__DataDecl__ParamsAssignment_3 ) ) )
            // InternalX21.g:2515:1: ( ( rule__DataDecl__ParamsAssignment_3 ) )
            {
            // InternalX21.g:2515:1: ( ( rule__DataDecl__ParamsAssignment_3 ) )
            // InternalX21.g:2516:2: ( rule__DataDecl__ParamsAssignment_3 )
            {
             before(grammarAccess.getDataDeclAccess().getParamsAssignment_3()); 
            // InternalX21.g:2517:2: ( rule__DataDecl__ParamsAssignment_3 )
            // InternalX21.g:2517:3: rule__DataDecl__ParamsAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__DataDecl__ParamsAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getDataDeclAccess().getParamsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group__3__Impl"


    // $ANTLR start "rule__DataDecl__Group__4"
    // InternalX21.g:2525:1: rule__DataDecl__Group__4 : rule__DataDecl__Group__4__Impl rule__DataDecl__Group__5 ;
    public final void rule__DataDecl__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2529:1: ( rule__DataDecl__Group__4__Impl rule__DataDecl__Group__5 )
            // InternalX21.g:2530:2: rule__DataDecl__Group__4__Impl rule__DataDecl__Group__5
            {
            pushFollow(FOLLOW_24);
            rule__DataDecl__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataDecl__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group__4"


    // $ANTLR start "rule__DataDecl__Group__4__Impl"
    // InternalX21.g:2537:1: rule__DataDecl__Group__4__Impl : ( ( rule__DataDecl__Group_4__0 )* ) ;
    public final void rule__DataDecl__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2541:1: ( ( ( rule__DataDecl__Group_4__0 )* ) )
            // InternalX21.g:2542:1: ( ( rule__DataDecl__Group_4__0 )* )
            {
            // InternalX21.g:2542:1: ( ( rule__DataDecl__Group_4__0 )* )
            // InternalX21.g:2543:2: ( rule__DataDecl__Group_4__0 )*
            {
             before(grammarAccess.getDataDeclAccess().getGroup_4()); 
            // InternalX21.g:2544:2: ( rule__DataDecl__Group_4__0 )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==29) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // InternalX21.g:2544:3: rule__DataDecl__Group_4__0
            	    {
            	    pushFollow(FOLLOW_20);
            	    rule__DataDecl__Group_4__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

             after(grammarAccess.getDataDeclAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group__4__Impl"


    // $ANTLR start "rule__DataDecl__Group__5"
    // InternalX21.g:2552:1: rule__DataDecl__Group__5 : rule__DataDecl__Group__5__Impl ;
    public final void rule__DataDecl__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2556:1: ( rule__DataDecl__Group__5__Impl )
            // InternalX21.g:2557:2: rule__DataDecl__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DataDecl__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group__5"


    // $ANTLR start "rule__DataDecl__Group__5__Impl"
    // InternalX21.g:2563:1: rule__DataDecl__Group__5__Impl : ( '}' ) ;
    public final void rule__DataDecl__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2567:1: ( ( '}' ) )
            // InternalX21.g:2568:1: ( '}' )
            {
            // InternalX21.g:2568:1: ( '}' )
            // InternalX21.g:2569:2: '}'
            {
             before(grammarAccess.getDataDeclAccess().getRightCurlyBracketKeyword_5()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getDataDeclAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group__5__Impl"


    // $ANTLR start "rule__DataDecl__Group_4__0"
    // InternalX21.g:2579:1: rule__DataDecl__Group_4__0 : rule__DataDecl__Group_4__0__Impl rule__DataDecl__Group_4__1 ;
    public final void rule__DataDecl__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2583:1: ( rule__DataDecl__Group_4__0__Impl rule__DataDecl__Group_4__1 )
            // InternalX21.g:2584:2: rule__DataDecl__Group_4__0__Impl rule__DataDecl__Group_4__1
            {
            pushFollow(FOLLOW_4);
            rule__DataDecl__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataDecl__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group_4__0"


    // $ANTLR start "rule__DataDecl__Group_4__0__Impl"
    // InternalX21.g:2591:1: rule__DataDecl__Group_4__0__Impl : ( ',' ) ;
    public final void rule__DataDecl__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2595:1: ( ( ',' ) )
            // InternalX21.g:2596:1: ( ',' )
            {
            // InternalX21.g:2596:1: ( ',' )
            // InternalX21.g:2597:2: ','
            {
             before(grammarAccess.getDataDeclAccess().getCommaKeyword_4_0()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getDataDeclAccess().getCommaKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group_4__0__Impl"


    // $ANTLR start "rule__DataDecl__Group_4__1"
    // InternalX21.g:2606:1: rule__DataDecl__Group_4__1 : rule__DataDecl__Group_4__1__Impl ;
    public final void rule__DataDecl__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2610:1: ( rule__DataDecl__Group_4__1__Impl )
            // InternalX21.g:2611:2: rule__DataDecl__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DataDecl__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group_4__1"


    // $ANTLR start "rule__DataDecl__Group_4__1__Impl"
    // InternalX21.g:2617:1: rule__DataDecl__Group_4__1__Impl : ( ( rule__DataDecl__ParamsAssignment_4_1 ) ) ;
    public final void rule__DataDecl__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2621:1: ( ( ( rule__DataDecl__ParamsAssignment_4_1 ) ) )
            // InternalX21.g:2622:1: ( ( rule__DataDecl__ParamsAssignment_4_1 ) )
            {
            // InternalX21.g:2622:1: ( ( rule__DataDecl__ParamsAssignment_4_1 ) )
            // InternalX21.g:2623:2: ( rule__DataDecl__ParamsAssignment_4_1 )
            {
             before(grammarAccess.getDataDeclAccess().getParamsAssignment_4_1()); 
            // InternalX21.g:2624:2: ( rule__DataDecl__ParamsAssignment_4_1 )
            // InternalX21.g:2624:3: rule__DataDecl__ParamsAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__DataDecl__ParamsAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getDataDeclAccess().getParamsAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__Group_4__1__Impl"


    // $ANTLR start "rule__Type__Group_0__0"
    // InternalX21.g:2633:1: rule__Type__Group_0__0 : rule__Type__Group_0__0__Impl rule__Type__Group_0__1 ;
    public final void rule__Type__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2637:1: ( rule__Type__Group_0__0__Impl rule__Type__Group_0__1 )
            // InternalX21.g:2638:2: rule__Type__Group_0__0__Impl rule__Type__Group_0__1
            {
            pushFollow(FOLLOW_25);
            rule__Type__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Type__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__Group_0__0"


    // $ANTLR start "rule__Type__Group_0__0__Impl"
    // InternalX21.g:2645:1: rule__Type__Group_0__0__Impl : ( () ) ;
    public final void rule__Type__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2649:1: ( ( () ) )
            // InternalX21.g:2650:1: ( () )
            {
            // InternalX21.g:2650:1: ( () )
            // InternalX21.g:2651:2: ()
            {
             before(grammarAccess.getTypeAccess().getTypeAction_0_0()); 
            // InternalX21.g:2652:2: ()
            // InternalX21.g:2652:3: 
            {
            }

             after(grammarAccess.getTypeAccess().getTypeAction_0_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__Group_0__0__Impl"


    // $ANTLR start "rule__Type__Group_0__1"
    // InternalX21.g:2660:1: rule__Type__Group_0__1 : rule__Type__Group_0__1__Impl ;
    public final void rule__Type__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2664:1: ( rule__Type__Group_0__1__Impl )
            // InternalX21.g:2665:2: rule__Type__Group_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Type__Group_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__Group_0__1"


    // $ANTLR start "rule__Type__Group_0__1__Impl"
    // InternalX21.g:2671:1: rule__Type__Group_0__1__Impl : ( ( rule__Type__TypeAssignment_0_1 ) ) ;
    public final void rule__Type__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2675:1: ( ( ( rule__Type__TypeAssignment_0_1 ) ) )
            // InternalX21.g:2676:1: ( ( rule__Type__TypeAssignment_0_1 ) )
            {
            // InternalX21.g:2676:1: ( ( rule__Type__TypeAssignment_0_1 ) )
            // InternalX21.g:2677:2: ( rule__Type__TypeAssignment_0_1 )
            {
             before(grammarAccess.getTypeAccess().getTypeAssignment_0_1()); 
            // InternalX21.g:2678:2: ( rule__Type__TypeAssignment_0_1 )
            // InternalX21.g:2678:3: rule__Type__TypeAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__Type__TypeAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getTypeAccess().getTypeAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__Group_0__1__Impl"


    // $ANTLR start "rule__Type__Group_1__0"
    // InternalX21.g:2687:1: rule__Type__Group_1__0 : rule__Type__Group_1__0__Impl rule__Type__Group_1__1 ;
    public final void rule__Type__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2691:1: ( rule__Type__Group_1__0__Impl rule__Type__Group_1__1 )
            // InternalX21.g:2692:2: rule__Type__Group_1__0__Impl rule__Type__Group_1__1
            {
            pushFollow(FOLLOW_26);
            rule__Type__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Type__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__Group_1__0"


    // $ANTLR start "rule__Type__Group_1__0__Impl"
    // InternalX21.g:2699:1: rule__Type__Group_1__0__Impl : ( () ) ;
    public final void rule__Type__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2703:1: ( ( () ) )
            // InternalX21.g:2704:1: ( () )
            {
            // InternalX21.g:2704:1: ( () )
            // InternalX21.g:2705:2: ()
            {
             before(grammarAccess.getTypeAccess().getTypeAction_1_0()); 
            // InternalX21.g:2706:2: ()
            // InternalX21.g:2706:3: 
            {
            }

             after(grammarAccess.getTypeAccess().getTypeAction_1_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__Group_1__0__Impl"


    // $ANTLR start "rule__Type__Group_1__1"
    // InternalX21.g:2714:1: rule__Type__Group_1__1 : rule__Type__Group_1__1__Impl ;
    public final void rule__Type__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2718:1: ( rule__Type__Group_1__1__Impl )
            // InternalX21.g:2719:2: rule__Type__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Type__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__Group_1__1"


    // $ANTLR start "rule__Type__Group_1__1__Impl"
    // InternalX21.g:2725:1: rule__Type__Group_1__1__Impl : ( ( rule__Type__TypeAssignment_1_1 ) ) ;
    public final void rule__Type__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2729:1: ( ( ( rule__Type__TypeAssignment_1_1 ) ) )
            // InternalX21.g:2730:1: ( ( rule__Type__TypeAssignment_1_1 ) )
            {
            // InternalX21.g:2730:1: ( ( rule__Type__TypeAssignment_1_1 ) )
            // InternalX21.g:2731:2: ( rule__Type__TypeAssignment_1_1 )
            {
             before(grammarAccess.getTypeAccess().getTypeAssignment_1_1()); 
            // InternalX21.g:2732:2: ( rule__Type__TypeAssignment_1_1 )
            // InternalX21.g:2732:3: rule__Type__TypeAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__Type__TypeAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getTypeAccess().getTypeAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__Group_1__1__Impl"


    // $ANTLR start "rule__SubAddExp__Group__0"
    // InternalX21.g:2741:1: rule__SubAddExp__Group__0 : rule__SubAddExp__Group__0__Impl rule__SubAddExp__Group__1 ;
    public final void rule__SubAddExp__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2745:1: ( rule__SubAddExp__Group__0__Impl rule__SubAddExp__Group__1 )
            // InternalX21.g:2746:2: rule__SubAddExp__Group__0__Impl rule__SubAddExp__Group__1
            {
            pushFollow(FOLLOW_27);
            rule__SubAddExp__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SubAddExp__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group__0"


    // $ANTLR start "rule__SubAddExp__Group__0__Impl"
    // InternalX21.g:2753:1: rule__SubAddExp__Group__0__Impl : ( ruleDivMultExp ) ;
    public final void rule__SubAddExp__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2757:1: ( ( ruleDivMultExp ) )
            // InternalX21.g:2758:1: ( ruleDivMultExp )
            {
            // InternalX21.g:2758:1: ( ruleDivMultExp )
            // InternalX21.g:2759:2: ruleDivMultExp
            {
             before(grammarAccess.getSubAddExpAccess().getDivMultExpParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleDivMultExp();

            state._fsp--;

             after(grammarAccess.getSubAddExpAccess().getDivMultExpParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group__0__Impl"


    // $ANTLR start "rule__SubAddExp__Group__1"
    // InternalX21.g:2768:1: rule__SubAddExp__Group__1 : rule__SubAddExp__Group__1__Impl ;
    public final void rule__SubAddExp__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2772:1: ( rule__SubAddExp__Group__1__Impl )
            // InternalX21.g:2773:2: rule__SubAddExp__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SubAddExp__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group__1"


    // $ANTLR start "rule__SubAddExp__Group__1__Impl"
    // InternalX21.g:2779:1: rule__SubAddExp__Group__1__Impl : ( ( rule__SubAddExp__Group_1__0 )* ) ;
    public final void rule__SubAddExp__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2783:1: ( ( ( rule__SubAddExp__Group_1__0 )* ) )
            // InternalX21.g:2784:1: ( ( rule__SubAddExp__Group_1__0 )* )
            {
            // InternalX21.g:2784:1: ( ( rule__SubAddExp__Group_1__0 )* )
            // InternalX21.g:2785:2: ( rule__SubAddExp__Group_1__0 )*
            {
             before(grammarAccess.getSubAddExpAccess().getGroup_1()); 
            // InternalX21.g:2786:2: ( rule__SubAddExp__Group_1__0 )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( ((LA15_0>=33 && LA15_0<=34)) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalX21.g:2786:3: rule__SubAddExp__Group_1__0
            	    {
            	    pushFollow(FOLLOW_28);
            	    rule__SubAddExp__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

             after(grammarAccess.getSubAddExpAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group__1__Impl"


    // $ANTLR start "rule__SubAddExp__Group_1__0"
    // InternalX21.g:2795:1: rule__SubAddExp__Group_1__0 : rule__SubAddExp__Group_1__0__Impl rule__SubAddExp__Group_1__1 ;
    public final void rule__SubAddExp__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2799:1: ( rule__SubAddExp__Group_1__0__Impl rule__SubAddExp__Group_1__1 )
            // InternalX21.g:2800:2: rule__SubAddExp__Group_1__0__Impl rule__SubAddExp__Group_1__1
            {
            pushFollow(FOLLOW_12);
            rule__SubAddExp__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SubAddExp__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group_1__0"


    // $ANTLR start "rule__SubAddExp__Group_1__0__Impl"
    // InternalX21.g:2807:1: rule__SubAddExp__Group_1__0__Impl : ( ( rule__SubAddExp__Alternatives_1_0 ) ) ;
    public final void rule__SubAddExp__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2811:1: ( ( ( rule__SubAddExp__Alternatives_1_0 ) ) )
            // InternalX21.g:2812:1: ( ( rule__SubAddExp__Alternatives_1_0 ) )
            {
            // InternalX21.g:2812:1: ( ( rule__SubAddExp__Alternatives_1_0 ) )
            // InternalX21.g:2813:2: ( rule__SubAddExp__Alternatives_1_0 )
            {
             before(grammarAccess.getSubAddExpAccess().getAlternatives_1_0()); 
            // InternalX21.g:2814:2: ( rule__SubAddExp__Alternatives_1_0 )
            // InternalX21.g:2814:3: rule__SubAddExp__Alternatives_1_0
            {
            pushFollow(FOLLOW_2);
            rule__SubAddExp__Alternatives_1_0();

            state._fsp--;


            }

             after(grammarAccess.getSubAddExpAccess().getAlternatives_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group_1__0__Impl"


    // $ANTLR start "rule__SubAddExp__Group_1__1"
    // InternalX21.g:2822:1: rule__SubAddExp__Group_1__1 : rule__SubAddExp__Group_1__1__Impl ;
    public final void rule__SubAddExp__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2826:1: ( rule__SubAddExp__Group_1__1__Impl )
            // InternalX21.g:2827:2: rule__SubAddExp__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SubAddExp__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group_1__1"


    // $ANTLR start "rule__SubAddExp__Group_1__1__Impl"
    // InternalX21.g:2833:1: rule__SubAddExp__Group_1__1__Impl : ( ( rule__SubAddExp__RightAssignment_1_1 ) ) ;
    public final void rule__SubAddExp__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2837:1: ( ( ( rule__SubAddExp__RightAssignment_1_1 ) ) )
            // InternalX21.g:2838:1: ( ( rule__SubAddExp__RightAssignment_1_1 ) )
            {
            // InternalX21.g:2838:1: ( ( rule__SubAddExp__RightAssignment_1_1 ) )
            // InternalX21.g:2839:2: ( rule__SubAddExp__RightAssignment_1_1 )
            {
             before(grammarAccess.getSubAddExpAccess().getRightAssignment_1_1()); 
            // InternalX21.g:2840:2: ( rule__SubAddExp__RightAssignment_1_1 )
            // InternalX21.g:2840:3: rule__SubAddExp__RightAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__SubAddExp__RightAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getSubAddExpAccess().getRightAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group_1__1__Impl"


    // $ANTLR start "rule__SubAddExp__Group_1_0_0__0"
    // InternalX21.g:2849:1: rule__SubAddExp__Group_1_0_0__0 : rule__SubAddExp__Group_1_0_0__0__Impl rule__SubAddExp__Group_1_0_0__1 ;
    public final void rule__SubAddExp__Group_1_0_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2853:1: ( rule__SubAddExp__Group_1_0_0__0__Impl rule__SubAddExp__Group_1_0_0__1 )
            // InternalX21.g:2854:2: rule__SubAddExp__Group_1_0_0__0__Impl rule__SubAddExp__Group_1_0_0__1
            {
            pushFollow(FOLLOW_1);
            rule__SubAddExp__Group_1_0_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SubAddExp__Group_1_0_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group_1_0_0__0"


    // $ANTLR start "rule__SubAddExp__Group_1_0_0__0__Impl"
    // InternalX21.g:2861:1: rule__SubAddExp__Group_1_0_0__0__Impl : ( '-' ) ;
    public final void rule__SubAddExp__Group_1_0_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2865:1: ( ( '-' ) )
            // InternalX21.g:2866:1: ( '-' )
            {
            // InternalX21.g:2866:1: ( '-' )
            // InternalX21.g:2867:2: '-'
            {
             before(grammarAccess.getSubAddExpAccess().getHyphenMinusKeyword_1_0_0_0()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getSubAddExpAccess().getHyphenMinusKeyword_1_0_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group_1_0_0__0__Impl"


    // $ANTLR start "rule__SubAddExp__Group_1_0_0__1"
    // InternalX21.g:2876:1: rule__SubAddExp__Group_1_0_0__1 : rule__SubAddExp__Group_1_0_0__1__Impl ;
    public final void rule__SubAddExp__Group_1_0_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2880:1: ( rule__SubAddExp__Group_1_0_0__1__Impl )
            // InternalX21.g:2881:2: rule__SubAddExp__Group_1_0_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SubAddExp__Group_1_0_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group_1_0_0__1"


    // $ANTLR start "rule__SubAddExp__Group_1_0_0__1__Impl"
    // InternalX21.g:2887:1: rule__SubAddExp__Group_1_0_0__1__Impl : ( () ) ;
    public final void rule__SubAddExp__Group_1_0_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2891:1: ( ( () ) )
            // InternalX21.g:2892:1: ( () )
            {
            // InternalX21.g:2892:1: ( () )
            // InternalX21.g:2893:2: ()
            {
             before(grammarAccess.getSubAddExpAccess().getSubtractionLeftAction_1_0_0_1()); 
            // InternalX21.g:2894:2: ()
            // InternalX21.g:2894:3: 
            {
            }

             after(grammarAccess.getSubAddExpAccess().getSubtractionLeftAction_1_0_0_1()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group_1_0_0__1__Impl"


    // $ANTLR start "rule__SubAddExp__Group_1_0_1__0"
    // InternalX21.g:2903:1: rule__SubAddExp__Group_1_0_1__0 : rule__SubAddExp__Group_1_0_1__0__Impl rule__SubAddExp__Group_1_0_1__1 ;
    public final void rule__SubAddExp__Group_1_0_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2907:1: ( rule__SubAddExp__Group_1_0_1__0__Impl rule__SubAddExp__Group_1_0_1__1 )
            // InternalX21.g:2908:2: rule__SubAddExp__Group_1_0_1__0__Impl rule__SubAddExp__Group_1_0_1__1
            {
            pushFollow(FOLLOW_1);
            rule__SubAddExp__Group_1_0_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SubAddExp__Group_1_0_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group_1_0_1__0"


    // $ANTLR start "rule__SubAddExp__Group_1_0_1__0__Impl"
    // InternalX21.g:2915:1: rule__SubAddExp__Group_1_0_1__0__Impl : ( '+' ) ;
    public final void rule__SubAddExp__Group_1_0_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2919:1: ( ( '+' ) )
            // InternalX21.g:2920:1: ( '+' )
            {
            // InternalX21.g:2920:1: ( '+' )
            // InternalX21.g:2921:2: '+'
            {
             before(grammarAccess.getSubAddExpAccess().getPlusSignKeyword_1_0_1_0()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getSubAddExpAccess().getPlusSignKeyword_1_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group_1_0_1__0__Impl"


    // $ANTLR start "rule__SubAddExp__Group_1_0_1__1"
    // InternalX21.g:2930:1: rule__SubAddExp__Group_1_0_1__1 : rule__SubAddExp__Group_1_0_1__1__Impl ;
    public final void rule__SubAddExp__Group_1_0_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2934:1: ( rule__SubAddExp__Group_1_0_1__1__Impl )
            // InternalX21.g:2935:2: rule__SubAddExp__Group_1_0_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SubAddExp__Group_1_0_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group_1_0_1__1"


    // $ANTLR start "rule__SubAddExp__Group_1_0_1__1__Impl"
    // InternalX21.g:2941:1: rule__SubAddExp__Group_1_0_1__1__Impl : ( () ) ;
    public final void rule__SubAddExp__Group_1_0_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2945:1: ( ( () ) )
            // InternalX21.g:2946:1: ( () )
            {
            // InternalX21.g:2946:1: ( () )
            // InternalX21.g:2947:2: ()
            {
             before(grammarAccess.getSubAddExpAccess().getAdditionLeftAction_1_0_1_1()); 
            // InternalX21.g:2948:2: ()
            // InternalX21.g:2948:3: 
            {
            }

             after(grammarAccess.getSubAddExpAccess().getAdditionLeftAction_1_0_1_1()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__Group_1_0_1__1__Impl"


    // $ANTLR start "rule__DivMultExp__Group__0"
    // InternalX21.g:2957:1: rule__DivMultExp__Group__0 : rule__DivMultExp__Group__0__Impl rule__DivMultExp__Group__1 ;
    public final void rule__DivMultExp__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2961:1: ( rule__DivMultExp__Group__0__Impl rule__DivMultExp__Group__1 )
            // InternalX21.g:2962:2: rule__DivMultExp__Group__0__Impl rule__DivMultExp__Group__1
            {
            pushFollow(FOLLOW_29);
            rule__DivMultExp__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DivMultExp__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group__0"


    // $ANTLR start "rule__DivMultExp__Group__0__Impl"
    // InternalX21.g:2969:1: rule__DivMultExp__Group__0__Impl : ( rulePrimary ) ;
    public final void rule__DivMultExp__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2973:1: ( ( rulePrimary ) )
            // InternalX21.g:2974:1: ( rulePrimary )
            {
            // InternalX21.g:2974:1: ( rulePrimary )
            // InternalX21.g:2975:2: rulePrimary
            {
             before(grammarAccess.getDivMultExpAccess().getPrimaryParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            rulePrimary();

            state._fsp--;

             after(grammarAccess.getDivMultExpAccess().getPrimaryParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group__0__Impl"


    // $ANTLR start "rule__DivMultExp__Group__1"
    // InternalX21.g:2984:1: rule__DivMultExp__Group__1 : rule__DivMultExp__Group__1__Impl ;
    public final void rule__DivMultExp__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2988:1: ( rule__DivMultExp__Group__1__Impl )
            // InternalX21.g:2989:2: rule__DivMultExp__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DivMultExp__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group__1"


    // $ANTLR start "rule__DivMultExp__Group__1__Impl"
    // InternalX21.g:2995:1: rule__DivMultExp__Group__1__Impl : ( ( rule__DivMultExp__Group_1__0 )* ) ;
    public final void rule__DivMultExp__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:2999:1: ( ( ( rule__DivMultExp__Group_1__0 )* ) )
            // InternalX21.g:3000:1: ( ( rule__DivMultExp__Group_1__0 )* )
            {
            // InternalX21.g:3000:1: ( ( rule__DivMultExp__Group_1__0 )* )
            // InternalX21.g:3001:2: ( rule__DivMultExp__Group_1__0 )*
            {
             before(grammarAccess.getDivMultExpAccess().getGroup_1()); 
            // InternalX21.g:3002:2: ( rule__DivMultExp__Group_1__0 )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( ((LA16_0>=35 && LA16_0<=36)) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // InternalX21.g:3002:3: rule__DivMultExp__Group_1__0
            	    {
            	    pushFollow(FOLLOW_30);
            	    rule__DivMultExp__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);

             after(grammarAccess.getDivMultExpAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group__1__Impl"


    // $ANTLR start "rule__DivMultExp__Group_1__0"
    // InternalX21.g:3011:1: rule__DivMultExp__Group_1__0 : rule__DivMultExp__Group_1__0__Impl rule__DivMultExp__Group_1__1 ;
    public final void rule__DivMultExp__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3015:1: ( rule__DivMultExp__Group_1__0__Impl rule__DivMultExp__Group_1__1 )
            // InternalX21.g:3016:2: rule__DivMultExp__Group_1__0__Impl rule__DivMultExp__Group_1__1
            {
            pushFollow(FOLLOW_12);
            rule__DivMultExp__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DivMultExp__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group_1__0"


    // $ANTLR start "rule__DivMultExp__Group_1__0__Impl"
    // InternalX21.g:3023:1: rule__DivMultExp__Group_1__0__Impl : ( ( rule__DivMultExp__Alternatives_1_0 ) ) ;
    public final void rule__DivMultExp__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3027:1: ( ( ( rule__DivMultExp__Alternatives_1_0 ) ) )
            // InternalX21.g:3028:1: ( ( rule__DivMultExp__Alternatives_1_0 ) )
            {
            // InternalX21.g:3028:1: ( ( rule__DivMultExp__Alternatives_1_0 ) )
            // InternalX21.g:3029:2: ( rule__DivMultExp__Alternatives_1_0 )
            {
             before(grammarAccess.getDivMultExpAccess().getAlternatives_1_0()); 
            // InternalX21.g:3030:2: ( rule__DivMultExp__Alternatives_1_0 )
            // InternalX21.g:3030:3: rule__DivMultExp__Alternatives_1_0
            {
            pushFollow(FOLLOW_2);
            rule__DivMultExp__Alternatives_1_0();

            state._fsp--;


            }

             after(grammarAccess.getDivMultExpAccess().getAlternatives_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group_1__0__Impl"


    // $ANTLR start "rule__DivMultExp__Group_1__1"
    // InternalX21.g:3038:1: rule__DivMultExp__Group_1__1 : rule__DivMultExp__Group_1__1__Impl ;
    public final void rule__DivMultExp__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3042:1: ( rule__DivMultExp__Group_1__1__Impl )
            // InternalX21.g:3043:2: rule__DivMultExp__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DivMultExp__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group_1__1"


    // $ANTLR start "rule__DivMultExp__Group_1__1__Impl"
    // InternalX21.g:3049:1: rule__DivMultExp__Group_1__1__Impl : ( ( rule__DivMultExp__RightAssignment_1_1 ) ) ;
    public final void rule__DivMultExp__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3053:1: ( ( ( rule__DivMultExp__RightAssignment_1_1 ) ) )
            // InternalX21.g:3054:1: ( ( rule__DivMultExp__RightAssignment_1_1 ) )
            {
            // InternalX21.g:3054:1: ( ( rule__DivMultExp__RightAssignment_1_1 ) )
            // InternalX21.g:3055:2: ( rule__DivMultExp__RightAssignment_1_1 )
            {
             before(grammarAccess.getDivMultExpAccess().getRightAssignment_1_1()); 
            // InternalX21.g:3056:2: ( rule__DivMultExp__RightAssignment_1_1 )
            // InternalX21.g:3056:3: rule__DivMultExp__RightAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__DivMultExp__RightAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getDivMultExpAccess().getRightAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group_1__1__Impl"


    // $ANTLR start "rule__DivMultExp__Group_1_0_0__0"
    // InternalX21.g:3065:1: rule__DivMultExp__Group_1_0_0__0 : rule__DivMultExp__Group_1_0_0__0__Impl rule__DivMultExp__Group_1_0_0__1 ;
    public final void rule__DivMultExp__Group_1_0_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3069:1: ( rule__DivMultExp__Group_1_0_0__0__Impl rule__DivMultExp__Group_1_0_0__1 )
            // InternalX21.g:3070:2: rule__DivMultExp__Group_1_0_0__0__Impl rule__DivMultExp__Group_1_0_0__1
            {
            pushFollow(FOLLOW_1);
            rule__DivMultExp__Group_1_0_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DivMultExp__Group_1_0_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group_1_0_0__0"


    // $ANTLR start "rule__DivMultExp__Group_1_0_0__0__Impl"
    // InternalX21.g:3077:1: rule__DivMultExp__Group_1_0_0__0__Impl : ( '/' ) ;
    public final void rule__DivMultExp__Group_1_0_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3081:1: ( ( '/' ) )
            // InternalX21.g:3082:1: ( '/' )
            {
            // InternalX21.g:3082:1: ( '/' )
            // InternalX21.g:3083:2: '/'
            {
             before(grammarAccess.getDivMultExpAccess().getSolidusKeyword_1_0_0_0()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getDivMultExpAccess().getSolidusKeyword_1_0_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group_1_0_0__0__Impl"


    // $ANTLR start "rule__DivMultExp__Group_1_0_0__1"
    // InternalX21.g:3092:1: rule__DivMultExp__Group_1_0_0__1 : rule__DivMultExp__Group_1_0_0__1__Impl ;
    public final void rule__DivMultExp__Group_1_0_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3096:1: ( rule__DivMultExp__Group_1_0_0__1__Impl )
            // InternalX21.g:3097:2: rule__DivMultExp__Group_1_0_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DivMultExp__Group_1_0_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group_1_0_0__1"


    // $ANTLR start "rule__DivMultExp__Group_1_0_0__1__Impl"
    // InternalX21.g:3103:1: rule__DivMultExp__Group_1_0_0__1__Impl : ( () ) ;
    public final void rule__DivMultExp__Group_1_0_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3107:1: ( ( () ) )
            // InternalX21.g:3108:1: ( () )
            {
            // InternalX21.g:3108:1: ( () )
            // InternalX21.g:3109:2: ()
            {
             before(grammarAccess.getDivMultExpAccess().getDivisionLeftAction_1_0_0_1()); 
            // InternalX21.g:3110:2: ()
            // InternalX21.g:3110:3: 
            {
            }

             after(grammarAccess.getDivMultExpAccess().getDivisionLeftAction_1_0_0_1()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group_1_0_0__1__Impl"


    // $ANTLR start "rule__DivMultExp__Group_1_0_1__0"
    // InternalX21.g:3119:1: rule__DivMultExp__Group_1_0_1__0 : rule__DivMultExp__Group_1_0_1__0__Impl rule__DivMultExp__Group_1_0_1__1 ;
    public final void rule__DivMultExp__Group_1_0_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3123:1: ( rule__DivMultExp__Group_1_0_1__0__Impl rule__DivMultExp__Group_1_0_1__1 )
            // InternalX21.g:3124:2: rule__DivMultExp__Group_1_0_1__0__Impl rule__DivMultExp__Group_1_0_1__1
            {
            pushFollow(FOLLOW_1);
            rule__DivMultExp__Group_1_0_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DivMultExp__Group_1_0_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group_1_0_1__0"


    // $ANTLR start "rule__DivMultExp__Group_1_0_1__0__Impl"
    // InternalX21.g:3131:1: rule__DivMultExp__Group_1_0_1__0__Impl : ( '*' ) ;
    public final void rule__DivMultExp__Group_1_0_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3135:1: ( ( '*' ) )
            // InternalX21.g:3136:1: ( '*' )
            {
            // InternalX21.g:3136:1: ( '*' )
            // InternalX21.g:3137:2: '*'
            {
             before(grammarAccess.getDivMultExpAccess().getAsteriskKeyword_1_0_1_0()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getDivMultExpAccess().getAsteriskKeyword_1_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group_1_0_1__0__Impl"


    // $ANTLR start "rule__DivMultExp__Group_1_0_1__1"
    // InternalX21.g:3146:1: rule__DivMultExp__Group_1_0_1__1 : rule__DivMultExp__Group_1_0_1__1__Impl ;
    public final void rule__DivMultExp__Group_1_0_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3150:1: ( rule__DivMultExp__Group_1_0_1__1__Impl )
            // InternalX21.g:3151:2: rule__DivMultExp__Group_1_0_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DivMultExp__Group_1_0_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group_1_0_1__1"


    // $ANTLR start "rule__DivMultExp__Group_1_0_1__1__Impl"
    // InternalX21.g:3157:1: rule__DivMultExp__Group_1_0_1__1__Impl : ( () ) ;
    public final void rule__DivMultExp__Group_1_0_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3161:1: ( ( () ) )
            // InternalX21.g:3162:1: ( () )
            {
            // InternalX21.g:3162:1: ( () )
            // InternalX21.g:3163:2: ()
            {
             before(grammarAccess.getDivMultExpAccess().getMultiplicationLeftAction_1_0_1_1()); 
            // InternalX21.g:3164:2: ()
            // InternalX21.g:3164:3: 
            {
            }

             after(grammarAccess.getDivMultExpAccess().getMultiplicationLeftAction_1_0_1_1()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__Group_1_0_1__1__Impl"


    // $ANTLR start "rule__None__Group__0"
    // InternalX21.g:3173:1: rule__None__Group__0 : rule__None__Group__0__Impl rule__None__Group__1 ;
    public final void rule__None__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3177:1: ( rule__None__Group__0__Impl rule__None__Group__1 )
            // InternalX21.g:3178:2: rule__None__Group__0__Impl rule__None__Group__1
            {
            pushFollow(FOLLOW_31);
            rule__None__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__None__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__None__Group__0"


    // $ANTLR start "rule__None__Group__0__Impl"
    // InternalX21.g:3185:1: rule__None__Group__0__Impl : ( () ) ;
    public final void rule__None__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3189:1: ( ( () ) )
            // InternalX21.g:3190:1: ( () )
            {
            // InternalX21.g:3190:1: ( () )
            // InternalX21.g:3191:2: ()
            {
             before(grammarAccess.getNoneAccess().getNoneAction_0()); 
            // InternalX21.g:3192:2: ()
            // InternalX21.g:3192:3: 
            {
            }

             after(grammarAccess.getNoneAccess().getNoneAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__None__Group__0__Impl"


    // $ANTLR start "rule__None__Group__1"
    // InternalX21.g:3200:1: rule__None__Group__1 : rule__None__Group__1__Impl ;
    public final void rule__None__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3204:1: ( rule__None__Group__1__Impl )
            // InternalX21.g:3205:2: rule__None__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__None__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__None__Group__1"


    // $ANTLR start "rule__None__Group__1__Impl"
    // InternalX21.g:3211:1: rule__None__Group__1__Impl : ( 'none' ) ;
    public final void rule__None__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3215:1: ( ( 'none' ) )
            // InternalX21.g:3216:1: ( 'none' )
            {
            // InternalX21.g:3216:1: ( 'none' )
            // InternalX21.g:3217:2: 'none'
            {
             before(grammarAccess.getNoneAccess().getNoneKeyword_1()); 
            match(input,37,FOLLOW_2); 
             after(grammarAccess.getNoneAccess().getNoneKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__None__Group__1__Impl"


    // $ANTLR start "rule__Ifstatement__Group__0"
    // InternalX21.g:3227:1: rule__Ifstatement__Group__0 : rule__Ifstatement__Group__0__Impl rule__Ifstatement__Group__1 ;
    public final void rule__Ifstatement__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3231:1: ( rule__Ifstatement__Group__0__Impl rule__Ifstatement__Group__1 )
            // InternalX21.g:3232:2: rule__Ifstatement__Group__0__Impl rule__Ifstatement__Group__1
            {
            pushFollow(FOLLOW_32);
            rule__Ifstatement__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ifstatement__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__0"


    // $ANTLR start "rule__Ifstatement__Group__0__Impl"
    // InternalX21.g:3239:1: rule__Ifstatement__Group__0__Impl : ( () ) ;
    public final void rule__Ifstatement__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3243:1: ( ( () ) )
            // InternalX21.g:3244:1: ( () )
            {
            // InternalX21.g:3244:1: ( () )
            // InternalX21.g:3245:2: ()
            {
             before(grammarAccess.getIfstatementAccess().getIfstatementAction_0()); 
            // InternalX21.g:3246:2: ()
            // InternalX21.g:3246:3: 
            {
            }

             after(grammarAccess.getIfstatementAccess().getIfstatementAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__0__Impl"


    // $ANTLR start "rule__Ifstatement__Group__1"
    // InternalX21.g:3254:1: rule__Ifstatement__Group__1 : rule__Ifstatement__Group__1__Impl rule__Ifstatement__Group__2 ;
    public final void rule__Ifstatement__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3258:1: ( rule__Ifstatement__Group__1__Impl rule__Ifstatement__Group__2 )
            // InternalX21.g:3259:2: rule__Ifstatement__Group__1__Impl rule__Ifstatement__Group__2
            {
            pushFollow(FOLLOW_12);
            rule__Ifstatement__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ifstatement__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__1"


    // $ANTLR start "rule__Ifstatement__Group__1__Impl"
    // InternalX21.g:3266:1: rule__Ifstatement__Group__1__Impl : ( 'if' ) ;
    public final void rule__Ifstatement__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3270:1: ( ( 'if' ) )
            // InternalX21.g:3271:1: ( 'if' )
            {
            // InternalX21.g:3271:1: ( 'if' )
            // InternalX21.g:3272:2: 'if'
            {
             before(grammarAccess.getIfstatementAccess().getIfKeyword_1()); 
            match(input,38,FOLLOW_2); 
             after(grammarAccess.getIfstatementAccess().getIfKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__1__Impl"


    // $ANTLR start "rule__Ifstatement__Group__2"
    // InternalX21.g:3281:1: rule__Ifstatement__Group__2 : rule__Ifstatement__Group__2__Impl rule__Ifstatement__Group__3 ;
    public final void rule__Ifstatement__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3285:1: ( rule__Ifstatement__Group__2__Impl rule__Ifstatement__Group__3 )
            // InternalX21.g:3286:2: rule__Ifstatement__Group__2__Impl rule__Ifstatement__Group__3
            {
            pushFollow(FOLLOW_33);
            rule__Ifstatement__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ifstatement__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__2"


    // $ANTLR start "rule__Ifstatement__Group__2__Impl"
    // InternalX21.g:3293:1: rule__Ifstatement__Group__2__Impl : ( ( rule__Ifstatement__LogicExpAssignment_2 ) ) ;
    public final void rule__Ifstatement__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3297:1: ( ( ( rule__Ifstatement__LogicExpAssignment_2 ) ) )
            // InternalX21.g:3298:1: ( ( rule__Ifstatement__LogicExpAssignment_2 ) )
            {
            // InternalX21.g:3298:1: ( ( rule__Ifstatement__LogicExpAssignment_2 ) )
            // InternalX21.g:3299:2: ( rule__Ifstatement__LogicExpAssignment_2 )
            {
             before(grammarAccess.getIfstatementAccess().getLogicExpAssignment_2()); 
            // InternalX21.g:3300:2: ( rule__Ifstatement__LogicExpAssignment_2 )
            // InternalX21.g:3300:3: rule__Ifstatement__LogicExpAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Ifstatement__LogicExpAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getIfstatementAccess().getLogicExpAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__2__Impl"


    // $ANTLR start "rule__Ifstatement__Group__3"
    // InternalX21.g:3308:1: rule__Ifstatement__Group__3 : rule__Ifstatement__Group__3__Impl rule__Ifstatement__Group__4 ;
    public final void rule__Ifstatement__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3312:1: ( rule__Ifstatement__Group__3__Impl rule__Ifstatement__Group__4 )
            // InternalX21.g:3313:2: rule__Ifstatement__Group__3__Impl rule__Ifstatement__Group__4
            {
            pushFollow(FOLLOW_12);
            rule__Ifstatement__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ifstatement__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__3"


    // $ANTLR start "rule__Ifstatement__Group__3__Impl"
    // InternalX21.g:3320:1: rule__Ifstatement__Group__3__Impl : ( 'then' ) ;
    public final void rule__Ifstatement__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3324:1: ( ( 'then' ) )
            // InternalX21.g:3325:1: ( 'then' )
            {
            // InternalX21.g:3325:1: ( 'then' )
            // InternalX21.g:3326:2: 'then'
            {
             before(grammarAccess.getIfstatementAccess().getThenKeyword_3()); 
            match(input,39,FOLLOW_2); 
             after(grammarAccess.getIfstatementAccess().getThenKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__3__Impl"


    // $ANTLR start "rule__Ifstatement__Group__4"
    // InternalX21.g:3335:1: rule__Ifstatement__Group__4 : rule__Ifstatement__Group__4__Impl rule__Ifstatement__Group__5 ;
    public final void rule__Ifstatement__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3339:1: ( rule__Ifstatement__Group__4__Impl rule__Ifstatement__Group__5 )
            // InternalX21.g:3340:2: rule__Ifstatement__Group__4__Impl rule__Ifstatement__Group__5
            {
            pushFollow(FOLLOW_34);
            rule__Ifstatement__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ifstatement__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__4"


    // $ANTLR start "rule__Ifstatement__Group__4__Impl"
    // InternalX21.g:3347:1: rule__Ifstatement__Group__4__Impl : ( ( rule__Ifstatement__ExpAssignment_4 ) ) ;
    public final void rule__Ifstatement__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3351:1: ( ( ( rule__Ifstatement__ExpAssignment_4 ) ) )
            // InternalX21.g:3352:1: ( ( rule__Ifstatement__ExpAssignment_4 ) )
            {
            // InternalX21.g:3352:1: ( ( rule__Ifstatement__ExpAssignment_4 ) )
            // InternalX21.g:3353:2: ( rule__Ifstatement__ExpAssignment_4 )
            {
             before(grammarAccess.getIfstatementAccess().getExpAssignment_4()); 
            // InternalX21.g:3354:2: ( rule__Ifstatement__ExpAssignment_4 )
            // InternalX21.g:3354:3: rule__Ifstatement__ExpAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Ifstatement__ExpAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getIfstatementAccess().getExpAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__4__Impl"


    // $ANTLR start "rule__Ifstatement__Group__5"
    // InternalX21.g:3362:1: rule__Ifstatement__Group__5 : rule__Ifstatement__Group__5__Impl rule__Ifstatement__Group__6 ;
    public final void rule__Ifstatement__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3366:1: ( rule__Ifstatement__Group__5__Impl rule__Ifstatement__Group__6 )
            // InternalX21.g:3367:2: rule__Ifstatement__Group__5__Impl rule__Ifstatement__Group__6
            {
            pushFollow(FOLLOW_12);
            rule__Ifstatement__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ifstatement__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__5"


    // $ANTLR start "rule__Ifstatement__Group__5__Impl"
    // InternalX21.g:3374:1: rule__Ifstatement__Group__5__Impl : ( 'else' ) ;
    public final void rule__Ifstatement__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3378:1: ( ( 'else' ) )
            // InternalX21.g:3379:1: ( 'else' )
            {
            // InternalX21.g:3379:1: ( 'else' )
            // InternalX21.g:3380:2: 'else'
            {
             before(grammarAccess.getIfstatementAccess().getElseKeyword_5()); 
            match(input,40,FOLLOW_2); 
             after(grammarAccess.getIfstatementAccess().getElseKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__5__Impl"


    // $ANTLR start "rule__Ifstatement__Group__6"
    // InternalX21.g:3389:1: rule__Ifstatement__Group__6 : rule__Ifstatement__Group__6__Impl rule__Ifstatement__Group__7 ;
    public final void rule__Ifstatement__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3393:1: ( rule__Ifstatement__Group__6__Impl rule__Ifstatement__Group__7 )
            // InternalX21.g:3394:2: rule__Ifstatement__Group__6__Impl rule__Ifstatement__Group__7
            {
            pushFollow(FOLLOW_35);
            rule__Ifstatement__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ifstatement__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__6"


    // $ANTLR start "rule__Ifstatement__Group__6__Impl"
    // InternalX21.g:3401:1: rule__Ifstatement__Group__6__Impl : ( ( rule__Ifstatement__ElseExpAssignment_6 ) ) ;
    public final void rule__Ifstatement__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3405:1: ( ( ( rule__Ifstatement__ElseExpAssignment_6 ) ) )
            // InternalX21.g:3406:1: ( ( rule__Ifstatement__ElseExpAssignment_6 ) )
            {
            // InternalX21.g:3406:1: ( ( rule__Ifstatement__ElseExpAssignment_6 ) )
            // InternalX21.g:3407:2: ( rule__Ifstatement__ElseExpAssignment_6 )
            {
             before(grammarAccess.getIfstatementAccess().getElseExpAssignment_6()); 
            // InternalX21.g:3408:2: ( rule__Ifstatement__ElseExpAssignment_6 )
            // InternalX21.g:3408:3: rule__Ifstatement__ElseExpAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__Ifstatement__ElseExpAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getIfstatementAccess().getElseExpAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__6__Impl"


    // $ANTLR start "rule__Ifstatement__Group__7"
    // InternalX21.g:3416:1: rule__Ifstatement__Group__7 : rule__Ifstatement__Group__7__Impl ;
    public final void rule__Ifstatement__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3420:1: ( rule__Ifstatement__Group__7__Impl )
            // InternalX21.g:3421:2: rule__Ifstatement__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Ifstatement__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__7"


    // $ANTLR start "rule__Ifstatement__Group__7__Impl"
    // InternalX21.g:3427:1: rule__Ifstatement__Group__7__Impl : ( 'end' ) ;
    public final void rule__Ifstatement__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3431:1: ( ( 'end' ) )
            // InternalX21.g:3432:1: ( 'end' )
            {
            // InternalX21.g:3432:1: ( 'end' )
            // InternalX21.g:3433:2: 'end'
            {
             before(grammarAccess.getIfstatementAccess().getEndKeyword_7()); 
            match(input,41,FOLLOW_2); 
             after(grammarAccess.getIfstatementAccess().getEndKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__Group__7__Impl"


    // $ANTLR start "rule__Parenthesis__Group__0"
    // InternalX21.g:3443:1: rule__Parenthesis__Group__0 : rule__Parenthesis__Group__0__Impl rule__Parenthesis__Group__1 ;
    public final void rule__Parenthesis__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3447:1: ( rule__Parenthesis__Group__0__Impl rule__Parenthesis__Group__1 )
            // InternalX21.g:3448:2: rule__Parenthesis__Group__0__Impl rule__Parenthesis__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__Parenthesis__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Parenthesis__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parenthesis__Group__0"


    // $ANTLR start "rule__Parenthesis__Group__0__Impl"
    // InternalX21.g:3455:1: rule__Parenthesis__Group__0__Impl : ( () ) ;
    public final void rule__Parenthesis__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3459:1: ( ( () ) )
            // InternalX21.g:3460:1: ( () )
            {
            // InternalX21.g:3460:1: ( () )
            // InternalX21.g:3461:2: ()
            {
             before(grammarAccess.getParenthesisAccess().getParenthesisAction_0()); 
            // InternalX21.g:3462:2: ()
            // InternalX21.g:3462:3: 
            {
            }

             after(grammarAccess.getParenthesisAccess().getParenthesisAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parenthesis__Group__0__Impl"


    // $ANTLR start "rule__Parenthesis__Group__1"
    // InternalX21.g:3470:1: rule__Parenthesis__Group__1 : rule__Parenthesis__Group__1__Impl rule__Parenthesis__Group__2 ;
    public final void rule__Parenthesis__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3474:1: ( rule__Parenthesis__Group__1__Impl rule__Parenthesis__Group__2 )
            // InternalX21.g:3475:2: rule__Parenthesis__Group__1__Impl rule__Parenthesis__Group__2
            {
            pushFollow(FOLLOW_12);
            rule__Parenthesis__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Parenthesis__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parenthesis__Group__1"


    // $ANTLR start "rule__Parenthesis__Group__1__Impl"
    // InternalX21.g:3482:1: rule__Parenthesis__Group__1__Impl : ( '(' ) ;
    public final void rule__Parenthesis__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3486:1: ( ( '(' ) )
            // InternalX21.g:3487:1: ( '(' )
            {
            // InternalX21.g:3487:1: ( '(' )
            // InternalX21.g:3488:2: '('
            {
             before(grammarAccess.getParenthesisAccess().getLeftParenthesisKeyword_1()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getParenthesisAccess().getLeftParenthesisKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parenthesis__Group__1__Impl"


    // $ANTLR start "rule__Parenthesis__Group__2"
    // InternalX21.g:3497:1: rule__Parenthesis__Group__2 : rule__Parenthesis__Group__2__Impl rule__Parenthesis__Group__3 ;
    public final void rule__Parenthesis__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3501:1: ( rule__Parenthesis__Group__2__Impl rule__Parenthesis__Group__3 )
            // InternalX21.g:3502:2: rule__Parenthesis__Group__2__Impl rule__Parenthesis__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__Parenthesis__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Parenthesis__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parenthesis__Group__2"


    // $ANTLR start "rule__Parenthesis__Group__2__Impl"
    // InternalX21.g:3509:1: rule__Parenthesis__Group__2__Impl : ( ( rule__Parenthesis__InnerAssignment_2 ) ) ;
    public final void rule__Parenthesis__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3513:1: ( ( ( rule__Parenthesis__InnerAssignment_2 ) ) )
            // InternalX21.g:3514:1: ( ( rule__Parenthesis__InnerAssignment_2 ) )
            {
            // InternalX21.g:3514:1: ( ( rule__Parenthesis__InnerAssignment_2 ) )
            // InternalX21.g:3515:2: ( rule__Parenthesis__InnerAssignment_2 )
            {
             before(grammarAccess.getParenthesisAccess().getInnerAssignment_2()); 
            // InternalX21.g:3516:2: ( rule__Parenthesis__InnerAssignment_2 )
            // InternalX21.g:3516:3: rule__Parenthesis__InnerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Parenthesis__InnerAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getParenthesisAccess().getInnerAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parenthesis__Group__2__Impl"


    // $ANTLR start "rule__Parenthesis__Group__3"
    // InternalX21.g:3524:1: rule__Parenthesis__Group__3 : rule__Parenthesis__Group__3__Impl ;
    public final void rule__Parenthesis__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3528:1: ( rule__Parenthesis__Group__3__Impl )
            // InternalX21.g:3529:2: rule__Parenthesis__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Parenthesis__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parenthesis__Group__3"


    // $ANTLR start "rule__Parenthesis__Group__3__Impl"
    // InternalX21.g:3535:1: rule__Parenthesis__Group__3__Impl : ( ')' ) ;
    public final void rule__Parenthesis__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3539:1: ( ( ')' ) )
            // InternalX21.g:3540:1: ( ')' )
            {
            // InternalX21.g:3540:1: ( ')' )
            // InternalX21.g:3541:2: ')'
            {
             before(grammarAccess.getParenthesisAccess().getRightParenthesisKeyword_3()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getParenthesisAccess().getRightParenthesisKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parenthesis__Group__3__Impl"


    // $ANTLR start "rule__Number__Group__0"
    // InternalX21.g:3551:1: rule__Number__Group__0 : rule__Number__Group__0__Impl rule__Number__Group__1 ;
    public final void rule__Number__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3555:1: ( rule__Number__Group__0__Impl rule__Number__Group__1 )
            // InternalX21.g:3556:2: rule__Number__Group__0__Impl rule__Number__Group__1
            {
            pushFollow(FOLLOW_36);
            rule__Number__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Number__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Number__Group__0"


    // $ANTLR start "rule__Number__Group__0__Impl"
    // InternalX21.g:3563:1: rule__Number__Group__0__Impl : ( () ) ;
    public final void rule__Number__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3567:1: ( ( () ) )
            // InternalX21.g:3568:1: ( () )
            {
            // InternalX21.g:3568:1: ( () )
            // InternalX21.g:3569:2: ()
            {
             before(grammarAccess.getNumberAccess().getNumberAction_0()); 
            // InternalX21.g:3570:2: ()
            // InternalX21.g:3570:3: 
            {
            }

             after(grammarAccess.getNumberAccess().getNumberAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Number__Group__0__Impl"


    // $ANTLR start "rule__Number__Group__1"
    // InternalX21.g:3578:1: rule__Number__Group__1 : rule__Number__Group__1__Impl ;
    public final void rule__Number__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3582:1: ( rule__Number__Group__1__Impl )
            // InternalX21.g:3583:2: rule__Number__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Number__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Number__Group__1"


    // $ANTLR start "rule__Number__Group__1__Impl"
    // InternalX21.g:3589:1: rule__Number__Group__1__Impl : ( ( rule__Number__ValueAssignment_1 ) ) ;
    public final void rule__Number__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3593:1: ( ( ( rule__Number__ValueAssignment_1 ) ) )
            // InternalX21.g:3594:1: ( ( rule__Number__ValueAssignment_1 ) )
            {
            // InternalX21.g:3594:1: ( ( rule__Number__ValueAssignment_1 ) )
            // InternalX21.g:3595:2: ( rule__Number__ValueAssignment_1 )
            {
             before(grammarAccess.getNumberAccess().getValueAssignment_1()); 
            // InternalX21.g:3596:2: ( rule__Number__ValueAssignment_1 )
            // InternalX21.g:3596:3: rule__Number__ValueAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Number__ValueAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getNumberAccess().getValueAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Number__Group__1__Impl"


    // $ANTLR start "rule__Let__Group__0"
    // InternalX21.g:3605:1: rule__Let__Group__0 : rule__Let__Group__0__Impl rule__Let__Group__1 ;
    public final void rule__Let__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3609:1: ( rule__Let__Group__0__Impl rule__Let__Group__1 )
            // InternalX21.g:3610:2: rule__Let__Group__0__Impl rule__Let__Group__1
            {
            pushFollow(FOLLOW_37);
            rule__Let__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Let__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__0"


    // $ANTLR start "rule__Let__Group__0__Impl"
    // InternalX21.g:3617:1: rule__Let__Group__0__Impl : ( () ) ;
    public final void rule__Let__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3621:1: ( ( () ) )
            // InternalX21.g:3622:1: ( () )
            {
            // InternalX21.g:3622:1: ( () )
            // InternalX21.g:3623:2: ()
            {
             before(grammarAccess.getLetAccess().getLetAction_0()); 
            // InternalX21.g:3624:2: ()
            // InternalX21.g:3624:3: 
            {
            }

             after(grammarAccess.getLetAccess().getLetAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__0__Impl"


    // $ANTLR start "rule__Let__Group__1"
    // InternalX21.g:3632:1: rule__Let__Group__1 : rule__Let__Group__1__Impl rule__Let__Group__2 ;
    public final void rule__Let__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3636:1: ( rule__Let__Group__1__Impl rule__Let__Group__2 )
            // InternalX21.g:3637:2: rule__Let__Group__1__Impl rule__Let__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Let__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Let__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__1"


    // $ANTLR start "rule__Let__Group__1__Impl"
    // InternalX21.g:3644:1: rule__Let__Group__1__Impl : ( 'let' ) ;
    public final void rule__Let__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3648:1: ( ( 'let' ) )
            // InternalX21.g:3649:1: ( 'let' )
            {
            // InternalX21.g:3649:1: ( 'let' )
            // InternalX21.g:3650:2: 'let'
            {
             before(grammarAccess.getLetAccess().getLetKeyword_1()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getLetAccess().getLetKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__1__Impl"


    // $ANTLR start "rule__Let__Group__2"
    // InternalX21.g:3659:1: rule__Let__Group__2 : rule__Let__Group__2__Impl rule__Let__Group__3 ;
    public final void rule__Let__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3663:1: ( rule__Let__Group__2__Impl rule__Let__Group__3 )
            // InternalX21.g:3664:2: rule__Let__Group__2__Impl rule__Let__Group__3
            {
            pushFollow(FOLLOW_38);
            rule__Let__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Let__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__2"


    // $ANTLR start "rule__Let__Group__2__Impl"
    // InternalX21.g:3671:1: rule__Let__Group__2__Impl : ( ( rule__Let__NameAssignment_2 ) ) ;
    public final void rule__Let__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3675:1: ( ( ( rule__Let__NameAssignment_2 ) ) )
            // InternalX21.g:3676:1: ( ( rule__Let__NameAssignment_2 ) )
            {
            // InternalX21.g:3676:1: ( ( rule__Let__NameAssignment_2 ) )
            // InternalX21.g:3677:2: ( rule__Let__NameAssignment_2 )
            {
             before(grammarAccess.getLetAccess().getNameAssignment_2()); 
            // InternalX21.g:3678:2: ( rule__Let__NameAssignment_2 )
            // InternalX21.g:3678:3: rule__Let__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Let__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getLetAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__2__Impl"


    // $ANTLR start "rule__Let__Group__3"
    // InternalX21.g:3686:1: rule__Let__Group__3 : rule__Let__Group__3__Impl rule__Let__Group__4 ;
    public final void rule__Let__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3690:1: ( rule__Let__Group__3__Impl rule__Let__Group__4 )
            // InternalX21.g:3691:2: rule__Let__Group__3__Impl rule__Let__Group__4
            {
            pushFollow(FOLLOW_12);
            rule__Let__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Let__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__3"


    // $ANTLR start "rule__Let__Group__3__Impl"
    // InternalX21.g:3698:1: rule__Let__Group__3__Impl : ( '=' ) ;
    public final void rule__Let__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3702:1: ( ( '=' ) )
            // InternalX21.g:3703:1: ( '=' )
            {
            // InternalX21.g:3703:1: ( '=' )
            // InternalX21.g:3704:2: '='
            {
             before(grammarAccess.getLetAccess().getEqualsSignKeyword_3()); 
            match(input,11,FOLLOW_2); 
             after(grammarAccess.getLetAccess().getEqualsSignKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__3__Impl"


    // $ANTLR start "rule__Let__Group__4"
    // InternalX21.g:3713:1: rule__Let__Group__4 : rule__Let__Group__4__Impl rule__Let__Group__5 ;
    public final void rule__Let__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3717:1: ( rule__Let__Group__4__Impl rule__Let__Group__5 )
            // InternalX21.g:3718:2: rule__Let__Group__4__Impl rule__Let__Group__5
            {
            pushFollow(FOLLOW_39);
            rule__Let__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Let__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__4"


    // $ANTLR start "rule__Let__Group__4__Impl"
    // InternalX21.g:3725:1: rule__Let__Group__4__Impl : ( ( rule__Let__DefAssignment_4 ) ) ;
    public final void rule__Let__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3729:1: ( ( ( rule__Let__DefAssignment_4 ) ) )
            // InternalX21.g:3730:1: ( ( rule__Let__DefAssignment_4 ) )
            {
            // InternalX21.g:3730:1: ( ( rule__Let__DefAssignment_4 ) )
            // InternalX21.g:3731:2: ( rule__Let__DefAssignment_4 )
            {
             before(grammarAccess.getLetAccess().getDefAssignment_4()); 
            // InternalX21.g:3732:2: ( rule__Let__DefAssignment_4 )
            // InternalX21.g:3732:3: rule__Let__DefAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Let__DefAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getLetAccess().getDefAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__4__Impl"


    // $ANTLR start "rule__Let__Group__5"
    // InternalX21.g:3740:1: rule__Let__Group__5 : rule__Let__Group__5__Impl rule__Let__Group__6 ;
    public final void rule__Let__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3744:1: ( rule__Let__Group__5__Impl rule__Let__Group__6 )
            // InternalX21.g:3745:2: rule__Let__Group__5__Impl rule__Let__Group__6
            {
            pushFollow(FOLLOW_12);
            rule__Let__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Let__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__5"


    // $ANTLR start "rule__Let__Group__5__Impl"
    // InternalX21.g:3752:1: rule__Let__Group__5__Impl : ( 'in' ) ;
    public final void rule__Let__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3756:1: ( ( 'in' ) )
            // InternalX21.g:3757:1: ( 'in' )
            {
            // InternalX21.g:3757:1: ( 'in' )
            // InternalX21.g:3758:2: 'in'
            {
             before(grammarAccess.getLetAccess().getInKeyword_5()); 
            match(input,43,FOLLOW_2); 
             after(grammarAccess.getLetAccess().getInKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__5__Impl"


    // $ANTLR start "rule__Let__Group__6"
    // InternalX21.g:3767:1: rule__Let__Group__6 : rule__Let__Group__6__Impl rule__Let__Group__7 ;
    public final void rule__Let__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3771:1: ( rule__Let__Group__6__Impl rule__Let__Group__7 )
            // InternalX21.g:3772:2: rule__Let__Group__6__Impl rule__Let__Group__7
            {
            pushFollow(FOLLOW_35);
            rule__Let__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Let__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__6"


    // $ANTLR start "rule__Let__Group__6__Impl"
    // InternalX21.g:3779:1: rule__Let__Group__6__Impl : ( ( rule__Let__BodyAssignment_6 ) ) ;
    public final void rule__Let__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3783:1: ( ( ( rule__Let__BodyAssignment_6 ) ) )
            // InternalX21.g:3784:1: ( ( rule__Let__BodyAssignment_6 ) )
            {
            // InternalX21.g:3784:1: ( ( rule__Let__BodyAssignment_6 ) )
            // InternalX21.g:3785:2: ( rule__Let__BodyAssignment_6 )
            {
             before(grammarAccess.getLetAccess().getBodyAssignment_6()); 
            // InternalX21.g:3786:2: ( rule__Let__BodyAssignment_6 )
            // InternalX21.g:3786:3: rule__Let__BodyAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__Let__BodyAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getLetAccess().getBodyAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__6__Impl"


    // $ANTLR start "rule__Let__Group__7"
    // InternalX21.g:3794:1: rule__Let__Group__7 : rule__Let__Group__7__Impl ;
    public final void rule__Let__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3798:1: ( rule__Let__Group__7__Impl )
            // InternalX21.g:3799:2: rule__Let__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Let__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__7"


    // $ANTLR start "rule__Let__Group__7__Impl"
    // InternalX21.g:3805:1: rule__Let__Group__7__Impl : ( 'end' ) ;
    public final void rule__Let__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3809:1: ( ( 'end' ) )
            // InternalX21.g:3810:1: ( 'end' )
            {
            // InternalX21.g:3810:1: ( 'end' )
            // InternalX21.g:3811:2: 'end'
            {
             before(grammarAccess.getLetAccess().getEndKeyword_7()); 
            match(input,41,FOLLOW_2); 
             after(grammarAccess.getLetAccess().getEndKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__Group__7__Impl"


    // $ANTLR start "rule__VariableAssignment__Group__0"
    // InternalX21.g:3821:1: rule__VariableAssignment__Group__0 : rule__VariableAssignment__Group__0__Impl rule__VariableAssignment__Group__1 ;
    public final void rule__VariableAssignment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3825:1: ( rule__VariableAssignment__Group__0__Impl rule__VariableAssignment__Group__1 )
            // InternalX21.g:3826:2: rule__VariableAssignment__Group__0__Impl rule__VariableAssignment__Group__1
            {
            pushFollow(FOLLOW_40);
            rule__VariableAssignment__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__0"


    // $ANTLR start "rule__VariableAssignment__Group__0__Impl"
    // InternalX21.g:3833:1: rule__VariableAssignment__Group__0__Impl : ( () ) ;
    public final void rule__VariableAssignment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3837:1: ( ( () ) )
            // InternalX21.g:3838:1: ( () )
            {
            // InternalX21.g:3838:1: ( () )
            // InternalX21.g:3839:2: ()
            {
             before(grammarAccess.getVariableAssignmentAccess().getVariableAssignmentAction_0()); 
            // InternalX21.g:3840:2: ()
            // InternalX21.g:3840:3: 
            {
            }

             after(grammarAccess.getVariableAssignmentAccess().getVariableAssignmentAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__0__Impl"


    // $ANTLR start "rule__VariableAssignment__Group__1"
    // InternalX21.g:3848:1: rule__VariableAssignment__Group__1 : rule__VariableAssignment__Group__1__Impl rule__VariableAssignment__Group__2 ;
    public final void rule__VariableAssignment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3852:1: ( rule__VariableAssignment__Group__1__Impl rule__VariableAssignment__Group__2 )
            // InternalX21.g:3853:2: rule__VariableAssignment__Group__1__Impl rule__VariableAssignment__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__VariableAssignment__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__1"


    // $ANTLR start "rule__VariableAssignment__Group__1__Impl"
    // InternalX21.g:3860:1: rule__VariableAssignment__Group__1__Impl : ( 'new' ) ;
    public final void rule__VariableAssignment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3864:1: ( ( 'new' ) )
            // InternalX21.g:3865:1: ( 'new' )
            {
            // InternalX21.g:3865:1: ( 'new' )
            // InternalX21.g:3866:2: 'new'
            {
             before(grammarAccess.getVariableAssignmentAccess().getNewKeyword_1()); 
            match(input,44,FOLLOW_2); 
             after(grammarAccess.getVariableAssignmentAccess().getNewKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__1__Impl"


    // $ANTLR start "rule__VariableAssignment__Group__2"
    // InternalX21.g:3875:1: rule__VariableAssignment__Group__2 : rule__VariableAssignment__Group__2__Impl rule__VariableAssignment__Group__3 ;
    public final void rule__VariableAssignment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3879:1: ( rule__VariableAssignment__Group__2__Impl rule__VariableAssignment__Group__3 )
            // InternalX21.g:3880:2: rule__VariableAssignment__Group__2__Impl rule__VariableAssignment__Group__3
            {
            pushFollow(FOLLOW_14);
            rule__VariableAssignment__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__2"


    // $ANTLR start "rule__VariableAssignment__Group__2__Impl"
    // InternalX21.g:3887:1: rule__VariableAssignment__Group__2__Impl : ( ( rule__VariableAssignment__TypeAssignment_2 ) ) ;
    public final void rule__VariableAssignment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3891:1: ( ( ( rule__VariableAssignment__TypeAssignment_2 ) ) )
            // InternalX21.g:3892:1: ( ( rule__VariableAssignment__TypeAssignment_2 ) )
            {
            // InternalX21.g:3892:1: ( ( rule__VariableAssignment__TypeAssignment_2 ) )
            // InternalX21.g:3893:2: ( rule__VariableAssignment__TypeAssignment_2 )
            {
             before(grammarAccess.getVariableAssignmentAccess().getTypeAssignment_2()); 
            // InternalX21.g:3894:2: ( rule__VariableAssignment__TypeAssignment_2 )
            // InternalX21.g:3894:3: rule__VariableAssignment__TypeAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__VariableAssignment__TypeAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getVariableAssignmentAccess().getTypeAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__2__Impl"


    // $ANTLR start "rule__VariableAssignment__Group__3"
    // InternalX21.g:3902:1: rule__VariableAssignment__Group__3 : rule__VariableAssignment__Group__3__Impl rule__VariableAssignment__Group__4 ;
    public final void rule__VariableAssignment__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3906:1: ( rule__VariableAssignment__Group__3__Impl rule__VariableAssignment__Group__4 )
            // InternalX21.g:3907:2: rule__VariableAssignment__Group__3__Impl rule__VariableAssignment__Group__4
            {
            pushFollow(FOLLOW_4);
            rule__VariableAssignment__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__3"


    // $ANTLR start "rule__VariableAssignment__Group__3__Impl"
    // InternalX21.g:3914:1: rule__VariableAssignment__Group__3__Impl : ( '[' ) ;
    public final void rule__VariableAssignment__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3918:1: ( ( '[' ) )
            // InternalX21.g:3919:1: ( '[' )
            {
            // InternalX21.g:3919:1: ( '[' )
            // InternalX21.g:3920:2: '['
            {
             before(grammarAccess.getVariableAssignmentAccess().getLeftSquareBracketKeyword_3()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getVariableAssignmentAccess().getLeftSquareBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__3__Impl"


    // $ANTLR start "rule__VariableAssignment__Group__4"
    // InternalX21.g:3929:1: rule__VariableAssignment__Group__4 : rule__VariableAssignment__Group__4__Impl rule__VariableAssignment__Group__5 ;
    public final void rule__VariableAssignment__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3933:1: ( rule__VariableAssignment__Group__4__Impl rule__VariableAssignment__Group__5 )
            // InternalX21.g:3934:2: rule__VariableAssignment__Group__4__Impl rule__VariableAssignment__Group__5
            {
            pushFollow(FOLLOW_38);
            rule__VariableAssignment__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__4"


    // $ANTLR start "rule__VariableAssignment__Group__4__Impl"
    // InternalX21.g:3941:1: rule__VariableAssignment__Group__4__Impl : ( ( rule__VariableAssignment__AttrAssignment_4 ) ) ;
    public final void rule__VariableAssignment__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3945:1: ( ( ( rule__VariableAssignment__AttrAssignment_4 ) ) )
            // InternalX21.g:3946:1: ( ( rule__VariableAssignment__AttrAssignment_4 ) )
            {
            // InternalX21.g:3946:1: ( ( rule__VariableAssignment__AttrAssignment_4 ) )
            // InternalX21.g:3947:2: ( rule__VariableAssignment__AttrAssignment_4 )
            {
             before(grammarAccess.getVariableAssignmentAccess().getAttrAssignment_4()); 
            // InternalX21.g:3948:2: ( rule__VariableAssignment__AttrAssignment_4 )
            // InternalX21.g:3948:3: rule__VariableAssignment__AttrAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__VariableAssignment__AttrAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getVariableAssignmentAccess().getAttrAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__4__Impl"


    // $ANTLR start "rule__VariableAssignment__Group__5"
    // InternalX21.g:3956:1: rule__VariableAssignment__Group__5 : rule__VariableAssignment__Group__5__Impl rule__VariableAssignment__Group__6 ;
    public final void rule__VariableAssignment__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3960:1: ( rule__VariableAssignment__Group__5__Impl rule__VariableAssignment__Group__6 )
            // InternalX21.g:3961:2: rule__VariableAssignment__Group__5__Impl rule__VariableAssignment__Group__6
            {
            pushFollow(FOLLOW_12);
            rule__VariableAssignment__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__5"


    // $ANTLR start "rule__VariableAssignment__Group__5__Impl"
    // InternalX21.g:3968:1: rule__VariableAssignment__Group__5__Impl : ( '=' ) ;
    public final void rule__VariableAssignment__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3972:1: ( ( '=' ) )
            // InternalX21.g:3973:1: ( '=' )
            {
            // InternalX21.g:3973:1: ( '=' )
            // InternalX21.g:3974:2: '='
            {
             before(grammarAccess.getVariableAssignmentAccess().getEqualsSignKeyword_5()); 
            match(input,11,FOLLOW_2); 
             after(grammarAccess.getVariableAssignmentAccess().getEqualsSignKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__5__Impl"


    // $ANTLR start "rule__VariableAssignment__Group__6"
    // InternalX21.g:3983:1: rule__VariableAssignment__Group__6 : rule__VariableAssignment__Group__6__Impl rule__VariableAssignment__Group__7 ;
    public final void rule__VariableAssignment__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3987:1: ( rule__VariableAssignment__Group__6__Impl rule__VariableAssignment__Group__7 )
            // InternalX21.g:3988:2: rule__VariableAssignment__Group__6__Impl rule__VariableAssignment__Group__7
            {
            pushFollow(FOLLOW_41);
            rule__VariableAssignment__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__6"


    // $ANTLR start "rule__VariableAssignment__Group__6__Impl"
    // InternalX21.g:3995:1: rule__VariableAssignment__Group__6__Impl : ( ( rule__VariableAssignment__ValueAssignment_6 ) ) ;
    public final void rule__VariableAssignment__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:3999:1: ( ( ( rule__VariableAssignment__ValueAssignment_6 ) ) )
            // InternalX21.g:4000:1: ( ( rule__VariableAssignment__ValueAssignment_6 ) )
            {
            // InternalX21.g:4000:1: ( ( rule__VariableAssignment__ValueAssignment_6 ) )
            // InternalX21.g:4001:2: ( rule__VariableAssignment__ValueAssignment_6 )
            {
             before(grammarAccess.getVariableAssignmentAccess().getValueAssignment_6()); 
            // InternalX21.g:4002:2: ( rule__VariableAssignment__ValueAssignment_6 )
            // InternalX21.g:4002:3: rule__VariableAssignment__ValueAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__VariableAssignment__ValueAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getVariableAssignmentAccess().getValueAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__6__Impl"


    // $ANTLR start "rule__VariableAssignment__Group__7"
    // InternalX21.g:4010:1: rule__VariableAssignment__Group__7 : rule__VariableAssignment__Group__7__Impl rule__VariableAssignment__Group__8 ;
    public final void rule__VariableAssignment__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4014:1: ( rule__VariableAssignment__Group__7__Impl rule__VariableAssignment__Group__8 )
            // InternalX21.g:4015:2: rule__VariableAssignment__Group__7__Impl rule__VariableAssignment__Group__8
            {
            pushFollow(FOLLOW_41);
            rule__VariableAssignment__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__7"


    // $ANTLR start "rule__VariableAssignment__Group__7__Impl"
    // InternalX21.g:4022:1: rule__VariableAssignment__Group__7__Impl : ( ( rule__VariableAssignment__Group_7__0 )* ) ;
    public final void rule__VariableAssignment__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4026:1: ( ( ( rule__VariableAssignment__Group_7__0 )* ) )
            // InternalX21.g:4027:1: ( ( rule__VariableAssignment__Group_7__0 )* )
            {
            // InternalX21.g:4027:1: ( ( rule__VariableAssignment__Group_7__0 )* )
            // InternalX21.g:4028:2: ( rule__VariableAssignment__Group_7__0 )*
            {
             before(grammarAccess.getVariableAssignmentAccess().getGroup_7()); 
            // InternalX21.g:4029:2: ( rule__VariableAssignment__Group_7__0 )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0==29) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalX21.g:4029:3: rule__VariableAssignment__Group_7__0
            	    {
            	    pushFollow(FOLLOW_20);
            	    rule__VariableAssignment__Group_7__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

             after(grammarAccess.getVariableAssignmentAccess().getGroup_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__7__Impl"


    // $ANTLR start "rule__VariableAssignment__Group__8"
    // InternalX21.g:4037:1: rule__VariableAssignment__Group__8 : rule__VariableAssignment__Group__8__Impl ;
    public final void rule__VariableAssignment__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4041:1: ( rule__VariableAssignment__Group__8__Impl )
            // InternalX21.g:4042:2: rule__VariableAssignment__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__8"


    // $ANTLR start "rule__VariableAssignment__Group__8__Impl"
    // InternalX21.g:4048:1: rule__VariableAssignment__Group__8__Impl : ( ']' ) ;
    public final void rule__VariableAssignment__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4052:1: ( ( ']' ) )
            // InternalX21.g:4053:1: ( ']' )
            {
            // InternalX21.g:4053:1: ( ']' )
            // InternalX21.g:4054:2: ']'
            {
             before(grammarAccess.getVariableAssignmentAccess().getRightSquareBracketKeyword_8()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getVariableAssignmentAccess().getRightSquareBracketKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group__8__Impl"


    // $ANTLR start "rule__VariableAssignment__Group_7__0"
    // InternalX21.g:4064:1: rule__VariableAssignment__Group_7__0 : rule__VariableAssignment__Group_7__0__Impl rule__VariableAssignment__Group_7__1 ;
    public final void rule__VariableAssignment__Group_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4068:1: ( rule__VariableAssignment__Group_7__0__Impl rule__VariableAssignment__Group_7__1 )
            // InternalX21.g:4069:2: rule__VariableAssignment__Group_7__0__Impl rule__VariableAssignment__Group_7__1
            {
            pushFollow(FOLLOW_4);
            rule__VariableAssignment__Group_7__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group_7__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group_7__0"


    // $ANTLR start "rule__VariableAssignment__Group_7__0__Impl"
    // InternalX21.g:4076:1: rule__VariableAssignment__Group_7__0__Impl : ( ',' ) ;
    public final void rule__VariableAssignment__Group_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4080:1: ( ( ',' ) )
            // InternalX21.g:4081:1: ( ',' )
            {
            // InternalX21.g:4081:1: ( ',' )
            // InternalX21.g:4082:2: ','
            {
             before(grammarAccess.getVariableAssignmentAccess().getCommaKeyword_7_0()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getVariableAssignmentAccess().getCommaKeyword_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group_7__0__Impl"


    // $ANTLR start "rule__VariableAssignment__Group_7__1"
    // InternalX21.g:4091:1: rule__VariableAssignment__Group_7__1 : rule__VariableAssignment__Group_7__1__Impl rule__VariableAssignment__Group_7__2 ;
    public final void rule__VariableAssignment__Group_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4095:1: ( rule__VariableAssignment__Group_7__1__Impl rule__VariableAssignment__Group_7__2 )
            // InternalX21.g:4096:2: rule__VariableAssignment__Group_7__1__Impl rule__VariableAssignment__Group_7__2
            {
            pushFollow(FOLLOW_38);
            rule__VariableAssignment__Group_7__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group_7__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group_7__1"


    // $ANTLR start "rule__VariableAssignment__Group_7__1__Impl"
    // InternalX21.g:4103:1: rule__VariableAssignment__Group_7__1__Impl : ( ( rule__VariableAssignment__AttrAssignment_7_1 ) ) ;
    public final void rule__VariableAssignment__Group_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4107:1: ( ( ( rule__VariableAssignment__AttrAssignment_7_1 ) ) )
            // InternalX21.g:4108:1: ( ( rule__VariableAssignment__AttrAssignment_7_1 ) )
            {
            // InternalX21.g:4108:1: ( ( rule__VariableAssignment__AttrAssignment_7_1 ) )
            // InternalX21.g:4109:2: ( rule__VariableAssignment__AttrAssignment_7_1 )
            {
             before(grammarAccess.getVariableAssignmentAccess().getAttrAssignment_7_1()); 
            // InternalX21.g:4110:2: ( rule__VariableAssignment__AttrAssignment_7_1 )
            // InternalX21.g:4110:3: rule__VariableAssignment__AttrAssignment_7_1
            {
            pushFollow(FOLLOW_2);
            rule__VariableAssignment__AttrAssignment_7_1();

            state._fsp--;


            }

             after(grammarAccess.getVariableAssignmentAccess().getAttrAssignment_7_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group_7__1__Impl"


    // $ANTLR start "rule__VariableAssignment__Group_7__2"
    // InternalX21.g:4118:1: rule__VariableAssignment__Group_7__2 : rule__VariableAssignment__Group_7__2__Impl rule__VariableAssignment__Group_7__3 ;
    public final void rule__VariableAssignment__Group_7__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4122:1: ( rule__VariableAssignment__Group_7__2__Impl rule__VariableAssignment__Group_7__3 )
            // InternalX21.g:4123:2: rule__VariableAssignment__Group_7__2__Impl rule__VariableAssignment__Group_7__3
            {
            pushFollow(FOLLOW_12);
            rule__VariableAssignment__Group_7__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group_7__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group_7__2"


    // $ANTLR start "rule__VariableAssignment__Group_7__2__Impl"
    // InternalX21.g:4130:1: rule__VariableAssignment__Group_7__2__Impl : ( '=' ) ;
    public final void rule__VariableAssignment__Group_7__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4134:1: ( ( '=' ) )
            // InternalX21.g:4135:1: ( '=' )
            {
            // InternalX21.g:4135:1: ( '=' )
            // InternalX21.g:4136:2: '='
            {
             before(grammarAccess.getVariableAssignmentAccess().getEqualsSignKeyword_7_2()); 
            match(input,11,FOLLOW_2); 
             after(grammarAccess.getVariableAssignmentAccess().getEqualsSignKeyword_7_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group_7__2__Impl"


    // $ANTLR start "rule__VariableAssignment__Group_7__3"
    // InternalX21.g:4145:1: rule__VariableAssignment__Group_7__3 : rule__VariableAssignment__Group_7__3__Impl ;
    public final void rule__VariableAssignment__Group_7__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4149:1: ( rule__VariableAssignment__Group_7__3__Impl )
            // InternalX21.g:4150:2: rule__VariableAssignment__Group_7__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__VariableAssignment__Group_7__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group_7__3"


    // $ANTLR start "rule__VariableAssignment__Group_7__3__Impl"
    // InternalX21.g:4156:1: rule__VariableAssignment__Group_7__3__Impl : ( ( rule__VariableAssignment__ValueAssignment_7_3 ) ) ;
    public final void rule__VariableAssignment__Group_7__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4160:1: ( ( ( rule__VariableAssignment__ValueAssignment_7_3 ) ) )
            // InternalX21.g:4161:1: ( ( rule__VariableAssignment__ValueAssignment_7_3 ) )
            {
            // InternalX21.g:4161:1: ( ( rule__VariableAssignment__ValueAssignment_7_3 ) )
            // InternalX21.g:4162:2: ( rule__VariableAssignment__ValueAssignment_7_3 )
            {
             before(grammarAccess.getVariableAssignmentAccess().getValueAssignment_7_3()); 
            // InternalX21.g:4163:2: ( rule__VariableAssignment__ValueAssignment_7_3 )
            // InternalX21.g:4163:3: rule__VariableAssignment__ValueAssignment_7_3
            {
            pushFollow(FOLLOW_2);
            rule__VariableAssignment__ValueAssignment_7_3();

            state._fsp--;


            }

             after(grammarAccess.getVariableAssignmentAccess().getValueAssignment_7_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__Group_7__3__Impl"


    // $ANTLR start "rule__DataTypeAttribute__Group__0"
    // InternalX21.g:4172:1: rule__DataTypeAttribute__Group__0 : rule__DataTypeAttribute__Group__0__Impl rule__DataTypeAttribute__Group__1 ;
    public final void rule__DataTypeAttribute__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4176:1: ( rule__DataTypeAttribute__Group__0__Impl rule__DataTypeAttribute__Group__1 )
            // InternalX21.g:4177:2: rule__DataTypeAttribute__Group__0__Impl rule__DataTypeAttribute__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__DataTypeAttribute__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataTypeAttribute__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataTypeAttribute__Group__0"


    // $ANTLR start "rule__DataTypeAttribute__Group__0__Impl"
    // InternalX21.g:4184:1: rule__DataTypeAttribute__Group__0__Impl : ( () ) ;
    public final void rule__DataTypeAttribute__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4188:1: ( ( () ) )
            // InternalX21.g:4189:1: ( () )
            {
            // InternalX21.g:4189:1: ( () )
            // InternalX21.g:4190:2: ()
            {
             before(grammarAccess.getDataTypeAttributeAccess().getDataTypeAttributeAction_0()); 
            // InternalX21.g:4191:2: ()
            // InternalX21.g:4191:3: 
            {
            }

             after(grammarAccess.getDataTypeAttributeAccess().getDataTypeAttributeAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataTypeAttribute__Group__0__Impl"


    // $ANTLR start "rule__DataTypeAttribute__Group__1"
    // InternalX21.g:4199:1: rule__DataTypeAttribute__Group__1 : rule__DataTypeAttribute__Group__1__Impl rule__DataTypeAttribute__Group__2 ;
    public final void rule__DataTypeAttribute__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4203:1: ( rule__DataTypeAttribute__Group__1__Impl rule__DataTypeAttribute__Group__2 )
            // InternalX21.g:4204:2: rule__DataTypeAttribute__Group__1__Impl rule__DataTypeAttribute__Group__2
            {
            pushFollow(FOLLOW_42);
            rule__DataTypeAttribute__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataTypeAttribute__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataTypeAttribute__Group__1"


    // $ANTLR start "rule__DataTypeAttribute__Group__1__Impl"
    // InternalX21.g:4211:1: rule__DataTypeAttribute__Group__1__Impl : ( ( rule__DataTypeAttribute__SourceAssignment_1 ) ) ;
    public final void rule__DataTypeAttribute__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4215:1: ( ( ( rule__DataTypeAttribute__SourceAssignment_1 ) ) )
            // InternalX21.g:4216:1: ( ( rule__DataTypeAttribute__SourceAssignment_1 ) )
            {
            // InternalX21.g:4216:1: ( ( rule__DataTypeAttribute__SourceAssignment_1 ) )
            // InternalX21.g:4217:2: ( rule__DataTypeAttribute__SourceAssignment_1 )
            {
             before(grammarAccess.getDataTypeAttributeAccess().getSourceAssignment_1()); 
            // InternalX21.g:4218:2: ( rule__DataTypeAttribute__SourceAssignment_1 )
            // InternalX21.g:4218:3: rule__DataTypeAttribute__SourceAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__DataTypeAttribute__SourceAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getDataTypeAttributeAccess().getSourceAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataTypeAttribute__Group__1__Impl"


    // $ANTLR start "rule__DataTypeAttribute__Group__2"
    // InternalX21.g:4226:1: rule__DataTypeAttribute__Group__2 : rule__DataTypeAttribute__Group__2__Impl rule__DataTypeAttribute__Group__3 ;
    public final void rule__DataTypeAttribute__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4230:1: ( rule__DataTypeAttribute__Group__2__Impl rule__DataTypeAttribute__Group__3 )
            // InternalX21.g:4231:2: rule__DataTypeAttribute__Group__2__Impl rule__DataTypeAttribute__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__DataTypeAttribute__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataTypeAttribute__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataTypeAttribute__Group__2"


    // $ANTLR start "rule__DataTypeAttribute__Group__2__Impl"
    // InternalX21.g:4238:1: rule__DataTypeAttribute__Group__2__Impl : ( '.' ) ;
    public final void rule__DataTypeAttribute__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4242:1: ( ( '.' ) )
            // InternalX21.g:4243:1: ( '.' )
            {
            // InternalX21.g:4243:1: ( '.' )
            // InternalX21.g:4244:2: '.'
            {
             before(grammarAccess.getDataTypeAttributeAccess().getFullStopKeyword_2()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getDataTypeAttributeAccess().getFullStopKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataTypeAttribute__Group__2__Impl"


    // $ANTLR start "rule__DataTypeAttribute__Group__3"
    // InternalX21.g:4253:1: rule__DataTypeAttribute__Group__3 : rule__DataTypeAttribute__Group__3__Impl ;
    public final void rule__DataTypeAttribute__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4257:1: ( rule__DataTypeAttribute__Group__3__Impl )
            // InternalX21.g:4258:2: rule__DataTypeAttribute__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DataTypeAttribute__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataTypeAttribute__Group__3"


    // $ANTLR start "rule__DataTypeAttribute__Group__3__Impl"
    // InternalX21.g:4264:1: rule__DataTypeAttribute__Group__3__Impl : ( ( rule__DataTypeAttribute__AttrAssignment_3 ) ) ;
    public final void rule__DataTypeAttribute__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4268:1: ( ( ( rule__DataTypeAttribute__AttrAssignment_3 ) ) )
            // InternalX21.g:4269:1: ( ( rule__DataTypeAttribute__AttrAssignment_3 ) )
            {
            // InternalX21.g:4269:1: ( ( rule__DataTypeAttribute__AttrAssignment_3 ) )
            // InternalX21.g:4270:2: ( rule__DataTypeAttribute__AttrAssignment_3 )
            {
             before(grammarAccess.getDataTypeAttributeAccess().getAttrAssignment_3()); 
            // InternalX21.g:4271:2: ( rule__DataTypeAttribute__AttrAssignment_3 )
            // InternalX21.g:4271:3: rule__DataTypeAttribute__AttrAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__DataTypeAttribute__AttrAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getDataTypeAttributeAccess().getAttrAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataTypeAttribute__Group__3__Impl"


    // $ANTLR start "rule__LogicExp__Group__0"
    // InternalX21.g:4280:1: rule__LogicExp__Group__0 : rule__LogicExp__Group__0__Impl rule__LogicExp__Group__1 ;
    public final void rule__LogicExp__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4284:1: ( rule__LogicExp__Group__0__Impl rule__LogicExp__Group__1 )
            // InternalX21.g:4285:2: rule__LogicExp__Group__0__Impl rule__LogicExp__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__LogicExp__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LogicExp__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicExp__Group__0"


    // $ANTLR start "rule__LogicExp__Group__0__Impl"
    // InternalX21.g:4292:1: rule__LogicExp__Group__0__Impl : ( () ) ;
    public final void rule__LogicExp__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4296:1: ( ( () ) )
            // InternalX21.g:4297:1: ( () )
            {
            // InternalX21.g:4297:1: ( () )
            // InternalX21.g:4298:2: ()
            {
             before(grammarAccess.getLogicExpAccess().getLogicExpAction_0()); 
            // InternalX21.g:4299:2: ()
            // InternalX21.g:4299:3: 
            {
            }

             after(grammarAccess.getLogicExpAccess().getLogicExpAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicExp__Group__0__Impl"


    // $ANTLR start "rule__LogicExp__Group__1"
    // InternalX21.g:4307:1: rule__LogicExp__Group__1 : rule__LogicExp__Group__1__Impl rule__LogicExp__Group__2 ;
    public final void rule__LogicExp__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4311:1: ( rule__LogicExp__Group__1__Impl rule__LogicExp__Group__2 )
            // InternalX21.g:4312:2: rule__LogicExp__Group__1__Impl rule__LogicExp__Group__2
            {
            pushFollow(FOLLOW_43);
            rule__LogicExp__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LogicExp__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicExp__Group__1"


    // $ANTLR start "rule__LogicExp__Group__1__Impl"
    // InternalX21.g:4319:1: rule__LogicExp__Group__1__Impl : ( ( rule__LogicExp__LeftAssignment_1 ) ) ;
    public final void rule__LogicExp__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4323:1: ( ( ( rule__LogicExp__LeftAssignment_1 ) ) )
            // InternalX21.g:4324:1: ( ( rule__LogicExp__LeftAssignment_1 ) )
            {
            // InternalX21.g:4324:1: ( ( rule__LogicExp__LeftAssignment_1 ) )
            // InternalX21.g:4325:2: ( rule__LogicExp__LeftAssignment_1 )
            {
             before(grammarAccess.getLogicExpAccess().getLeftAssignment_1()); 
            // InternalX21.g:4326:2: ( rule__LogicExp__LeftAssignment_1 )
            // InternalX21.g:4326:3: rule__LogicExp__LeftAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__LogicExp__LeftAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getLogicExpAccess().getLeftAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicExp__Group__1__Impl"


    // $ANTLR start "rule__LogicExp__Group__2"
    // InternalX21.g:4334:1: rule__LogicExp__Group__2 : rule__LogicExp__Group__2__Impl rule__LogicExp__Group__3 ;
    public final void rule__LogicExp__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4338:1: ( rule__LogicExp__Group__2__Impl rule__LogicExp__Group__3 )
            // InternalX21.g:4339:2: rule__LogicExp__Group__2__Impl rule__LogicExp__Group__3
            {
            pushFollow(FOLLOW_12);
            rule__LogicExp__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LogicExp__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicExp__Group__2"


    // $ANTLR start "rule__LogicExp__Group__2__Impl"
    // InternalX21.g:4346:1: rule__LogicExp__Group__2__Impl : ( ( rule__LogicExp__CompAssignment_2 ) ) ;
    public final void rule__LogicExp__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4350:1: ( ( ( rule__LogicExp__CompAssignment_2 ) ) )
            // InternalX21.g:4351:1: ( ( rule__LogicExp__CompAssignment_2 ) )
            {
            // InternalX21.g:4351:1: ( ( rule__LogicExp__CompAssignment_2 ) )
            // InternalX21.g:4352:2: ( rule__LogicExp__CompAssignment_2 )
            {
             before(grammarAccess.getLogicExpAccess().getCompAssignment_2()); 
            // InternalX21.g:4353:2: ( rule__LogicExp__CompAssignment_2 )
            // InternalX21.g:4353:3: rule__LogicExp__CompAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__LogicExp__CompAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getLogicExpAccess().getCompAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicExp__Group__2__Impl"


    // $ANTLR start "rule__LogicExp__Group__3"
    // InternalX21.g:4361:1: rule__LogicExp__Group__3 : rule__LogicExp__Group__3__Impl ;
    public final void rule__LogicExp__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4365:1: ( rule__LogicExp__Group__3__Impl )
            // InternalX21.g:4366:2: rule__LogicExp__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LogicExp__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicExp__Group__3"


    // $ANTLR start "rule__LogicExp__Group__3__Impl"
    // InternalX21.g:4372:1: rule__LogicExp__Group__3__Impl : ( ( rule__LogicExp__RightAssignment_3 ) ) ;
    public final void rule__LogicExp__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4376:1: ( ( ( rule__LogicExp__RightAssignment_3 ) ) )
            // InternalX21.g:4377:1: ( ( rule__LogicExp__RightAssignment_3 ) )
            {
            // InternalX21.g:4377:1: ( ( rule__LogicExp__RightAssignment_3 ) )
            // InternalX21.g:4378:2: ( rule__LogicExp__RightAssignment_3 )
            {
             before(grammarAccess.getLogicExpAccess().getRightAssignment_3()); 
            // InternalX21.g:4379:2: ( rule__LogicExp__RightAssignment_3 )
            // InternalX21.g:4379:3: rule__LogicExp__RightAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__LogicExp__RightAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getLogicExpAccess().getRightAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicExp__Group__3__Impl"


    // $ANTLR start "rule__Program__NameAssignment_2"
    // InternalX21.g:4388:1: rule__Program__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__Program__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4392:1: ( ( RULE_ID ) )
            // InternalX21.g:4393:2: ( RULE_ID )
            {
            // InternalX21.g:4393:2: ( RULE_ID )
            // InternalX21.g:4394:3: RULE_ID
            {
             before(grammarAccess.getProgramAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getProgramAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__NameAssignment_2"


    // $ANTLR start "rule__Program__DeclarationsAssignment_3"
    // InternalX21.g:4403:1: rule__Program__DeclarationsAssignment_3 : ( ruleDeclaration ) ;
    public final void rule__Program__DeclarationsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4407:1: ( ( ruleDeclaration ) )
            // InternalX21.g:4408:2: ( ruleDeclaration )
            {
            // InternalX21.g:4408:2: ( ruleDeclaration )
            // InternalX21.g:4409:3: ruleDeclaration
            {
             before(grammarAccess.getProgramAccess().getDeclarationsDeclarationParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleDeclaration();

            state._fsp--;

             after(grammarAccess.getProgramAccess().getDeclarationsDeclarationParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__DeclarationsAssignment_3"


    // $ANTLR start "rule__Parameter__NameAssignment_1"
    // InternalX21.g:4418:1: rule__Parameter__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Parameter__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4422:1: ( ( RULE_ID ) )
            // InternalX21.g:4423:2: ( RULE_ID )
            {
            // InternalX21.g:4423:2: ( RULE_ID )
            // InternalX21.g:4424:3: RULE_ID
            {
             before(grammarAccess.getParameterAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getParameterAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parameter__NameAssignment_1"


    // $ANTLR start "rule__Parameter__TypeAssignment_3"
    // InternalX21.g:4433:1: rule__Parameter__TypeAssignment_3 : ( ruleType ) ;
    public final void rule__Parameter__TypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4437:1: ( ( ruleType ) )
            // InternalX21.g:4438:2: ( ruleType )
            {
            // InternalX21.g:4438:2: ( ruleType )
            // InternalX21.g:4439:3: ruleType
            {
             before(grammarAccess.getParameterAccess().getTypeTypeParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleType();

            state._fsp--;

             after(grammarAccess.getParameterAccess().getTypeTypeParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parameter__TypeAssignment_3"


    // $ANTLR start "rule__InternalParameter__NameAssignment_1"
    // InternalX21.g:4448:1: rule__InternalParameter__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__InternalParameter__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4452:1: ( ( RULE_ID ) )
            // InternalX21.g:4453:2: ( RULE_ID )
            {
            // InternalX21.g:4453:2: ( RULE_ID )
            // InternalX21.g:4454:3: RULE_ID
            {
             before(grammarAccess.getInternalParameterAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getInternalParameterAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InternalParameter__NameAssignment_1"


    // $ANTLR start "rule__InternalParameter__TypeAssignment_3"
    // InternalX21.g:4463:1: rule__InternalParameter__TypeAssignment_3 : ( ruleType ) ;
    public final void rule__InternalParameter__TypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4467:1: ( ( ruleType ) )
            // InternalX21.g:4468:2: ( ruleType )
            {
            // InternalX21.g:4468:2: ( ruleType )
            // InternalX21.g:4469:3: ruleType
            {
             before(grammarAccess.getInternalParameterAccess().getTypeTypeParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleType();

            state._fsp--;

             after(grammarAccess.getInternalParameterAccess().getTypeTypeParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InternalParameter__TypeAssignment_3"


    // $ANTLR start "rule__Function__NameAssignment_1"
    // InternalX21.g:4478:1: rule__Function__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Function__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4482:1: ( ( RULE_ID ) )
            // InternalX21.g:4483:2: ( RULE_ID )
            {
            // InternalX21.g:4483:2: ( RULE_ID )
            // InternalX21.g:4484:3: RULE_ID
            {
             before(grammarAccess.getFunctionAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getFunctionAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__NameAssignment_1"


    // $ANTLR start "rule__Function__LambdaAssignment_2"
    // InternalX21.g:4493:1: rule__Function__LambdaAssignment_2 : ( ruleLambda ) ;
    public final void rule__Function__LambdaAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4497:1: ( ( ruleLambda ) )
            // InternalX21.g:4498:2: ( ruleLambda )
            {
            // InternalX21.g:4498:2: ( ruleLambda )
            // InternalX21.g:4499:3: ruleLambda
            {
             before(grammarAccess.getFunctionAccess().getLambdaLambdaParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleLambda();

            state._fsp--;

             after(grammarAccess.getFunctionAccess().getLambdaLambdaParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__LambdaAssignment_2"


    // $ANTLR start "rule__Lambda__ParameterAssignment_1"
    // InternalX21.g:4508:1: rule__Lambda__ParameterAssignment_1 : ( ruleInternalParameter ) ;
    public final void rule__Lambda__ParameterAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4512:1: ( ( ruleInternalParameter ) )
            // InternalX21.g:4513:2: ( ruleInternalParameter )
            {
            // InternalX21.g:4513:2: ( ruleInternalParameter )
            // InternalX21.g:4514:3: ruleInternalParameter
            {
             before(grammarAccess.getLambdaAccess().getParameterInternalParameterParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleInternalParameter();

            state._fsp--;

             after(grammarAccess.getLambdaAccess().getParameterInternalParameterParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__ParameterAssignment_1"


    // $ANTLR start "rule__Lambda__ExpAssignment_4"
    // InternalX21.g:4523:1: rule__Lambda__ExpAssignment_4 : ( ruleExp ) ;
    public final void rule__Lambda__ExpAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4527:1: ( ( ruleExp ) )
            // InternalX21.g:4528:2: ( ruleExp )
            {
            // InternalX21.g:4528:2: ( ruleExp )
            // InternalX21.g:4529:3: ruleExp
            {
             before(grammarAccess.getLambdaAccess().getExpExpParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleExp();

            state._fsp--;

             after(grammarAccess.getLambdaAccess().getExpExpParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Lambda__ExpAssignment_4"


    // $ANTLR start "rule__Input__NameAssignment_1"
    // InternalX21.g:4538:1: rule__Input__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Input__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4542:1: ( ( RULE_ID ) )
            // InternalX21.g:4543:2: ( RULE_ID )
            {
            // InternalX21.g:4543:2: ( RULE_ID )
            // InternalX21.g:4544:3: RULE_ID
            {
             before(grammarAccess.getInputAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getInputAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__NameAssignment_1"


    // $ANTLR start "rule__Input__TypeAssignment_3"
    // InternalX21.g:4553:1: rule__Input__TypeAssignment_3 : ( ruleType ) ;
    public final void rule__Input__TypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4557:1: ( ( ruleType ) )
            // InternalX21.g:4558:2: ( ruleType )
            {
            // InternalX21.g:4558:2: ( ruleType )
            // InternalX21.g:4559:3: ruleType
            {
             before(grammarAccess.getInputAccess().getTypeTypeParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleType();

            state._fsp--;

             after(grammarAccess.getInputAccess().getTypeTypeParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__TypeAssignment_3"


    // $ANTLR start "rule__Node__NameAssignment_1"
    // InternalX21.g:4568:1: rule__Node__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Node__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4572:1: ( ( RULE_ID ) )
            // InternalX21.g:4573:2: ( RULE_ID )
            {
            // InternalX21.g:4573:2: ( RULE_ID )
            // InternalX21.g:4574:3: RULE_ID
            {
             before(grammarAccess.getNodeAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getNodeAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__NameAssignment_1"


    // $ANTLR start "rule__Node__RefbodyAssignment_3_0"
    // InternalX21.g:4583:1: rule__Node__RefbodyAssignment_3_0 : ( ( RULE_ID ) ) ;
    public final void rule__Node__RefbodyAssignment_3_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4587:1: ( ( ( RULE_ID ) ) )
            // InternalX21.g:4588:2: ( ( RULE_ID ) )
            {
            // InternalX21.g:4588:2: ( ( RULE_ID ) )
            // InternalX21.g:4589:3: ( RULE_ID )
            {
             before(grammarAccess.getNodeAccess().getRefbodyFunctionCrossReference_3_0_0()); 
            // InternalX21.g:4590:3: ( RULE_ID )
            // InternalX21.g:4591:4: RULE_ID
            {
             before(grammarAccess.getNodeAccess().getRefbodyFunctionIDTerminalRuleCall_3_0_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getNodeAccess().getRefbodyFunctionIDTerminalRuleCall_3_0_0_1()); 

            }

             after(grammarAccess.getNodeAccess().getRefbodyFunctionCrossReference_3_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__RefbodyAssignment_3_0"


    // $ANTLR start "rule__Node__BodyAssignment_3_1"
    // InternalX21.g:4602:1: rule__Node__BodyAssignment_3_1 : ( ruleLambda ) ;
    public final void rule__Node__BodyAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4606:1: ( ( ruleLambda ) )
            // InternalX21.g:4607:2: ( ruleLambda )
            {
            // InternalX21.g:4607:2: ( ruleLambda )
            // InternalX21.g:4608:3: ruleLambda
            {
             before(grammarAccess.getNodeAccess().getBodyLambdaParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleLambda();

            state._fsp--;

             after(grammarAccess.getNodeAccess().getBodyLambdaParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__BodyAssignment_3_1"


    // $ANTLR start "rule__StreamOutput__TargetsAssignment_2"
    // InternalX21.g:4617:1: rule__StreamOutput__TargetsAssignment_2 : ( ruleElement ) ;
    public final void rule__StreamOutput__TargetsAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4621:1: ( ( ruleElement ) )
            // InternalX21.g:4622:2: ( ruleElement )
            {
            // InternalX21.g:4622:2: ( ruleElement )
            // InternalX21.g:4623:3: ruleElement
            {
             before(grammarAccess.getStreamOutputAccess().getTargetsElementParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleElement();

            state._fsp--;

             after(grammarAccess.getStreamOutputAccess().getTargetsElementParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__TargetsAssignment_2"


    // $ANTLR start "rule__StreamOutput__TargetsAssignment_3_1"
    // InternalX21.g:4632:1: rule__StreamOutput__TargetsAssignment_3_1 : ( ruleElement ) ;
    public final void rule__StreamOutput__TargetsAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4636:1: ( ( ruleElement ) )
            // InternalX21.g:4637:2: ( ruleElement )
            {
            // InternalX21.g:4637:2: ( ruleElement )
            // InternalX21.g:4638:3: ruleElement
            {
             before(grammarAccess.getStreamOutputAccess().getTargetsElementParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleElement();

            state._fsp--;

             after(grammarAccess.getStreamOutputAccess().getTargetsElementParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StreamOutput__TargetsAssignment_3_1"


    // $ANTLR start "rule__Stream__OriginsAssignment_2"
    // InternalX21.g:4647:1: rule__Stream__OriginsAssignment_2 : ( ( RULE_ID ) ) ;
    public final void rule__Stream__OriginsAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4651:1: ( ( ( RULE_ID ) ) )
            // InternalX21.g:4652:2: ( ( RULE_ID ) )
            {
            // InternalX21.g:4652:2: ( ( RULE_ID ) )
            // InternalX21.g:4653:3: ( RULE_ID )
            {
             before(grammarAccess.getStreamAccess().getOriginsStreamInputCrossReference_2_0()); 
            // InternalX21.g:4654:3: ( RULE_ID )
            // InternalX21.g:4655:4: RULE_ID
            {
             before(grammarAccess.getStreamAccess().getOriginsStreamInputIDTerminalRuleCall_2_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getStreamAccess().getOriginsStreamInputIDTerminalRuleCall_2_0_1()); 

            }

             after(grammarAccess.getStreamAccess().getOriginsStreamInputCrossReference_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__OriginsAssignment_2"


    // $ANTLR start "rule__Stream__OriginsAssignment_3_1"
    // InternalX21.g:4666:1: rule__Stream__OriginsAssignment_3_1 : ( ( RULE_ID ) ) ;
    public final void rule__Stream__OriginsAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4670:1: ( ( ( RULE_ID ) ) )
            // InternalX21.g:4671:2: ( ( RULE_ID ) )
            {
            // InternalX21.g:4671:2: ( ( RULE_ID ) )
            // InternalX21.g:4672:3: ( RULE_ID )
            {
             before(grammarAccess.getStreamAccess().getOriginsStreamInputCrossReference_3_1_0()); 
            // InternalX21.g:4673:3: ( RULE_ID )
            // InternalX21.g:4674:4: RULE_ID
            {
             before(grammarAccess.getStreamAccess().getOriginsStreamInputIDTerminalRuleCall_3_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getStreamAccess().getOriginsStreamInputIDTerminalRuleCall_3_1_0_1()); 

            }

             after(grammarAccess.getStreamAccess().getOriginsStreamInputCrossReference_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__OriginsAssignment_3_1"


    // $ANTLR start "rule__Stream__OutputsAssignment_4"
    // InternalX21.g:4685:1: rule__Stream__OutputsAssignment_4 : ( ruleStreamOutput ) ;
    public final void rule__Stream__OutputsAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4689:1: ( ( ruleStreamOutput ) )
            // InternalX21.g:4690:2: ( ruleStreamOutput )
            {
            // InternalX21.g:4690:2: ( ruleStreamOutput )
            // InternalX21.g:4691:3: ruleStreamOutput
            {
             before(grammarAccess.getStreamAccess().getOutputsStreamOutputParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleStreamOutput();

            state._fsp--;

             after(grammarAccess.getStreamAccess().getOutputsStreamOutputParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Stream__OutputsAssignment_4"


    // $ANTLR start "rule__Element__NodeAssignment_0_1"
    // InternalX21.g:4700:1: rule__Element__NodeAssignment_0_1 : ( ( RULE_ID ) ) ;
    public final void rule__Element__NodeAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4704:1: ( ( ( RULE_ID ) ) )
            // InternalX21.g:4705:2: ( ( RULE_ID ) )
            {
            // InternalX21.g:4705:2: ( ( RULE_ID ) )
            // InternalX21.g:4706:3: ( RULE_ID )
            {
             before(grammarAccess.getElementAccess().getNodeNodeCrossReference_0_1_0()); 
            // InternalX21.g:4707:3: ( RULE_ID )
            // InternalX21.g:4708:4: RULE_ID
            {
             before(grammarAccess.getElementAccess().getNodeNodeIDTerminalRuleCall_0_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getElementAccess().getNodeNodeIDTerminalRuleCall_0_1_0_1()); 

            }

             after(grammarAccess.getElementAccess().getNodeNodeCrossReference_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__NodeAssignment_0_1"


    // $ANTLR start "rule__Element__RefBodyAssignment_1_2_0"
    // InternalX21.g:4719:1: rule__Element__RefBodyAssignment_1_2_0 : ( ( RULE_ID ) ) ;
    public final void rule__Element__RefBodyAssignment_1_2_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4723:1: ( ( ( RULE_ID ) ) )
            // InternalX21.g:4724:2: ( ( RULE_ID ) )
            {
            // InternalX21.g:4724:2: ( ( RULE_ID ) )
            // InternalX21.g:4725:3: ( RULE_ID )
            {
             before(grammarAccess.getElementAccess().getRefBodyFunctionCrossReference_1_2_0_0()); 
            // InternalX21.g:4726:3: ( RULE_ID )
            // InternalX21.g:4727:4: RULE_ID
            {
             before(grammarAccess.getElementAccess().getRefBodyFunctionIDTerminalRuleCall_1_2_0_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getElementAccess().getRefBodyFunctionIDTerminalRuleCall_1_2_0_0_1()); 

            }

             after(grammarAccess.getElementAccess().getRefBodyFunctionCrossReference_1_2_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__RefBodyAssignment_1_2_0"


    // $ANTLR start "rule__Element__BodyAssignment_1_2_1"
    // InternalX21.g:4738:1: rule__Element__BodyAssignment_1_2_1 : ( ruleLambda ) ;
    public final void rule__Element__BodyAssignment_1_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4742:1: ( ( ruleLambda ) )
            // InternalX21.g:4743:2: ( ruleLambda )
            {
            // InternalX21.g:4743:2: ( ruleLambda )
            // InternalX21.g:4744:3: ruleLambda
            {
             before(grammarAccess.getElementAccess().getBodyLambdaParserRuleCall_1_2_1_0()); 
            pushFollow(FOLLOW_2);
            ruleLambda();

            state._fsp--;

             after(grammarAccess.getElementAccess().getBodyLambdaParserRuleCall_1_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__BodyAssignment_1_2_1"


    // $ANTLR start "rule__Element__OutputNameAssignment_2_2"
    // InternalX21.g:4753:1: rule__Element__OutputNameAssignment_2_2 : ( RULE_ID ) ;
    public final void rule__Element__OutputNameAssignment_2_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4757:1: ( ( RULE_ID ) )
            // InternalX21.g:4758:2: ( RULE_ID )
            {
            // InternalX21.g:4758:2: ( RULE_ID )
            // InternalX21.g:4759:3: RULE_ID
            {
             before(grammarAccess.getElementAccess().getOutputNameIDTerminalRuleCall_2_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getElementAccess().getOutputNameIDTerminalRuleCall_2_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__OutputNameAssignment_2_2"


    // $ANTLR start "rule__DataDecl__NameAssignment_1"
    // InternalX21.g:4768:1: rule__DataDecl__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__DataDecl__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4772:1: ( ( RULE_ID ) )
            // InternalX21.g:4773:2: ( RULE_ID )
            {
            // InternalX21.g:4773:2: ( RULE_ID )
            // InternalX21.g:4774:3: RULE_ID
            {
             before(grammarAccess.getDataDeclAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getDataDeclAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__NameAssignment_1"


    // $ANTLR start "rule__DataDecl__ParamsAssignment_3"
    // InternalX21.g:4783:1: rule__DataDecl__ParamsAssignment_3 : ( ruleInternalParameter ) ;
    public final void rule__DataDecl__ParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4787:1: ( ( ruleInternalParameter ) )
            // InternalX21.g:4788:2: ( ruleInternalParameter )
            {
            // InternalX21.g:4788:2: ( ruleInternalParameter )
            // InternalX21.g:4789:3: ruleInternalParameter
            {
             before(grammarAccess.getDataDeclAccess().getParamsInternalParameterParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleInternalParameter();

            state._fsp--;

             after(grammarAccess.getDataDeclAccess().getParamsInternalParameterParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__ParamsAssignment_3"


    // $ANTLR start "rule__DataDecl__ParamsAssignment_4_1"
    // InternalX21.g:4798:1: rule__DataDecl__ParamsAssignment_4_1 : ( ruleInternalParameter ) ;
    public final void rule__DataDecl__ParamsAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4802:1: ( ( ruleInternalParameter ) )
            // InternalX21.g:4803:2: ( ruleInternalParameter )
            {
            // InternalX21.g:4803:2: ( ruleInternalParameter )
            // InternalX21.g:4804:3: ruleInternalParameter
            {
             before(grammarAccess.getDataDeclAccess().getParamsInternalParameterParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleInternalParameter();

            state._fsp--;

             after(grammarAccess.getDataDeclAccess().getParamsInternalParameterParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataDecl__ParamsAssignment_4_1"


    // $ANTLR start "rule__Type__TypeAssignment_0_1"
    // InternalX21.g:4813:1: rule__Type__TypeAssignment_0_1 : ( ( 'int' ) ) ;
    public final void rule__Type__TypeAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4817:1: ( ( ( 'int' ) ) )
            // InternalX21.g:4818:2: ( ( 'int' ) )
            {
            // InternalX21.g:4818:2: ( ( 'int' ) )
            // InternalX21.g:4819:3: ( 'int' )
            {
             before(grammarAccess.getTypeAccess().getTypeIntKeyword_0_1_0()); 
            // InternalX21.g:4820:3: ( 'int' )
            // InternalX21.g:4821:4: 'int'
            {
             before(grammarAccess.getTypeAccess().getTypeIntKeyword_0_1_0()); 
            match(input,46,FOLLOW_2); 
             after(grammarAccess.getTypeAccess().getTypeIntKeyword_0_1_0()); 

            }

             after(grammarAccess.getTypeAccess().getTypeIntKeyword_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__TypeAssignment_0_1"


    // $ANTLR start "rule__Type__TypeAssignment_1_1"
    // InternalX21.g:4832:1: rule__Type__TypeAssignment_1_1 : ( ( 'string' ) ) ;
    public final void rule__Type__TypeAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4836:1: ( ( ( 'string' ) ) )
            // InternalX21.g:4837:2: ( ( 'string' ) )
            {
            // InternalX21.g:4837:2: ( ( 'string' ) )
            // InternalX21.g:4838:3: ( 'string' )
            {
             before(grammarAccess.getTypeAccess().getTypeStringKeyword_1_1_0()); 
            // InternalX21.g:4839:3: ( 'string' )
            // InternalX21.g:4840:4: 'string'
            {
             before(grammarAccess.getTypeAccess().getTypeStringKeyword_1_1_0()); 
            match(input,47,FOLLOW_2); 
             after(grammarAccess.getTypeAccess().getTypeStringKeyword_1_1_0()); 

            }

             after(grammarAccess.getTypeAccess().getTypeStringKeyword_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__TypeAssignment_1_1"


    // $ANTLR start "rule__Type__RefAssignment_2"
    // InternalX21.g:4851:1: rule__Type__RefAssignment_2 : ( ( RULE_ID ) ) ;
    public final void rule__Type__RefAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4855:1: ( ( ( RULE_ID ) ) )
            // InternalX21.g:4856:2: ( ( RULE_ID ) )
            {
            // InternalX21.g:4856:2: ( ( RULE_ID ) )
            // InternalX21.g:4857:3: ( RULE_ID )
            {
             before(grammarAccess.getTypeAccess().getRefDataDeclCrossReference_2_0()); 
            // InternalX21.g:4858:3: ( RULE_ID )
            // InternalX21.g:4859:4: RULE_ID
            {
             before(grammarAccess.getTypeAccess().getRefDataDeclIDTerminalRuleCall_2_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTypeAccess().getRefDataDeclIDTerminalRuleCall_2_0_1()); 

            }

             after(grammarAccess.getTypeAccess().getRefDataDeclCrossReference_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__RefAssignment_2"


    // $ANTLR start "rule__SubAddExp__RightAssignment_1_1"
    // InternalX21.g:4870:1: rule__SubAddExp__RightAssignment_1_1 : ( ruleDivMultExp ) ;
    public final void rule__SubAddExp__RightAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4874:1: ( ( ruleDivMultExp ) )
            // InternalX21.g:4875:2: ( ruleDivMultExp )
            {
            // InternalX21.g:4875:2: ( ruleDivMultExp )
            // InternalX21.g:4876:3: ruleDivMultExp
            {
             before(grammarAccess.getSubAddExpAccess().getRightDivMultExpParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_2);
            ruleDivMultExp();

            state._fsp--;

             after(grammarAccess.getSubAddExpAccess().getRightDivMultExpParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SubAddExp__RightAssignment_1_1"


    // $ANTLR start "rule__DivMultExp__RightAssignment_1_1"
    // InternalX21.g:4885:1: rule__DivMultExp__RightAssignment_1_1 : ( rulePrimary ) ;
    public final void rule__DivMultExp__RightAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4889:1: ( ( rulePrimary ) )
            // InternalX21.g:4890:2: ( rulePrimary )
            {
            // InternalX21.g:4890:2: ( rulePrimary )
            // InternalX21.g:4891:3: rulePrimary
            {
             before(grammarAccess.getDivMultExpAccess().getRightPrimaryParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_2);
            rulePrimary();

            state._fsp--;

             after(grammarAccess.getDivMultExpAccess().getRightPrimaryParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DivMultExp__RightAssignment_1_1"


    // $ANTLR start "rule__Ifstatement__LogicExpAssignment_2"
    // InternalX21.g:4900:1: rule__Ifstatement__LogicExpAssignment_2 : ( ruleLogicExp ) ;
    public final void rule__Ifstatement__LogicExpAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4904:1: ( ( ruleLogicExp ) )
            // InternalX21.g:4905:2: ( ruleLogicExp )
            {
            // InternalX21.g:4905:2: ( ruleLogicExp )
            // InternalX21.g:4906:3: ruleLogicExp
            {
             before(grammarAccess.getIfstatementAccess().getLogicExpLogicExpParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleLogicExp();

            state._fsp--;

             after(grammarAccess.getIfstatementAccess().getLogicExpLogicExpParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__LogicExpAssignment_2"


    // $ANTLR start "rule__Ifstatement__ExpAssignment_4"
    // InternalX21.g:4915:1: rule__Ifstatement__ExpAssignment_4 : ( ruleExp ) ;
    public final void rule__Ifstatement__ExpAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4919:1: ( ( ruleExp ) )
            // InternalX21.g:4920:2: ( ruleExp )
            {
            // InternalX21.g:4920:2: ( ruleExp )
            // InternalX21.g:4921:3: ruleExp
            {
             before(grammarAccess.getIfstatementAccess().getExpExpParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleExp();

            state._fsp--;

             after(grammarAccess.getIfstatementAccess().getExpExpParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__ExpAssignment_4"


    // $ANTLR start "rule__Ifstatement__ElseExpAssignment_6"
    // InternalX21.g:4930:1: rule__Ifstatement__ElseExpAssignment_6 : ( ruleExp ) ;
    public final void rule__Ifstatement__ElseExpAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4934:1: ( ( ruleExp ) )
            // InternalX21.g:4935:2: ( ruleExp )
            {
            // InternalX21.g:4935:2: ( ruleExp )
            // InternalX21.g:4936:3: ruleExp
            {
             before(grammarAccess.getIfstatementAccess().getElseExpExpParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleExp();

            state._fsp--;

             after(grammarAccess.getIfstatementAccess().getElseExpExpParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ifstatement__ElseExpAssignment_6"


    // $ANTLR start "rule__Parenthesis__InnerAssignment_2"
    // InternalX21.g:4945:1: rule__Parenthesis__InnerAssignment_2 : ( ruleExp ) ;
    public final void rule__Parenthesis__InnerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4949:1: ( ( ruleExp ) )
            // InternalX21.g:4950:2: ( ruleExp )
            {
            // InternalX21.g:4950:2: ( ruleExp )
            // InternalX21.g:4951:3: ruleExp
            {
             before(grammarAccess.getParenthesisAccess().getInnerExpParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleExp();

            state._fsp--;

             after(grammarAccess.getParenthesisAccess().getInnerExpParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parenthesis__InnerAssignment_2"


    // $ANTLR start "rule__Number__ValueAssignment_1"
    // InternalX21.g:4960:1: rule__Number__ValueAssignment_1 : ( RULE_INT ) ;
    public final void rule__Number__ValueAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4964:1: ( ( RULE_INT ) )
            // InternalX21.g:4965:2: ( RULE_INT )
            {
            // InternalX21.g:4965:2: ( RULE_INT )
            // InternalX21.g:4966:3: RULE_INT
            {
             before(grammarAccess.getNumberAccess().getValueINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getNumberAccess().getValueINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Number__ValueAssignment_1"


    // $ANTLR start "rule__Let__NameAssignment_2"
    // InternalX21.g:4975:1: rule__Let__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__Let__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4979:1: ( ( RULE_ID ) )
            // InternalX21.g:4980:2: ( RULE_ID )
            {
            // InternalX21.g:4980:2: ( RULE_ID )
            // InternalX21.g:4981:3: RULE_ID
            {
             before(grammarAccess.getLetAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getLetAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__NameAssignment_2"


    // $ANTLR start "rule__Let__DefAssignment_4"
    // InternalX21.g:4990:1: rule__Let__DefAssignment_4 : ( ruleExp ) ;
    public final void rule__Let__DefAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:4994:1: ( ( ruleExp ) )
            // InternalX21.g:4995:2: ( ruleExp )
            {
            // InternalX21.g:4995:2: ( ruleExp )
            // InternalX21.g:4996:3: ruleExp
            {
             before(grammarAccess.getLetAccess().getDefExpParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleExp();

            state._fsp--;

             after(grammarAccess.getLetAccess().getDefExpParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__DefAssignment_4"


    // $ANTLR start "rule__Let__BodyAssignment_6"
    // InternalX21.g:5005:1: rule__Let__BodyAssignment_6 : ( ruleExp ) ;
    public final void rule__Let__BodyAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:5009:1: ( ( ruleExp ) )
            // InternalX21.g:5010:2: ( ruleExp )
            {
            // InternalX21.g:5010:2: ( ruleExp )
            // InternalX21.g:5011:3: ruleExp
            {
             before(grammarAccess.getLetAccess().getBodyExpParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleExp();

            state._fsp--;

             after(grammarAccess.getLetAccess().getBodyExpParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Let__BodyAssignment_6"


    // $ANTLR start "rule__VariableAssignment__TypeAssignment_2"
    // InternalX21.g:5020:1: rule__VariableAssignment__TypeAssignment_2 : ( ( RULE_ID ) ) ;
    public final void rule__VariableAssignment__TypeAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:5024:1: ( ( ( RULE_ID ) ) )
            // InternalX21.g:5025:2: ( ( RULE_ID ) )
            {
            // InternalX21.g:5025:2: ( ( RULE_ID ) )
            // InternalX21.g:5026:3: ( RULE_ID )
            {
             before(grammarAccess.getVariableAssignmentAccess().getTypeDataDeclCrossReference_2_0()); 
            // InternalX21.g:5027:3: ( RULE_ID )
            // InternalX21.g:5028:4: RULE_ID
            {
             before(grammarAccess.getVariableAssignmentAccess().getTypeDataDeclIDTerminalRuleCall_2_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getVariableAssignmentAccess().getTypeDataDeclIDTerminalRuleCall_2_0_1()); 

            }

             after(grammarAccess.getVariableAssignmentAccess().getTypeDataDeclCrossReference_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__TypeAssignment_2"


    // $ANTLR start "rule__VariableAssignment__AttrAssignment_4"
    // InternalX21.g:5039:1: rule__VariableAssignment__AttrAssignment_4 : ( ( RULE_ID ) ) ;
    public final void rule__VariableAssignment__AttrAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:5043:1: ( ( ( RULE_ID ) ) )
            // InternalX21.g:5044:2: ( ( RULE_ID ) )
            {
            // InternalX21.g:5044:2: ( ( RULE_ID ) )
            // InternalX21.g:5045:3: ( RULE_ID )
            {
             before(grammarAccess.getVariableAssignmentAccess().getAttrInternalParameterCrossReference_4_0()); 
            // InternalX21.g:5046:3: ( RULE_ID )
            // InternalX21.g:5047:4: RULE_ID
            {
             before(grammarAccess.getVariableAssignmentAccess().getAttrInternalParameterIDTerminalRuleCall_4_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getVariableAssignmentAccess().getAttrInternalParameterIDTerminalRuleCall_4_0_1()); 

            }

             after(grammarAccess.getVariableAssignmentAccess().getAttrInternalParameterCrossReference_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__AttrAssignment_4"


    // $ANTLR start "rule__VariableAssignment__ValueAssignment_6"
    // InternalX21.g:5058:1: rule__VariableAssignment__ValueAssignment_6 : ( ruleExp ) ;
    public final void rule__VariableAssignment__ValueAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:5062:1: ( ( ruleExp ) )
            // InternalX21.g:5063:2: ( ruleExp )
            {
            // InternalX21.g:5063:2: ( ruleExp )
            // InternalX21.g:5064:3: ruleExp
            {
             before(grammarAccess.getVariableAssignmentAccess().getValueExpParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleExp();

            state._fsp--;

             after(grammarAccess.getVariableAssignmentAccess().getValueExpParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__ValueAssignment_6"


    // $ANTLR start "rule__VariableAssignment__AttrAssignment_7_1"
    // InternalX21.g:5073:1: rule__VariableAssignment__AttrAssignment_7_1 : ( ( RULE_ID ) ) ;
    public final void rule__VariableAssignment__AttrAssignment_7_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:5077:1: ( ( ( RULE_ID ) ) )
            // InternalX21.g:5078:2: ( ( RULE_ID ) )
            {
            // InternalX21.g:5078:2: ( ( RULE_ID ) )
            // InternalX21.g:5079:3: ( RULE_ID )
            {
             before(grammarAccess.getVariableAssignmentAccess().getAttrInternalParameterCrossReference_7_1_0()); 
            // InternalX21.g:5080:3: ( RULE_ID )
            // InternalX21.g:5081:4: RULE_ID
            {
             before(grammarAccess.getVariableAssignmentAccess().getAttrInternalParameterIDTerminalRuleCall_7_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getVariableAssignmentAccess().getAttrInternalParameterIDTerminalRuleCall_7_1_0_1()); 

            }

             after(grammarAccess.getVariableAssignmentAccess().getAttrInternalParameterCrossReference_7_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__AttrAssignment_7_1"


    // $ANTLR start "rule__VariableAssignment__ValueAssignment_7_3"
    // InternalX21.g:5092:1: rule__VariableAssignment__ValueAssignment_7_3 : ( ruleExp ) ;
    public final void rule__VariableAssignment__ValueAssignment_7_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:5096:1: ( ( ruleExp ) )
            // InternalX21.g:5097:2: ( ruleExp )
            {
            // InternalX21.g:5097:2: ( ruleExp )
            // InternalX21.g:5098:3: ruleExp
            {
             before(grammarAccess.getVariableAssignmentAccess().getValueExpParserRuleCall_7_3_0()); 
            pushFollow(FOLLOW_2);
            ruleExp();

            state._fsp--;

             after(grammarAccess.getVariableAssignmentAccess().getValueExpParserRuleCall_7_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableAssignment__ValueAssignment_7_3"


    // $ANTLR start "rule__VariableUse__RefAssignment"
    // InternalX21.g:5107:1: rule__VariableUse__RefAssignment : ( ( RULE_ID ) ) ;
    public final void rule__VariableUse__RefAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:5111:1: ( ( ( RULE_ID ) ) )
            // InternalX21.g:5112:2: ( ( RULE_ID ) )
            {
            // InternalX21.g:5112:2: ( ( RULE_ID ) )
            // InternalX21.g:5113:3: ( RULE_ID )
            {
             before(grammarAccess.getVariableUseAccess().getRefDefinitionCrossReference_0()); 
            // InternalX21.g:5114:3: ( RULE_ID )
            // InternalX21.g:5115:4: RULE_ID
            {
             before(grammarAccess.getVariableUseAccess().getRefDefinitionIDTerminalRuleCall_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getVariableUseAccess().getRefDefinitionIDTerminalRuleCall_0_1()); 

            }

             after(grammarAccess.getVariableUseAccess().getRefDefinitionCrossReference_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__VariableUse__RefAssignment"


    // $ANTLR start "rule__DataTypeAttribute__SourceAssignment_1"
    // InternalX21.g:5126:1: rule__DataTypeAttribute__SourceAssignment_1 : ( ruleVariableUse ) ;
    public final void rule__DataTypeAttribute__SourceAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:5130:1: ( ( ruleVariableUse ) )
            // InternalX21.g:5131:2: ( ruleVariableUse )
            {
            // InternalX21.g:5131:2: ( ruleVariableUse )
            // InternalX21.g:5132:3: ruleVariableUse
            {
             before(grammarAccess.getDataTypeAttributeAccess().getSourceVariableUseParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleVariableUse();

            state._fsp--;

             after(grammarAccess.getDataTypeAttributeAccess().getSourceVariableUseParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataTypeAttribute__SourceAssignment_1"


    // $ANTLR start "rule__DataTypeAttribute__AttrAssignment_3"
    // InternalX21.g:5141:1: rule__DataTypeAttribute__AttrAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__DataTypeAttribute__AttrAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:5145:1: ( ( ( RULE_ID ) ) )
            // InternalX21.g:5146:2: ( ( RULE_ID ) )
            {
            // InternalX21.g:5146:2: ( ( RULE_ID ) )
            // InternalX21.g:5147:3: ( RULE_ID )
            {
             before(grammarAccess.getDataTypeAttributeAccess().getAttrInternalParameterCrossReference_3_0()); 
            // InternalX21.g:5148:3: ( RULE_ID )
            // InternalX21.g:5149:4: RULE_ID
            {
             before(grammarAccess.getDataTypeAttributeAccess().getAttrInternalParameterIDTerminalRuleCall_3_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getDataTypeAttributeAccess().getAttrInternalParameterIDTerminalRuleCall_3_0_1()); 

            }

             after(grammarAccess.getDataTypeAttributeAccess().getAttrInternalParameterCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataTypeAttribute__AttrAssignment_3"


    // $ANTLR start "rule__LogicExp__LeftAssignment_1"
    // InternalX21.g:5160:1: rule__LogicExp__LeftAssignment_1 : ( ruleExp ) ;
    public final void rule__LogicExp__LeftAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:5164:1: ( ( ruleExp ) )
            // InternalX21.g:5165:2: ( ruleExp )
            {
            // InternalX21.g:5165:2: ( ruleExp )
            // InternalX21.g:5166:3: ruleExp
            {
             before(grammarAccess.getLogicExpAccess().getLeftExpParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleExp();

            state._fsp--;

             after(grammarAccess.getLogicExpAccess().getLeftExpParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicExp__LeftAssignment_1"


    // $ANTLR start "rule__LogicExp__CompAssignment_2"
    // InternalX21.g:5175:1: rule__LogicExp__CompAssignment_2 : ( ruleComparison ) ;
    public final void rule__LogicExp__CompAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:5179:1: ( ( ruleComparison ) )
            // InternalX21.g:5180:2: ( ruleComparison )
            {
            // InternalX21.g:5180:2: ( ruleComparison )
            // InternalX21.g:5181:3: ruleComparison
            {
             before(grammarAccess.getLogicExpAccess().getCompComparisonParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleComparison();

            state._fsp--;

             after(grammarAccess.getLogicExpAccess().getCompComparisonParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicExp__CompAssignment_2"


    // $ANTLR start "rule__LogicExp__RightAssignment_3"
    // InternalX21.g:5190:1: rule__LogicExp__RightAssignment_3 : ( ruleExp ) ;
    public final void rule__LogicExp__RightAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalX21.g:5194:1: ( ( ruleExp ) )
            // InternalX21.g:5195:2: ( ruleExp )
            {
            // InternalX21.g:5195:2: ( ruleExp )
            // InternalX21.g:5196:3: ruleExp
            {
             before(grammarAccess.getLogicExpAccess().getRightExpParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleExp();

            state._fsp--;

             after(grammarAccess.getLogicExpAccess().getRightExpParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicExp__RightAssignment_3"

    // Delegated rules


    protected DFA8 dfa8 = new DFA8(this);
    static final String dfa_1s = "\12\uffff";
    static final String dfa_2s = "\3\uffff\1\11\6\uffff";
    static final String dfa_3s = "\1\4\2\uffff\1\13\6\uffff";
    static final String dfa_4s = "\1\54\2\uffff\1\55\6\uffff";
    static final String dfa_5s = "\1\uffff\1\1\1\2\1\uffff\1\4\1\5\1\6\1\7\1\10\1\3";
    static final String dfa_6s = "\12\uffff}>";
    static final String[] dfa_7s = {
            "\1\3\1\1\16\uffff\1\2\20\uffff\1\7\1\6\3\uffff\1\4\1\uffff\1\5",
            "",
            "",
            "\5\11\5\uffff\1\11\1\uffff\1\11\3\uffff\1\11\1\uffff\1\11\3\uffff\4\11\2\uffff\3\11\1\uffff\1\11\1\uffff\1\10",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final short[] dfa_2 = DFA.unpackEncodedString(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final char[] dfa_4 = DFA.unpackEncodedStringToUnsignedChars(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[] dfa_6 = DFA.unpackEncodedString(dfa_6s);
    static final short[][] dfa_7 = unpackEncodedStringArray(dfa_7s);

    class DFA8 extends DFA {

        public DFA8(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 8;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "910:1: rule__Primary__Alternatives : ( ( ruleNumber ) | ( ruleParenthesis ) | ( ruleVariableUse ) | ( ruleLet ) | ( ruleVariableAssignment ) | ( ruleIfstatement ) | ( ruleNone ) | ( ruleDataTypeAttribute ) );";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x00000001430A0000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x00000001430A0002L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000C00000000010L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000146000100030L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000100010L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000084000010L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000020000002L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000030000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000030000002L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000020800000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000600000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000600000002L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000001800000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000001800000002L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000028000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x000000000000F800L});

}