package dk.sdu.mmmi.olnor18.x21.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import dk.sdu.mmmi.olnor18.x21.services.X21GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalX21Parser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'program'", "'parameter'", "':'", "'function'", "'('", "')'", "'{'", "'}'", "'input'", "'node'", "'['", "']'", "'to'", "','", "'stream'", "'output'", "'data'", "'int'", "'string'", "'-'", "'+'", "'/'", "'*'", "'none'", "'if'", "'then'", "'else'", "'end'", "'let'", "'='", "'in'", "'new'", "'.'", "'<'", "'>'", "'<='", "'>='"
    };
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=5;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalX21Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalX21Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalX21Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalX21.g"; }



     	private X21GrammarAccess grammarAccess;

        public InternalX21Parser(TokenStream input, X21GrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Program";
       	}

       	@Override
       	protected X21GrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleProgram"
    // InternalX21.g:64:1: entryRuleProgram returns [EObject current=null] : iv_ruleProgram= ruleProgram EOF ;
    public final EObject entryRuleProgram() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProgram = null;


        try {
            // InternalX21.g:64:48: (iv_ruleProgram= ruleProgram EOF )
            // InternalX21.g:65:2: iv_ruleProgram= ruleProgram EOF
            {
             newCompositeNode(grammarAccess.getProgramRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProgram=ruleProgram();

            state._fsp--;

             current =iv_ruleProgram; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProgram"


    // $ANTLR start "ruleProgram"
    // InternalX21.g:71:1: ruleProgram returns [EObject current=null] : ( () otherlv_1= 'program' ( (lv_name_2_0= RULE_ID ) ) ( (lv_declarations_3_0= ruleDeclaration ) )* ) ;
    public final EObject ruleProgram() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_name_2_0=null;
        EObject lv_declarations_3_0 = null;



        	enterRule();

        try {
            // InternalX21.g:77:2: ( ( () otherlv_1= 'program' ( (lv_name_2_0= RULE_ID ) ) ( (lv_declarations_3_0= ruleDeclaration ) )* ) )
            // InternalX21.g:78:2: ( () otherlv_1= 'program' ( (lv_name_2_0= RULE_ID ) ) ( (lv_declarations_3_0= ruleDeclaration ) )* )
            {
            // InternalX21.g:78:2: ( () otherlv_1= 'program' ( (lv_name_2_0= RULE_ID ) ) ( (lv_declarations_3_0= ruleDeclaration ) )* )
            // InternalX21.g:79:3: () otherlv_1= 'program' ( (lv_name_2_0= RULE_ID ) ) ( (lv_declarations_3_0= ruleDeclaration ) )*
            {
            // InternalX21.g:79:3: ()
            // InternalX21.g:80:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getProgramAccess().getProgramAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getProgramAccess().getProgramKeyword_1());
            		
            // InternalX21.g:90:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalX21.g:91:4: (lv_name_2_0= RULE_ID )
            {
            // InternalX21.g:91:4: (lv_name_2_0= RULE_ID )
            // InternalX21.g:92:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(lv_name_2_0, grammarAccess.getProgramAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getProgramRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalX21.g:108:3: ( (lv_declarations_3_0= ruleDeclaration ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==12||LA1_0==14||(LA1_0>=19 && LA1_0<=20)||LA1_0==25||LA1_0==27) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalX21.g:109:4: (lv_declarations_3_0= ruleDeclaration )
            	    {
            	    // InternalX21.g:109:4: (lv_declarations_3_0= ruleDeclaration )
            	    // InternalX21.g:110:5: lv_declarations_3_0= ruleDeclaration
            	    {

            	    					newCompositeNode(grammarAccess.getProgramAccess().getDeclarationsDeclarationParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_declarations_3_0=ruleDeclaration();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getProgramRule());
            	    					}
            	    					add(
            	    						current,
            	    						"declarations",
            	    						lv_declarations_3_0,
            	    						"dk.sdu.mmmi.olnor18.x21.X21.Declaration");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProgram"


    // $ANTLR start "entryRuleDeclaration"
    // InternalX21.g:131:1: entryRuleDeclaration returns [EObject current=null] : iv_ruleDeclaration= ruleDeclaration EOF ;
    public final EObject entryRuleDeclaration() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDeclaration = null;


        try {
            // InternalX21.g:131:52: (iv_ruleDeclaration= ruleDeclaration EOF )
            // InternalX21.g:132:2: iv_ruleDeclaration= ruleDeclaration EOF
            {
             newCompositeNode(grammarAccess.getDeclarationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDeclaration=ruleDeclaration();

            state._fsp--;

             current =iv_ruleDeclaration; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDeclaration"


    // $ANTLR start "ruleDeclaration"
    // InternalX21.g:138:1: ruleDeclaration returns [EObject current=null] : (this_Function_0= ruleFunction | this_Input_1= ruleInput | this_Node_2= ruleNode | this_Stream_3= ruleStream | this_DataDecl_4= ruleDataDecl | this_Parameter_5= ruleParameter ) ;
    public final EObject ruleDeclaration() throws RecognitionException {
        EObject current = null;

        EObject this_Function_0 = null;

        EObject this_Input_1 = null;

        EObject this_Node_2 = null;

        EObject this_Stream_3 = null;

        EObject this_DataDecl_4 = null;

        EObject this_Parameter_5 = null;



        	enterRule();

        try {
            // InternalX21.g:144:2: ( (this_Function_0= ruleFunction | this_Input_1= ruleInput | this_Node_2= ruleNode | this_Stream_3= ruleStream | this_DataDecl_4= ruleDataDecl | this_Parameter_5= ruleParameter ) )
            // InternalX21.g:145:2: (this_Function_0= ruleFunction | this_Input_1= ruleInput | this_Node_2= ruleNode | this_Stream_3= ruleStream | this_DataDecl_4= ruleDataDecl | this_Parameter_5= ruleParameter )
            {
            // InternalX21.g:145:2: (this_Function_0= ruleFunction | this_Input_1= ruleInput | this_Node_2= ruleNode | this_Stream_3= ruleStream | this_DataDecl_4= ruleDataDecl | this_Parameter_5= ruleParameter )
            int alt2=6;
            switch ( input.LA(1) ) {
            case 14:
                {
                alt2=1;
                }
                break;
            case 19:
                {
                alt2=2;
                }
                break;
            case 20:
                {
                alt2=3;
                }
                break;
            case 25:
                {
                alt2=4;
                }
                break;
            case 27:
                {
                alt2=5;
                }
                break;
            case 12:
                {
                alt2=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalX21.g:146:3: this_Function_0= ruleFunction
                    {

                    			newCompositeNode(grammarAccess.getDeclarationAccess().getFunctionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Function_0=ruleFunction();

                    state._fsp--;


                    			current = this_Function_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalX21.g:155:3: this_Input_1= ruleInput
                    {

                    			newCompositeNode(grammarAccess.getDeclarationAccess().getInputParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Input_1=ruleInput();

                    state._fsp--;


                    			current = this_Input_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalX21.g:164:3: this_Node_2= ruleNode
                    {

                    			newCompositeNode(grammarAccess.getDeclarationAccess().getNodeParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_Node_2=ruleNode();

                    state._fsp--;


                    			current = this_Node_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalX21.g:173:3: this_Stream_3= ruleStream
                    {

                    			newCompositeNode(grammarAccess.getDeclarationAccess().getStreamParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_Stream_3=ruleStream();

                    state._fsp--;


                    			current = this_Stream_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalX21.g:182:3: this_DataDecl_4= ruleDataDecl
                    {

                    			newCompositeNode(grammarAccess.getDeclarationAccess().getDataDeclParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_DataDecl_4=ruleDataDecl();

                    state._fsp--;


                    			current = this_DataDecl_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalX21.g:191:3: this_Parameter_5= ruleParameter
                    {

                    			newCompositeNode(grammarAccess.getDeclarationAccess().getParameterParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_Parameter_5=ruleParameter();

                    state._fsp--;


                    			current = this_Parameter_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDeclaration"


    // $ANTLR start "entryRuleParameter"
    // InternalX21.g:203:1: entryRuleParameter returns [EObject current=null] : iv_ruleParameter= ruleParameter EOF ;
    public final EObject entryRuleParameter() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleParameter = null;


        try {
            // InternalX21.g:203:50: (iv_ruleParameter= ruleParameter EOF )
            // InternalX21.g:204:2: iv_ruleParameter= ruleParameter EOF
            {
             newCompositeNode(grammarAccess.getParameterRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleParameter=ruleParameter();

            state._fsp--;

             current =iv_ruleParameter; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleParameter"


    // $ANTLR start "ruleParameter"
    // InternalX21.g:210:1: ruleParameter returns [EObject current=null] : (otherlv_0= 'parameter' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) ) ) ;
    public final EObject ruleParameter() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        EObject lv_type_3_0 = null;



        	enterRule();

        try {
            // InternalX21.g:216:2: ( (otherlv_0= 'parameter' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) ) ) )
            // InternalX21.g:217:2: (otherlv_0= 'parameter' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) ) )
            {
            // InternalX21.g:217:2: (otherlv_0= 'parameter' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) ) )
            // InternalX21.g:218:3: otherlv_0= 'parameter' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) )
            {
            otherlv_0=(Token)match(input,12,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getParameterAccess().getParameterKeyword_0());
            		
            // InternalX21.g:222:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalX21.g:223:4: (lv_name_1_0= RULE_ID )
            {
            // InternalX21.g:223:4: (lv_name_1_0= RULE_ID )
            // InternalX21.g:224:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getParameterAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getParameterRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getParameterAccess().getColonKeyword_2());
            		
            // InternalX21.g:244:3: ( (lv_type_3_0= ruleType ) )
            // InternalX21.g:245:4: (lv_type_3_0= ruleType )
            {
            // InternalX21.g:245:4: (lv_type_3_0= ruleType )
            // InternalX21.g:246:5: lv_type_3_0= ruleType
            {

            					newCompositeNode(grammarAccess.getParameterAccess().getTypeTypeParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_type_3_0=ruleType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getParameterRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_3_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Type");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleParameter"


    // $ANTLR start "entryRuleInternalParameter"
    // InternalX21.g:267:1: entryRuleInternalParameter returns [EObject current=null] : iv_ruleInternalParameter= ruleInternalParameter EOF ;
    public final EObject entryRuleInternalParameter() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInternalParameter = null;


        try {
            // InternalX21.g:267:58: (iv_ruleInternalParameter= ruleInternalParameter EOF )
            // InternalX21.g:268:2: iv_ruleInternalParameter= ruleInternalParameter EOF
            {
             newCompositeNode(grammarAccess.getInternalParameterRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInternalParameter=ruleInternalParameter();

            state._fsp--;

             current =iv_ruleInternalParameter; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInternalParameter"


    // $ANTLR start "ruleInternalParameter"
    // InternalX21.g:274:1: ruleInternalParameter returns [EObject current=null] : ( () ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) ) ) ;
    public final EObject ruleInternalParameter() throws RecognitionException {
        EObject current = null;

        Token lv_name_1_0=null;
        Token otherlv_2=null;
        EObject lv_type_3_0 = null;



        	enterRule();

        try {
            // InternalX21.g:280:2: ( ( () ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) ) ) )
            // InternalX21.g:281:2: ( () ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) ) )
            {
            // InternalX21.g:281:2: ( () ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) ) )
            // InternalX21.g:282:3: () ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) )
            {
            // InternalX21.g:282:3: ()
            // InternalX21.g:283:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getInternalParameterAccess().getInternalParameterAction_0(),
            					current);
            			

            }

            // InternalX21.g:289:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalX21.g:290:4: (lv_name_1_0= RULE_ID )
            {
            // InternalX21.g:290:4: (lv_name_1_0= RULE_ID )
            // InternalX21.g:291:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getInternalParameterAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInternalParameterRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getInternalParameterAccess().getColonKeyword_2());
            		
            // InternalX21.g:311:3: ( (lv_type_3_0= ruleType ) )
            // InternalX21.g:312:4: (lv_type_3_0= ruleType )
            {
            // InternalX21.g:312:4: (lv_type_3_0= ruleType )
            // InternalX21.g:313:5: lv_type_3_0= ruleType
            {

            					newCompositeNode(grammarAccess.getInternalParameterAccess().getTypeTypeParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_type_3_0=ruleType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getInternalParameterRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_3_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Type");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInternalParameter"


    // $ANTLR start "entryRuleFunction"
    // InternalX21.g:334:1: entryRuleFunction returns [EObject current=null] : iv_ruleFunction= ruleFunction EOF ;
    public final EObject entryRuleFunction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFunction = null;


        try {
            // InternalX21.g:334:49: (iv_ruleFunction= ruleFunction EOF )
            // InternalX21.g:335:2: iv_ruleFunction= ruleFunction EOF
            {
             newCompositeNode(grammarAccess.getFunctionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFunction=ruleFunction();

            state._fsp--;

             current =iv_ruleFunction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFunction"


    // $ANTLR start "ruleFunction"
    // InternalX21.g:341:1: ruleFunction returns [EObject current=null] : (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) ( (lv_lambda_2_0= ruleLambda ) ) ) ;
    public final EObject ruleFunction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        EObject lv_lambda_2_0 = null;



        	enterRule();

        try {
            // InternalX21.g:347:2: ( (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) ( (lv_lambda_2_0= ruleLambda ) ) ) )
            // InternalX21.g:348:2: (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) ( (lv_lambda_2_0= ruleLambda ) ) )
            {
            // InternalX21.g:348:2: (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) ( (lv_lambda_2_0= ruleLambda ) ) )
            // InternalX21.g:349:3: otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) ( (lv_lambda_2_0= ruleLambda ) )
            {
            otherlv_0=(Token)match(input,14,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getFunctionAccess().getFunctionKeyword_0());
            		
            // InternalX21.g:353:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalX21.g:354:4: (lv_name_1_0= RULE_ID )
            {
            // InternalX21.g:354:4: (lv_name_1_0= RULE_ID )
            // InternalX21.g:355:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_7); 

            					newLeafNode(lv_name_1_0, grammarAccess.getFunctionAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFunctionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalX21.g:371:3: ( (lv_lambda_2_0= ruleLambda ) )
            // InternalX21.g:372:4: (lv_lambda_2_0= ruleLambda )
            {
            // InternalX21.g:372:4: (lv_lambda_2_0= ruleLambda )
            // InternalX21.g:373:5: lv_lambda_2_0= ruleLambda
            {

            					newCompositeNode(grammarAccess.getFunctionAccess().getLambdaLambdaParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_lambda_2_0=ruleLambda();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFunctionRule());
            					}
            					set(
            						current,
            						"lambda",
            						lv_lambda_2_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Lambda");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFunction"


    // $ANTLR start "entryRuleLambda"
    // InternalX21.g:394:1: entryRuleLambda returns [EObject current=null] : iv_ruleLambda= ruleLambda EOF ;
    public final EObject entryRuleLambda() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLambda = null;


        try {
            // InternalX21.g:394:47: (iv_ruleLambda= ruleLambda EOF )
            // InternalX21.g:395:2: iv_ruleLambda= ruleLambda EOF
            {
             newCompositeNode(grammarAccess.getLambdaRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLambda=ruleLambda();

            state._fsp--;

             current =iv_ruleLambda; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLambda"


    // $ANTLR start "ruleLambda"
    // InternalX21.g:401:1: ruleLambda returns [EObject current=null] : (otherlv_0= '(' ( (lv_parameter_1_0= ruleInternalParameter ) ) otherlv_2= ')' otherlv_3= '{' ( (lv_exp_4_0= ruleExp ) ) otherlv_5= '}' ) ;
    public final EObject ruleLambda() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_parameter_1_0 = null;

        EObject lv_exp_4_0 = null;



        	enterRule();

        try {
            // InternalX21.g:407:2: ( (otherlv_0= '(' ( (lv_parameter_1_0= ruleInternalParameter ) ) otherlv_2= ')' otherlv_3= '{' ( (lv_exp_4_0= ruleExp ) ) otherlv_5= '}' ) )
            // InternalX21.g:408:2: (otherlv_0= '(' ( (lv_parameter_1_0= ruleInternalParameter ) ) otherlv_2= ')' otherlv_3= '{' ( (lv_exp_4_0= ruleExp ) ) otherlv_5= '}' )
            {
            // InternalX21.g:408:2: (otherlv_0= '(' ( (lv_parameter_1_0= ruleInternalParameter ) ) otherlv_2= ')' otherlv_3= '{' ( (lv_exp_4_0= ruleExp ) ) otherlv_5= '}' )
            // InternalX21.g:409:3: otherlv_0= '(' ( (lv_parameter_1_0= ruleInternalParameter ) ) otherlv_2= ')' otherlv_3= '{' ( (lv_exp_4_0= ruleExp ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,15,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getLambdaAccess().getLeftParenthesisKeyword_0());
            		
            // InternalX21.g:413:3: ( (lv_parameter_1_0= ruleInternalParameter ) )
            // InternalX21.g:414:4: (lv_parameter_1_0= ruleInternalParameter )
            {
            // InternalX21.g:414:4: (lv_parameter_1_0= ruleInternalParameter )
            // InternalX21.g:415:5: lv_parameter_1_0= ruleInternalParameter
            {

            					newCompositeNode(grammarAccess.getLambdaAccess().getParameterInternalParameterParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_8);
            lv_parameter_1_0=ruleInternalParameter();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getLambdaRule());
            					}
            					set(
            						current,
            						"parameter",
            						lv_parameter_1_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.InternalParameter");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,16,FOLLOW_9); 

            			newLeafNode(otherlv_2, grammarAccess.getLambdaAccess().getRightParenthesisKeyword_2());
            		
            otherlv_3=(Token)match(input,17,FOLLOW_10); 

            			newLeafNode(otherlv_3, grammarAccess.getLambdaAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalX21.g:440:3: ( (lv_exp_4_0= ruleExp ) )
            // InternalX21.g:441:4: (lv_exp_4_0= ruleExp )
            {
            // InternalX21.g:441:4: (lv_exp_4_0= ruleExp )
            // InternalX21.g:442:5: lv_exp_4_0= ruleExp
            {

            					newCompositeNode(grammarAccess.getLambdaAccess().getExpExpParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_11);
            lv_exp_4_0=ruleExp();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getLambdaRule());
            					}
            					set(
            						current,
            						"exp",
            						lv_exp_4_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Exp");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getLambdaAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLambda"


    // $ANTLR start "entryRuleInput"
    // InternalX21.g:467:1: entryRuleInput returns [EObject current=null] : iv_ruleInput= ruleInput EOF ;
    public final EObject entryRuleInput() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInput = null;


        try {
            // InternalX21.g:467:46: (iv_ruleInput= ruleInput EOF )
            // InternalX21.g:468:2: iv_ruleInput= ruleInput EOF
            {
             newCompositeNode(grammarAccess.getInputRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInput=ruleInput();

            state._fsp--;

             current =iv_ruleInput; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInput"


    // $ANTLR start "ruleInput"
    // InternalX21.g:474:1: ruleInput returns [EObject current=null] : (otherlv_0= 'input' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) ) ) ;
    public final EObject ruleInput() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        EObject lv_type_3_0 = null;



        	enterRule();

        try {
            // InternalX21.g:480:2: ( (otherlv_0= 'input' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) ) ) )
            // InternalX21.g:481:2: (otherlv_0= 'input' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) ) )
            {
            // InternalX21.g:481:2: (otherlv_0= 'input' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) ) )
            // InternalX21.g:482:3: otherlv_0= 'input' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleType ) )
            {
            otherlv_0=(Token)match(input,19,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getInputAccess().getInputKeyword_0());
            		
            // InternalX21.g:486:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalX21.g:487:4: (lv_name_1_0= RULE_ID )
            {
            // InternalX21.g:487:4: (lv_name_1_0= RULE_ID )
            // InternalX21.g:488:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getInputAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInputRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getInputAccess().getColonKeyword_2());
            		
            // InternalX21.g:508:3: ( (lv_type_3_0= ruleType ) )
            // InternalX21.g:509:4: (lv_type_3_0= ruleType )
            {
            // InternalX21.g:509:4: (lv_type_3_0= ruleType )
            // InternalX21.g:510:5: lv_type_3_0= ruleType
            {

            					newCompositeNode(grammarAccess.getInputAccess().getTypeTypeParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_type_3_0=ruleType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getInputRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_3_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Type");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInput"


    // $ANTLR start "entryRuleNode"
    // InternalX21.g:531:1: entryRuleNode returns [EObject current=null] : iv_ruleNode= ruleNode EOF ;
    public final EObject entryRuleNode() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNode = null;


        try {
            // InternalX21.g:531:45: (iv_ruleNode= ruleNode EOF )
            // InternalX21.g:532:2: iv_ruleNode= ruleNode EOF
            {
             newCompositeNode(grammarAccess.getNodeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNode=ruleNode();

            state._fsp--;

             current =iv_ruleNode; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNode"


    // $ANTLR start "ruleNode"
    // InternalX21.g:538:1: ruleNode returns [EObject current=null] : (otherlv_0= 'node' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '[' ( ( (otherlv_3= RULE_ID ) ) | ( (lv_body_4_0= ruleLambda ) ) ) otherlv_5= ']' ) ;
    public final EObject ruleNode() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_body_4_0 = null;



        	enterRule();

        try {
            // InternalX21.g:544:2: ( (otherlv_0= 'node' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '[' ( ( (otherlv_3= RULE_ID ) ) | ( (lv_body_4_0= ruleLambda ) ) ) otherlv_5= ']' ) )
            // InternalX21.g:545:2: (otherlv_0= 'node' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '[' ( ( (otherlv_3= RULE_ID ) ) | ( (lv_body_4_0= ruleLambda ) ) ) otherlv_5= ']' )
            {
            // InternalX21.g:545:2: (otherlv_0= 'node' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '[' ( ( (otherlv_3= RULE_ID ) ) | ( (lv_body_4_0= ruleLambda ) ) ) otherlv_5= ']' )
            // InternalX21.g:546:3: otherlv_0= 'node' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '[' ( ( (otherlv_3= RULE_ID ) ) | ( (lv_body_4_0= ruleLambda ) ) ) otherlv_5= ']'
            {
            otherlv_0=(Token)match(input,20,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getNodeAccess().getNodeKeyword_0());
            		
            // InternalX21.g:550:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalX21.g:551:4: (lv_name_1_0= RULE_ID )
            {
            // InternalX21.g:551:4: (lv_name_1_0= RULE_ID )
            // InternalX21.g:552:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_12); 

            					newLeafNode(lv_name_1_0, grammarAccess.getNodeAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getNodeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,21,FOLLOW_13); 

            			newLeafNode(otherlv_2, grammarAccess.getNodeAccess().getLeftSquareBracketKeyword_2());
            		
            // InternalX21.g:572:3: ( ( (otherlv_3= RULE_ID ) ) | ( (lv_body_4_0= ruleLambda ) ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==RULE_ID) ) {
                alt3=1;
            }
            else if ( (LA3_0==15) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalX21.g:573:4: ( (otherlv_3= RULE_ID ) )
                    {
                    // InternalX21.g:573:4: ( (otherlv_3= RULE_ID ) )
                    // InternalX21.g:574:5: (otherlv_3= RULE_ID )
                    {
                    // InternalX21.g:574:5: (otherlv_3= RULE_ID )
                    // InternalX21.g:575:6: otherlv_3= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getNodeRule());
                    						}
                    					
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_14); 

                    						newLeafNode(otherlv_3, grammarAccess.getNodeAccess().getRefbodyFunctionCrossReference_3_0_0());
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalX21.g:587:4: ( (lv_body_4_0= ruleLambda ) )
                    {
                    // InternalX21.g:587:4: ( (lv_body_4_0= ruleLambda ) )
                    // InternalX21.g:588:5: (lv_body_4_0= ruleLambda )
                    {
                    // InternalX21.g:588:5: (lv_body_4_0= ruleLambda )
                    // InternalX21.g:589:6: lv_body_4_0= ruleLambda
                    {

                    						newCompositeNode(grammarAccess.getNodeAccess().getBodyLambdaParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_14);
                    lv_body_4_0=ruleLambda();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getNodeRule());
                    						}
                    						set(
                    							current,
                    							"body",
                    							lv_body_4_0,
                    							"dk.sdu.mmmi.olnor18.x21.X21.Lambda");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_5=(Token)match(input,22,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getNodeAccess().getRightSquareBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNode"


    // $ANTLR start "entryRuleStreamOutput"
    // InternalX21.g:615:1: entryRuleStreamOutput returns [EObject current=null] : iv_ruleStreamOutput= ruleStreamOutput EOF ;
    public final EObject entryRuleStreamOutput() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStreamOutput = null;


        try {
            // InternalX21.g:615:53: (iv_ruleStreamOutput= ruleStreamOutput EOF )
            // InternalX21.g:616:2: iv_ruleStreamOutput= ruleStreamOutput EOF
            {
             newCompositeNode(grammarAccess.getStreamOutputRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStreamOutput=ruleStreamOutput();

            state._fsp--;

             current =iv_ruleStreamOutput; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStreamOutput"


    // $ANTLR start "ruleStreamOutput"
    // InternalX21.g:622:1: ruleStreamOutput returns [EObject current=null] : ( () otherlv_1= 'to' ( (lv_targets_2_0= ruleElement ) ) (otherlv_3= ',' ( (lv_targets_4_0= ruleElement ) ) )* ) ;
    public final EObject ruleStreamOutput() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_targets_2_0 = null;

        EObject lv_targets_4_0 = null;



        	enterRule();

        try {
            // InternalX21.g:628:2: ( ( () otherlv_1= 'to' ( (lv_targets_2_0= ruleElement ) ) (otherlv_3= ',' ( (lv_targets_4_0= ruleElement ) ) )* ) )
            // InternalX21.g:629:2: ( () otherlv_1= 'to' ( (lv_targets_2_0= ruleElement ) ) (otherlv_3= ',' ( (lv_targets_4_0= ruleElement ) ) )* )
            {
            // InternalX21.g:629:2: ( () otherlv_1= 'to' ( (lv_targets_2_0= ruleElement ) ) (otherlv_3= ',' ( (lv_targets_4_0= ruleElement ) ) )* )
            // InternalX21.g:630:3: () otherlv_1= 'to' ( (lv_targets_2_0= ruleElement ) ) (otherlv_3= ',' ( (lv_targets_4_0= ruleElement ) ) )*
            {
            // InternalX21.g:630:3: ()
            // InternalX21.g:631:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getStreamOutputAccess().getStreamOutputAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,23,FOLLOW_15); 

            			newLeafNode(otherlv_1, grammarAccess.getStreamOutputAccess().getToKeyword_1());
            		
            // InternalX21.g:641:3: ( (lv_targets_2_0= ruleElement ) )
            // InternalX21.g:642:4: (lv_targets_2_0= ruleElement )
            {
            // InternalX21.g:642:4: (lv_targets_2_0= ruleElement )
            // InternalX21.g:643:5: lv_targets_2_0= ruleElement
            {

            					newCompositeNode(grammarAccess.getStreamOutputAccess().getTargetsElementParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_16);
            lv_targets_2_0=ruleElement();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStreamOutputRule());
            					}
            					add(
            						current,
            						"targets",
            						lv_targets_2_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Element");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalX21.g:660:3: (otherlv_3= ',' ( (lv_targets_4_0= ruleElement ) ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==24) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalX21.g:661:4: otherlv_3= ',' ( (lv_targets_4_0= ruleElement ) )
            	    {
            	    otherlv_3=(Token)match(input,24,FOLLOW_15); 

            	    				newLeafNode(otherlv_3, grammarAccess.getStreamOutputAccess().getCommaKeyword_3_0());
            	    			
            	    // InternalX21.g:665:4: ( (lv_targets_4_0= ruleElement ) )
            	    // InternalX21.g:666:5: (lv_targets_4_0= ruleElement )
            	    {
            	    // InternalX21.g:666:5: (lv_targets_4_0= ruleElement )
            	    // InternalX21.g:667:6: lv_targets_4_0= ruleElement
            	    {

            	    						newCompositeNode(grammarAccess.getStreamOutputAccess().getTargetsElementParserRuleCall_3_1_0());
            	    					
            	    pushFollow(FOLLOW_16);
            	    lv_targets_4_0=ruleElement();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getStreamOutputRule());
            	    						}
            	    						add(
            	    							current,
            	    							"targets",
            	    							lv_targets_4_0,
            	    							"dk.sdu.mmmi.olnor18.x21.X21.Element");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStreamOutput"


    // $ANTLR start "entryRuleStream"
    // InternalX21.g:689:1: entryRuleStream returns [EObject current=null] : iv_ruleStream= ruleStream EOF ;
    public final EObject entryRuleStream() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStream = null;


        try {
            // InternalX21.g:689:47: (iv_ruleStream= ruleStream EOF )
            // InternalX21.g:690:2: iv_ruleStream= ruleStream EOF
            {
             newCompositeNode(grammarAccess.getStreamRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStream=ruleStream();

            state._fsp--;

             current =iv_ruleStream; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStream"


    // $ANTLR start "ruleStream"
    // InternalX21.g:696:1: ruleStream returns [EObject current=null] : ( () otherlv_1= 'stream' ( (otherlv_2= RULE_ID ) ) (otherlv_3= ',' ( (otherlv_4= RULE_ID ) ) )* ( (lv_outputs_5_0= ruleStreamOutput ) )+ ) ;
    public final EObject ruleStream() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        EObject lv_outputs_5_0 = null;



        	enterRule();

        try {
            // InternalX21.g:702:2: ( ( () otherlv_1= 'stream' ( (otherlv_2= RULE_ID ) ) (otherlv_3= ',' ( (otherlv_4= RULE_ID ) ) )* ( (lv_outputs_5_0= ruleStreamOutput ) )+ ) )
            // InternalX21.g:703:2: ( () otherlv_1= 'stream' ( (otherlv_2= RULE_ID ) ) (otherlv_3= ',' ( (otherlv_4= RULE_ID ) ) )* ( (lv_outputs_5_0= ruleStreamOutput ) )+ )
            {
            // InternalX21.g:703:2: ( () otherlv_1= 'stream' ( (otherlv_2= RULE_ID ) ) (otherlv_3= ',' ( (otherlv_4= RULE_ID ) ) )* ( (lv_outputs_5_0= ruleStreamOutput ) )+ )
            // InternalX21.g:704:3: () otherlv_1= 'stream' ( (otherlv_2= RULE_ID ) ) (otherlv_3= ',' ( (otherlv_4= RULE_ID ) ) )* ( (lv_outputs_5_0= ruleStreamOutput ) )+
            {
            // InternalX21.g:704:3: ()
            // InternalX21.g:705:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getStreamAccess().getStreamAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,25,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getStreamAccess().getStreamKeyword_1());
            		
            // InternalX21.g:715:3: ( (otherlv_2= RULE_ID ) )
            // InternalX21.g:716:4: (otherlv_2= RULE_ID )
            {
            // InternalX21.g:716:4: (otherlv_2= RULE_ID )
            // InternalX21.g:717:5: otherlv_2= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getStreamRule());
            					}
            				
            otherlv_2=(Token)match(input,RULE_ID,FOLLOW_17); 

            					newLeafNode(otherlv_2, grammarAccess.getStreamAccess().getOriginsStreamInputCrossReference_2_0());
            				

            }


            }

            // InternalX21.g:728:3: (otherlv_3= ',' ( (otherlv_4= RULE_ID ) ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==24) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalX21.g:729:4: otherlv_3= ',' ( (otherlv_4= RULE_ID ) )
            	    {
            	    otherlv_3=(Token)match(input,24,FOLLOW_3); 

            	    				newLeafNode(otherlv_3, grammarAccess.getStreamAccess().getCommaKeyword_3_0());
            	    			
            	    // InternalX21.g:733:4: ( (otherlv_4= RULE_ID ) )
            	    // InternalX21.g:734:5: (otherlv_4= RULE_ID )
            	    {
            	    // InternalX21.g:734:5: (otherlv_4= RULE_ID )
            	    // InternalX21.g:735:6: otherlv_4= RULE_ID
            	    {

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getStreamRule());
            	    						}
            	    					
            	    otherlv_4=(Token)match(input,RULE_ID,FOLLOW_17); 

            	    						newLeafNode(otherlv_4, grammarAccess.getStreamAccess().getOriginsStreamInputCrossReference_3_1_0());
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            // InternalX21.g:747:3: ( (lv_outputs_5_0= ruleStreamOutput ) )+
            int cnt6=0;
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==23) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalX21.g:748:4: (lv_outputs_5_0= ruleStreamOutput )
            	    {
            	    // InternalX21.g:748:4: (lv_outputs_5_0= ruleStreamOutput )
            	    // InternalX21.g:749:5: lv_outputs_5_0= ruleStreamOutput
            	    {

            	    					newCompositeNode(grammarAccess.getStreamAccess().getOutputsStreamOutputParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_18);
            	    lv_outputs_5_0=ruleStreamOutput();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getStreamRule());
            	    					}
            	    					add(
            	    						current,
            	    						"outputs",
            	    						lv_outputs_5_0,
            	    						"dk.sdu.mmmi.olnor18.x21.X21.StreamOutput");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt6 >= 1 ) break loop6;
                        EarlyExitException eee =
                            new EarlyExitException(6, input);
                        throw eee;
                }
                cnt6++;
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStream"


    // $ANTLR start "entryRuleElement"
    // InternalX21.g:770:1: entryRuleElement returns [EObject current=null] : iv_ruleElement= ruleElement EOF ;
    public final EObject entryRuleElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElement = null;


        try {
            // InternalX21.g:770:48: (iv_ruleElement= ruleElement EOF )
            // InternalX21.g:771:2: iv_ruleElement= ruleElement EOF
            {
             newCompositeNode(grammarAccess.getElementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleElement=ruleElement();

            state._fsp--;

             current =iv_ruleElement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElement"


    // $ANTLR start "ruleElement"
    // InternalX21.g:777:1: ruleElement returns [EObject current=null] : ( ( () ( (otherlv_1= RULE_ID ) ) ) | ( () otherlv_3= '[' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_body_5_0= ruleLambda ) ) ) otherlv_6= ']' ) | ( () otherlv_8= 'output' ( (lv_outputName_9_0= RULE_ID ) ) ) ) ;
    public final EObject ruleElement() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token lv_outputName_9_0=null;
        EObject lv_body_5_0 = null;



        	enterRule();

        try {
            // InternalX21.g:783:2: ( ( ( () ( (otherlv_1= RULE_ID ) ) ) | ( () otherlv_3= '[' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_body_5_0= ruleLambda ) ) ) otherlv_6= ']' ) | ( () otherlv_8= 'output' ( (lv_outputName_9_0= RULE_ID ) ) ) ) )
            // InternalX21.g:784:2: ( ( () ( (otherlv_1= RULE_ID ) ) ) | ( () otherlv_3= '[' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_body_5_0= ruleLambda ) ) ) otherlv_6= ']' ) | ( () otherlv_8= 'output' ( (lv_outputName_9_0= RULE_ID ) ) ) )
            {
            // InternalX21.g:784:2: ( ( () ( (otherlv_1= RULE_ID ) ) ) | ( () otherlv_3= '[' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_body_5_0= ruleLambda ) ) ) otherlv_6= ']' ) | ( () otherlv_8= 'output' ( (lv_outputName_9_0= RULE_ID ) ) ) )
            int alt8=3;
            switch ( input.LA(1) ) {
            case RULE_ID:
                {
                alt8=1;
                }
                break;
            case 21:
                {
                alt8=2;
                }
                break;
            case 26:
                {
                alt8=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // InternalX21.g:785:3: ( () ( (otherlv_1= RULE_ID ) ) )
                    {
                    // InternalX21.g:785:3: ( () ( (otherlv_1= RULE_ID ) ) )
                    // InternalX21.g:786:4: () ( (otherlv_1= RULE_ID ) )
                    {
                    // InternalX21.g:786:4: ()
                    // InternalX21.g:787:5: 
                    {

                    					current = forceCreateModelElement(
                    						grammarAccess.getElementAccess().getElementAction_0_0(),
                    						current);
                    				

                    }

                    // InternalX21.g:793:4: ( (otherlv_1= RULE_ID ) )
                    // InternalX21.g:794:5: (otherlv_1= RULE_ID )
                    {
                    // InternalX21.g:794:5: (otherlv_1= RULE_ID )
                    // InternalX21.g:795:6: otherlv_1= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getElementRule());
                    						}
                    					
                    otherlv_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    						newLeafNode(otherlv_1, grammarAccess.getElementAccess().getNodeNodeCrossReference_0_1_0());
                    					

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalX21.g:808:3: ( () otherlv_3= '[' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_body_5_0= ruleLambda ) ) ) otherlv_6= ']' )
                    {
                    // InternalX21.g:808:3: ( () otherlv_3= '[' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_body_5_0= ruleLambda ) ) ) otherlv_6= ']' )
                    // InternalX21.g:809:4: () otherlv_3= '[' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_body_5_0= ruleLambda ) ) ) otherlv_6= ']'
                    {
                    // InternalX21.g:809:4: ()
                    // InternalX21.g:810:5: 
                    {

                    					current = forceCreateModelElement(
                    						grammarAccess.getElementAccess().getElementAction_1_0(),
                    						current);
                    				

                    }

                    otherlv_3=(Token)match(input,21,FOLLOW_13); 

                    				newLeafNode(otherlv_3, grammarAccess.getElementAccess().getLeftSquareBracketKeyword_1_1());
                    			
                    // InternalX21.g:820:4: ( ( (otherlv_4= RULE_ID ) ) | ( (lv_body_5_0= ruleLambda ) ) )
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==RULE_ID) ) {
                        alt7=1;
                    }
                    else if ( (LA7_0==15) ) {
                        alt7=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 7, 0, input);

                        throw nvae;
                    }
                    switch (alt7) {
                        case 1 :
                            // InternalX21.g:821:5: ( (otherlv_4= RULE_ID ) )
                            {
                            // InternalX21.g:821:5: ( (otherlv_4= RULE_ID ) )
                            // InternalX21.g:822:6: (otherlv_4= RULE_ID )
                            {
                            // InternalX21.g:822:6: (otherlv_4= RULE_ID )
                            // InternalX21.g:823:7: otherlv_4= RULE_ID
                            {

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getElementRule());
                            							}
                            						
                            otherlv_4=(Token)match(input,RULE_ID,FOLLOW_14); 

                            							newLeafNode(otherlv_4, grammarAccess.getElementAccess().getRefBodyFunctionCrossReference_1_2_0_0());
                            						

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalX21.g:835:5: ( (lv_body_5_0= ruleLambda ) )
                            {
                            // InternalX21.g:835:5: ( (lv_body_5_0= ruleLambda ) )
                            // InternalX21.g:836:6: (lv_body_5_0= ruleLambda )
                            {
                            // InternalX21.g:836:6: (lv_body_5_0= ruleLambda )
                            // InternalX21.g:837:7: lv_body_5_0= ruleLambda
                            {

                            							newCompositeNode(grammarAccess.getElementAccess().getBodyLambdaParserRuleCall_1_2_1_0());
                            						
                            pushFollow(FOLLOW_14);
                            lv_body_5_0=ruleLambda();

                            state._fsp--;


                            							if (current==null) {
                            								current = createModelElementForParent(grammarAccess.getElementRule());
                            							}
                            							set(
                            								current,
                            								"body",
                            								lv_body_5_0,
                            								"dk.sdu.mmmi.olnor18.x21.X21.Lambda");
                            							afterParserOrEnumRuleCall();
                            						

                            }


                            }


                            }
                            break;

                    }

                    otherlv_6=(Token)match(input,22,FOLLOW_2); 

                    				newLeafNode(otherlv_6, grammarAccess.getElementAccess().getRightSquareBracketKeyword_1_3());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalX21.g:861:3: ( () otherlv_8= 'output' ( (lv_outputName_9_0= RULE_ID ) ) )
                    {
                    // InternalX21.g:861:3: ( () otherlv_8= 'output' ( (lv_outputName_9_0= RULE_ID ) ) )
                    // InternalX21.g:862:4: () otherlv_8= 'output' ( (lv_outputName_9_0= RULE_ID ) )
                    {
                    // InternalX21.g:862:4: ()
                    // InternalX21.g:863:5: 
                    {

                    					current = forceCreateModelElement(
                    						grammarAccess.getElementAccess().getElementAction_2_0(),
                    						current);
                    				

                    }

                    otherlv_8=(Token)match(input,26,FOLLOW_3); 

                    				newLeafNode(otherlv_8, grammarAccess.getElementAccess().getOutputKeyword_2_1());
                    			
                    // InternalX21.g:873:4: ( (lv_outputName_9_0= RULE_ID ) )
                    // InternalX21.g:874:5: (lv_outputName_9_0= RULE_ID )
                    {
                    // InternalX21.g:874:5: (lv_outputName_9_0= RULE_ID )
                    // InternalX21.g:875:6: lv_outputName_9_0= RULE_ID
                    {
                    lv_outputName_9_0=(Token)match(input,RULE_ID,FOLLOW_2); 

                    						newLeafNode(lv_outputName_9_0, grammarAccess.getElementAccess().getOutputNameIDTerminalRuleCall_2_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getElementRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"outputName",
                    							lv_outputName_9_0,
                    							"org.eclipse.xtext.common.Terminals.ID");
                    					

                    }


                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElement"


    // $ANTLR start "entryRuleDataDecl"
    // InternalX21.g:896:1: entryRuleDataDecl returns [EObject current=null] : iv_ruleDataDecl= ruleDataDecl EOF ;
    public final EObject entryRuleDataDecl() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataDecl = null;


        try {
            // InternalX21.g:896:49: (iv_ruleDataDecl= ruleDataDecl EOF )
            // InternalX21.g:897:2: iv_ruleDataDecl= ruleDataDecl EOF
            {
             newCompositeNode(grammarAccess.getDataDeclRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataDecl=ruleDataDecl();

            state._fsp--;

             current =iv_ruleDataDecl; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataDecl"


    // $ANTLR start "ruleDataDecl"
    // InternalX21.g:903:1: ruleDataDecl returns [EObject current=null] : (otherlv_0= 'data' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_params_3_0= ruleInternalParameter ) ) (otherlv_4= ',' ( (lv_params_5_0= ruleInternalParameter ) ) )* otherlv_6= '}' ) ;
    public final EObject ruleDataDecl() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        EObject lv_params_3_0 = null;

        EObject lv_params_5_0 = null;



        	enterRule();

        try {
            // InternalX21.g:909:2: ( (otherlv_0= 'data' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_params_3_0= ruleInternalParameter ) ) (otherlv_4= ',' ( (lv_params_5_0= ruleInternalParameter ) ) )* otherlv_6= '}' ) )
            // InternalX21.g:910:2: (otherlv_0= 'data' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_params_3_0= ruleInternalParameter ) ) (otherlv_4= ',' ( (lv_params_5_0= ruleInternalParameter ) ) )* otherlv_6= '}' )
            {
            // InternalX21.g:910:2: (otherlv_0= 'data' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_params_3_0= ruleInternalParameter ) ) (otherlv_4= ',' ( (lv_params_5_0= ruleInternalParameter ) ) )* otherlv_6= '}' )
            // InternalX21.g:911:3: otherlv_0= 'data' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_params_3_0= ruleInternalParameter ) ) (otherlv_4= ',' ( (lv_params_5_0= ruleInternalParameter ) ) )* otherlv_6= '}'
            {
            otherlv_0=(Token)match(input,27,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getDataDeclAccess().getDataKeyword_0());
            		
            // InternalX21.g:915:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalX21.g:916:4: (lv_name_1_0= RULE_ID )
            {
            // InternalX21.g:916:4: (lv_name_1_0= RULE_ID )
            // InternalX21.g:917:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_9); 

            					newLeafNode(lv_name_1_0, grammarAccess.getDataDeclAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDataDeclRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,17,FOLLOW_3); 

            			newLeafNode(otherlv_2, grammarAccess.getDataDeclAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalX21.g:937:3: ( (lv_params_3_0= ruleInternalParameter ) )
            // InternalX21.g:938:4: (lv_params_3_0= ruleInternalParameter )
            {
            // InternalX21.g:938:4: (lv_params_3_0= ruleInternalParameter )
            // InternalX21.g:939:5: lv_params_3_0= ruleInternalParameter
            {

            					newCompositeNode(grammarAccess.getDataDeclAccess().getParamsInternalParameterParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_19);
            lv_params_3_0=ruleInternalParameter();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDataDeclRule());
            					}
            					add(
            						current,
            						"params",
            						lv_params_3_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.InternalParameter");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalX21.g:956:3: (otherlv_4= ',' ( (lv_params_5_0= ruleInternalParameter ) ) )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==24) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalX21.g:957:4: otherlv_4= ',' ( (lv_params_5_0= ruleInternalParameter ) )
            	    {
            	    otherlv_4=(Token)match(input,24,FOLLOW_3); 

            	    				newLeafNode(otherlv_4, grammarAccess.getDataDeclAccess().getCommaKeyword_4_0());
            	    			
            	    // InternalX21.g:961:4: ( (lv_params_5_0= ruleInternalParameter ) )
            	    // InternalX21.g:962:5: (lv_params_5_0= ruleInternalParameter )
            	    {
            	    // InternalX21.g:962:5: (lv_params_5_0= ruleInternalParameter )
            	    // InternalX21.g:963:6: lv_params_5_0= ruleInternalParameter
            	    {

            	    						newCompositeNode(grammarAccess.getDataDeclAccess().getParamsInternalParameterParserRuleCall_4_1_0());
            	    					
            	    pushFollow(FOLLOW_19);
            	    lv_params_5_0=ruleInternalParameter();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getDataDeclRule());
            	    						}
            	    						add(
            	    							current,
            	    							"params",
            	    							lv_params_5_0,
            	    							"dk.sdu.mmmi.olnor18.x21.X21.InternalParameter");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

            otherlv_6=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getDataDeclAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataDecl"


    // $ANTLR start "entryRuleType"
    // InternalX21.g:989:1: entryRuleType returns [EObject current=null] : iv_ruleType= ruleType EOF ;
    public final EObject entryRuleType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleType = null;


        try {
            // InternalX21.g:989:45: (iv_ruleType= ruleType EOF )
            // InternalX21.g:990:2: iv_ruleType= ruleType EOF
            {
             newCompositeNode(grammarAccess.getTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleType=ruleType();

            state._fsp--;

             current =iv_ruleType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleType"


    // $ANTLR start "ruleType"
    // InternalX21.g:996:1: ruleType returns [EObject current=null] : ( ( () ( (lv_type_1_0= 'int' ) ) ) | ( () ( (lv_type_3_0= 'string' ) ) ) | ( (otherlv_4= RULE_ID ) ) ) ;
    public final EObject ruleType() throws RecognitionException {
        EObject current = null;

        Token lv_type_1_0=null;
        Token lv_type_3_0=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalX21.g:1002:2: ( ( ( () ( (lv_type_1_0= 'int' ) ) ) | ( () ( (lv_type_3_0= 'string' ) ) ) | ( (otherlv_4= RULE_ID ) ) ) )
            // InternalX21.g:1003:2: ( ( () ( (lv_type_1_0= 'int' ) ) ) | ( () ( (lv_type_3_0= 'string' ) ) ) | ( (otherlv_4= RULE_ID ) ) )
            {
            // InternalX21.g:1003:2: ( ( () ( (lv_type_1_0= 'int' ) ) ) | ( () ( (lv_type_3_0= 'string' ) ) ) | ( (otherlv_4= RULE_ID ) ) )
            int alt10=3;
            switch ( input.LA(1) ) {
            case 28:
                {
                alt10=1;
                }
                break;
            case 29:
                {
                alt10=2;
                }
                break;
            case RULE_ID:
                {
                alt10=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }

            switch (alt10) {
                case 1 :
                    // InternalX21.g:1004:3: ( () ( (lv_type_1_0= 'int' ) ) )
                    {
                    // InternalX21.g:1004:3: ( () ( (lv_type_1_0= 'int' ) ) )
                    // InternalX21.g:1005:4: () ( (lv_type_1_0= 'int' ) )
                    {
                    // InternalX21.g:1005:4: ()
                    // InternalX21.g:1006:5: 
                    {

                    					current = forceCreateModelElement(
                    						grammarAccess.getTypeAccess().getTypeAction_0_0(),
                    						current);
                    				

                    }

                    // InternalX21.g:1012:4: ( (lv_type_1_0= 'int' ) )
                    // InternalX21.g:1013:5: (lv_type_1_0= 'int' )
                    {
                    // InternalX21.g:1013:5: (lv_type_1_0= 'int' )
                    // InternalX21.g:1014:6: lv_type_1_0= 'int'
                    {
                    lv_type_1_0=(Token)match(input,28,FOLLOW_2); 

                    						newLeafNode(lv_type_1_0, grammarAccess.getTypeAccess().getTypeIntKeyword_0_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTypeRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_1_0, "int");
                    					

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalX21.g:1028:3: ( () ( (lv_type_3_0= 'string' ) ) )
                    {
                    // InternalX21.g:1028:3: ( () ( (lv_type_3_0= 'string' ) ) )
                    // InternalX21.g:1029:4: () ( (lv_type_3_0= 'string' ) )
                    {
                    // InternalX21.g:1029:4: ()
                    // InternalX21.g:1030:5: 
                    {

                    					current = forceCreateModelElement(
                    						grammarAccess.getTypeAccess().getTypeAction_1_0(),
                    						current);
                    				

                    }

                    // InternalX21.g:1036:4: ( (lv_type_3_0= 'string' ) )
                    // InternalX21.g:1037:5: (lv_type_3_0= 'string' )
                    {
                    // InternalX21.g:1037:5: (lv_type_3_0= 'string' )
                    // InternalX21.g:1038:6: lv_type_3_0= 'string'
                    {
                    lv_type_3_0=(Token)match(input,29,FOLLOW_2); 

                    						newLeafNode(lv_type_3_0, grammarAccess.getTypeAccess().getTypeStringKeyword_1_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTypeRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_3_0, "string");
                    					

                    }


                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalX21.g:1052:3: ( (otherlv_4= RULE_ID ) )
                    {
                    // InternalX21.g:1052:3: ( (otherlv_4= RULE_ID ) )
                    // InternalX21.g:1053:4: (otherlv_4= RULE_ID )
                    {
                    // InternalX21.g:1053:4: (otherlv_4= RULE_ID )
                    // InternalX21.g:1054:5: otherlv_4= RULE_ID
                    {

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getTypeRule());
                    					}
                    				
                    otherlv_4=(Token)match(input,RULE_ID,FOLLOW_2); 

                    					newLeafNode(otherlv_4, grammarAccess.getTypeAccess().getRefDataDeclCrossReference_2_0());
                    				

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleType"


    // $ANTLR start "entryRuleExp"
    // InternalX21.g:1069:1: entryRuleExp returns [EObject current=null] : iv_ruleExp= ruleExp EOF ;
    public final EObject entryRuleExp() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExp = null;


        try {
            // InternalX21.g:1069:44: (iv_ruleExp= ruleExp EOF )
            // InternalX21.g:1070:2: iv_ruleExp= ruleExp EOF
            {
             newCompositeNode(grammarAccess.getExpRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExp=ruleExp();

            state._fsp--;

             current =iv_ruleExp; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExp"


    // $ANTLR start "ruleExp"
    // InternalX21.g:1076:1: ruleExp returns [EObject current=null] : this_SubAddExp_0= ruleSubAddExp ;
    public final EObject ruleExp() throws RecognitionException {
        EObject current = null;

        EObject this_SubAddExp_0 = null;



        	enterRule();

        try {
            // InternalX21.g:1082:2: (this_SubAddExp_0= ruleSubAddExp )
            // InternalX21.g:1083:2: this_SubAddExp_0= ruleSubAddExp
            {

            		newCompositeNode(grammarAccess.getExpAccess().getSubAddExpParserRuleCall());
            	
            pushFollow(FOLLOW_2);
            this_SubAddExp_0=ruleSubAddExp();

            state._fsp--;


            		current = this_SubAddExp_0;
            		afterParserOrEnumRuleCall();
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExp"


    // $ANTLR start "entryRuleSubAddExp"
    // InternalX21.g:1094:1: entryRuleSubAddExp returns [EObject current=null] : iv_ruleSubAddExp= ruleSubAddExp EOF ;
    public final EObject entryRuleSubAddExp() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSubAddExp = null;


        try {
            // InternalX21.g:1094:50: (iv_ruleSubAddExp= ruleSubAddExp EOF )
            // InternalX21.g:1095:2: iv_ruleSubAddExp= ruleSubAddExp EOF
            {
             newCompositeNode(grammarAccess.getSubAddExpRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSubAddExp=ruleSubAddExp();

            state._fsp--;

             current =iv_ruleSubAddExp; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSubAddExp"


    // $ANTLR start "ruleSubAddExp"
    // InternalX21.g:1101:1: ruleSubAddExp returns [EObject current=null] : (this_DivMultExp_0= ruleDivMultExp ( ( (otherlv_1= '-' () ) | (otherlv_3= '+' () ) ) ( (lv_right_5_0= ruleDivMultExp ) ) )* ) ;
    public final EObject ruleSubAddExp() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject this_DivMultExp_0 = null;

        EObject lv_right_5_0 = null;



        	enterRule();

        try {
            // InternalX21.g:1107:2: ( (this_DivMultExp_0= ruleDivMultExp ( ( (otherlv_1= '-' () ) | (otherlv_3= '+' () ) ) ( (lv_right_5_0= ruleDivMultExp ) ) )* ) )
            // InternalX21.g:1108:2: (this_DivMultExp_0= ruleDivMultExp ( ( (otherlv_1= '-' () ) | (otherlv_3= '+' () ) ) ( (lv_right_5_0= ruleDivMultExp ) ) )* )
            {
            // InternalX21.g:1108:2: (this_DivMultExp_0= ruleDivMultExp ( ( (otherlv_1= '-' () ) | (otherlv_3= '+' () ) ) ( (lv_right_5_0= ruleDivMultExp ) ) )* )
            // InternalX21.g:1109:3: this_DivMultExp_0= ruleDivMultExp ( ( (otherlv_1= '-' () ) | (otherlv_3= '+' () ) ) ( (lv_right_5_0= ruleDivMultExp ) ) )*
            {

            			newCompositeNode(grammarAccess.getSubAddExpAccess().getDivMultExpParserRuleCall_0());
            		
            pushFollow(FOLLOW_20);
            this_DivMultExp_0=ruleDivMultExp();

            state._fsp--;


            			current = this_DivMultExp_0;
            			afterParserOrEnumRuleCall();
            		
            // InternalX21.g:1117:3: ( ( (otherlv_1= '-' () ) | (otherlv_3= '+' () ) ) ( (lv_right_5_0= ruleDivMultExp ) ) )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( ((LA12_0>=30 && LA12_0<=31)) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalX21.g:1118:4: ( (otherlv_1= '-' () ) | (otherlv_3= '+' () ) ) ( (lv_right_5_0= ruleDivMultExp ) )
            	    {
            	    // InternalX21.g:1118:4: ( (otherlv_1= '-' () ) | (otherlv_3= '+' () ) )
            	    int alt11=2;
            	    int LA11_0 = input.LA(1);

            	    if ( (LA11_0==30) ) {
            	        alt11=1;
            	    }
            	    else if ( (LA11_0==31) ) {
            	        alt11=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 11, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt11) {
            	        case 1 :
            	            // InternalX21.g:1119:5: (otherlv_1= '-' () )
            	            {
            	            // InternalX21.g:1119:5: (otherlv_1= '-' () )
            	            // InternalX21.g:1120:6: otherlv_1= '-' ()
            	            {
            	            otherlv_1=(Token)match(input,30,FOLLOW_10); 

            	            						newLeafNode(otherlv_1, grammarAccess.getSubAddExpAccess().getHyphenMinusKeyword_1_0_0_0());
            	            					
            	            // InternalX21.g:1124:6: ()
            	            // InternalX21.g:1125:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getSubAddExpAccess().getSubtractionLeftAction_1_0_0_1(),
            	            								current);
            	            						

            	            }


            	            }


            	            }
            	            break;
            	        case 2 :
            	            // InternalX21.g:1133:5: (otherlv_3= '+' () )
            	            {
            	            // InternalX21.g:1133:5: (otherlv_3= '+' () )
            	            // InternalX21.g:1134:6: otherlv_3= '+' ()
            	            {
            	            otherlv_3=(Token)match(input,31,FOLLOW_10); 

            	            						newLeafNode(otherlv_3, grammarAccess.getSubAddExpAccess().getPlusSignKeyword_1_0_1_0());
            	            					
            	            // InternalX21.g:1138:6: ()
            	            // InternalX21.g:1139:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getSubAddExpAccess().getAdditionLeftAction_1_0_1_1(),
            	            								current);
            	            						

            	            }


            	            }


            	            }
            	            break;

            	    }

            	    // InternalX21.g:1147:4: ( (lv_right_5_0= ruleDivMultExp ) )
            	    // InternalX21.g:1148:5: (lv_right_5_0= ruleDivMultExp )
            	    {
            	    // InternalX21.g:1148:5: (lv_right_5_0= ruleDivMultExp )
            	    // InternalX21.g:1149:6: lv_right_5_0= ruleDivMultExp
            	    {

            	    						newCompositeNode(grammarAccess.getSubAddExpAccess().getRightDivMultExpParserRuleCall_1_1_0());
            	    					
            	    pushFollow(FOLLOW_20);
            	    lv_right_5_0=ruleDivMultExp();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getSubAddExpRule());
            	    						}
            	    						set(
            	    							current,
            	    							"right",
            	    							lv_right_5_0,
            	    							"dk.sdu.mmmi.olnor18.x21.X21.DivMultExp");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSubAddExp"


    // $ANTLR start "entryRuleDivMultExp"
    // InternalX21.g:1171:1: entryRuleDivMultExp returns [EObject current=null] : iv_ruleDivMultExp= ruleDivMultExp EOF ;
    public final EObject entryRuleDivMultExp() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDivMultExp = null;


        try {
            // InternalX21.g:1171:51: (iv_ruleDivMultExp= ruleDivMultExp EOF )
            // InternalX21.g:1172:2: iv_ruleDivMultExp= ruleDivMultExp EOF
            {
             newCompositeNode(grammarAccess.getDivMultExpRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDivMultExp=ruleDivMultExp();

            state._fsp--;

             current =iv_ruleDivMultExp; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDivMultExp"


    // $ANTLR start "ruleDivMultExp"
    // InternalX21.g:1178:1: ruleDivMultExp returns [EObject current=null] : (this_Primary_0= rulePrimary ( ( (otherlv_1= '/' () ) | (otherlv_3= '*' () ) ) ( (lv_right_5_0= rulePrimary ) ) )* ) ;
    public final EObject ruleDivMultExp() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject this_Primary_0 = null;

        EObject lv_right_5_0 = null;



        	enterRule();

        try {
            // InternalX21.g:1184:2: ( (this_Primary_0= rulePrimary ( ( (otherlv_1= '/' () ) | (otherlv_3= '*' () ) ) ( (lv_right_5_0= rulePrimary ) ) )* ) )
            // InternalX21.g:1185:2: (this_Primary_0= rulePrimary ( ( (otherlv_1= '/' () ) | (otherlv_3= '*' () ) ) ( (lv_right_5_0= rulePrimary ) ) )* )
            {
            // InternalX21.g:1185:2: (this_Primary_0= rulePrimary ( ( (otherlv_1= '/' () ) | (otherlv_3= '*' () ) ) ( (lv_right_5_0= rulePrimary ) ) )* )
            // InternalX21.g:1186:3: this_Primary_0= rulePrimary ( ( (otherlv_1= '/' () ) | (otherlv_3= '*' () ) ) ( (lv_right_5_0= rulePrimary ) ) )*
            {

            			newCompositeNode(grammarAccess.getDivMultExpAccess().getPrimaryParserRuleCall_0());
            		
            pushFollow(FOLLOW_21);
            this_Primary_0=rulePrimary();

            state._fsp--;


            			current = this_Primary_0;
            			afterParserOrEnumRuleCall();
            		
            // InternalX21.g:1194:3: ( ( (otherlv_1= '/' () ) | (otherlv_3= '*' () ) ) ( (lv_right_5_0= rulePrimary ) ) )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( ((LA14_0>=32 && LA14_0<=33)) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // InternalX21.g:1195:4: ( (otherlv_1= '/' () ) | (otherlv_3= '*' () ) ) ( (lv_right_5_0= rulePrimary ) )
            	    {
            	    // InternalX21.g:1195:4: ( (otherlv_1= '/' () ) | (otherlv_3= '*' () ) )
            	    int alt13=2;
            	    int LA13_0 = input.LA(1);

            	    if ( (LA13_0==32) ) {
            	        alt13=1;
            	    }
            	    else if ( (LA13_0==33) ) {
            	        alt13=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 13, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt13) {
            	        case 1 :
            	            // InternalX21.g:1196:5: (otherlv_1= '/' () )
            	            {
            	            // InternalX21.g:1196:5: (otherlv_1= '/' () )
            	            // InternalX21.g:1197:6: otherlv_1= '/' ()
            	            {
            	            otherlv_1=(Token)match(input,32,FOLLOW_10); 

            	            						newLeafNode(otherlv_1, grammarAccess.getDivMultExpAccess().getSolidusKeyword_1_0_0_0());
            	            					
            	            // InternalX21.g:1201:6: ()
            	            // InternalX21.g:1202:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getDivMultExpAccess().getDivisionLeftAction_1_0_0_1(),
            	            								current);
            	            						

            	            }


            	            }


            	            }
            	            break;
            	        case 2 :
            	            // InternalX21.g:1210:5: (otherlv_3= '*' () )
            	            {
            	            // InternalX21.g:1210:5: (otherlv_3= '*' () )
            	            // InternalX21.g:1211:6: otherlv_3= '*' ()
            	            {
            	            otherlv_3=(Token)match(input,33,FOLLOW_10); 

            	            						newLeafNode(otherlv_3, grammarAccess.getDivMultExpAccess().getAsteriskKeyword_1_0_1_0());
            	            					
            	            // InternalX21.g:1215:6: ()
            	            // InternalX21.g:1216:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getDivMultExpAccess().getMultiplicationLeftAction_1_0_1_1(),
            	            								current);
            	            						

            	            }


            	            }


            	            }
            	            break;

            	    }

            	    // InternalX21.g:1224:4: ( (lv_right_5_0= rulePrimary ) )
            	    // InternalX21.g:1225:5: (lv_right_5_0= rulePrimary )
            	    {
            	    // InternalX21.g:1225:5: (lv_right_5_0= rulePrimary )
            	    // InternalX21.g:1226:6: lv_right_5_0= rulePrimary
            	    {

            	    						newCompositeNode(grammarAccess.getDivMultExpAccess().getRightPrimaryParserRuleCall_1_1_0());
            	    					
            	    pushFollow(FOLLOW_21);
            	    lv_right_5_0=rulePrimary();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getDivMultExpRule());
            	    						}
            	    						set(
            	    							current,
            	    							"right",
            	    							lv_right_5_0,
            	    							"dk.sdu.mmmi.olnor18.x21.X21.Primary");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDivMultExp"


    // $ANTLR start "entryRulePrimary"
    // InternalX21.g:1248:1: entryRulePrimary returns [EObject current=null] : iv_rulePrimary= rulePrimary EOF ;
    public final EObject entryRulePrimary() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePrimary = null;


        try {
            // InternalX21.g:1248:48: (iv_rulePrimary= rulePrimary EOF )
            // InternalX21.g:1249:2: iv_rulePrimary= rulePrimary EOF
            {
             newCompositeNode(grammarAccess.getPrimaryRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePrimary=rulePrimary();

            state._fsp--;

             current =iv_rulePrimary; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrimary"


    // $ANTLR start "rulePrimary"
    // InternalX21.g:1255:1: rulePrimary returns [EObject current=null] : (this_Number_0= ruleNumber | this_Parenthesis_1= ruleParenthesis | this_VariableUse_2= ruleVariableUse | this_Let_3= ruleLet | this_VariableAssignment_4= ruleVariableAssignment | this_Ifstatement_5= ruleIfstatement | this_None_6= ruleNone | this_DataTypeAttribute_7= ruleDataTypeAttribute ) ;
    public final EObject rulePrimary() throws RecognitionException {
        EObject current = null;

        EObject this_Number_0 = null;

        EObject this_Parenthesis_1 = null;

        EObject this_VariableUse_2 = null;

        EObject this_Let_3 = null;

        EObject this_VariableAssignment_4 = null;

        EObject this_Ifstatement_5 = null;

        EObject this_None_6 = null;

        EObject this_DataTypeAttribute_7 = null;



        	enterRule();

        try {
            // InternalX21.g:1261:2: ( (this_Number_0= ruleNumber | this_Parenthesis_1= ruleParenthesis | this_VariableUse_2= ruleVariableUse | this_Let_3= ruleLet | this_VariableAssignment_4= ruleVariableAssignment | this_Ifstatement_5= ruleIfstatement | this_None_6= ruleNone | this_DataTypeAttribute_7= ruleDataTypeAttribute ) )
            // InternalX21.g:1262:2: (this_Number_0= ruleNumber | this_Parenthesis_1= ruleParenthesis | this_VariableUse_2= ruleVariableUse | this_Let_3= ruleLet | this_VariableAssignment_4= ruleVariableAssignment | this_Ifstatement_5= ruleIfstatement | this_None_6= ruleNone | this_DataTypeAttribute_7= ruleDataTypeAttribute )
            {
            // InternalX21.g:1262:2: (this_Number_0= ruleNumber | this_Parenthesis_1= ruleParenthesis | this_VariableUse_2= ruleVariableUse | this_Let_3= ruleLet | this_VariableAssignment_4= ruleVariableAssignment | this_Ifstatement_5= ruleIfstatement | this_None_6= ruleNone | this_DataTypeAttribute_7= ruleDataTypeAttribute )
            int alt15=8;
            alt15 = dfa15.predict(input);
            switch (alt15) {
                case 1 :
                    // InternalX21.g:1263:3: this_Number_0= ruleNumber
                    {

                    			newCompositeNode(grammarAccess.getPrimaryAccess().getNumberParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Number_0=ruleNumber();

                    state._fsp--;


                    			current = this_Number_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalX21.g:1272:3: this_Parenthesis_1= ruleParenthesis
                    {

                    			newCompositeNode(grammarAccess.getPrimaryAccess().getParenthesisParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Parenthesis_1=ruleParenthesis();

                    state._fsp--;


                    			current = this_Parenthesis_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalX21.g:1281:3: this_VariableUse_2= ruleVariableUse
                    {

                    			newCompositeNode(grammarAccess.getPrimaryAccess().getVariableUseParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_VariableUse_2=ruleVariableUse();

                    state._fsp--;


                    			current = this_VariableUse_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalX21.g:1290:3: this_Let_3= ruleLet
                    {

                    			newCompositeNode(grammarAccess.getPrimaryAccess().getLetParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_Let_3=ruleLet();

                    state._fsp--;


                    			current = this_Let_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalX21.g:1299:3: this_VariableAssignment_4= ruleVariableAssignment
                    {

                    			newCompositeNode(grammarAccess.getPrimaryAccess().getVariableAssignmentParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_VariableAssignment_4=ruleVariableAssignment();

                    state._fsp--;


                    			current = this_VariableAssignment_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalX21.g:1308:3: this_Ifstatement_5= ruleIfstatement
                    {

                    			newCompositeNode(grammarAccess.getPrimaryAccess().getIfstatementParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_Ifstatement_5=ruleIfstatement();

                    state._fsp--;


                    			current = this_Ifstatement_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 7 :
                    // InternalX21.g:1317:3: this_None_6= ruleNone
                    {

                    			newCompositeNode(grammarAccess.getPrimaryAccess().getNoneParserRuleCall_6());
                    		
                    pushFollow(FOLLOW_2);
                    this_None_6=ruleNone();

                    state._fsp--;


                    			current = this_None_6;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 8 :
                    // InternalX21.g:1326:3: this_DataTypeAttribute_7= ruleDataTypeAttribute
                    {

                    			newCompositeNode(grammarAccess.getPrimaryAccess().getDataTypeAttributeParserRuleCall_7());
                    		
                    pushFollow(FOLLOW_2);
                    this_DataTypeAttribute_7=ruleDataTypeAttribute();

                    state._fsp--;


                    			current = this_DataTypeAttribute_7;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrimary"


    // $ANTLR start "entryRuleNone"
    // InternalX21.g:1338:1: entryRuleNone returns [EObject current=null] : iv_ruleNone= ruleNone EOF ;
    public final EObject entryRuleNone() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNone = null;


        try {
            // InternalX21.g:1338:45: (iv_ruleNone= ruleNone EOF )
            // InternalX21.g:1339:2: iv_ruleNone= ruleNone EOF
            {
             newCompositeNode(grammarAccess.getNoneRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNone=ruleNone();

            state._fsp--;

             current =iv_ruleNone; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNone"


    // $ANTLR start "ruleNone"
    // InternalX21.g:1345:1: ruleNone returns [EObject current=null] : ( () otherlv_1= 'none' ) ;
    public final EObject ruleNone() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;


        	enterRule();

        try {
            // InternalX21.g:1351:2: ( ( () otherlv_1= 'none' ) )
            // InternalX21.g:1352:2: ( () otherlv_1= 'none' )
            {
            // InternalX21.g:1352:2: ( () otherlv_1= 'none' )
            // InternalX21.g:1353:3: () otherlv_1= 'none'
            {
            // InternalX21.g:1353:3: ()
            // InternalX21.g:1354:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getNoneAccess().getNoneAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,34,FOLLOW_2); 

            			newLeafNode(otherlv_1, grammarAccess.getNoneAccess().getNoneKeyword_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNone"


    // $ANTLR start "entryRuleIfstatement"
    // InternalX21.g:1368:1: entryRuleIfstatement returns [EObject current=null] : iv_ruleIfstatement= ruleIfstatement EOF ;
    public final EObject entryRuleIfstatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIfstatement = null;


        try {
            // InternalX21.g:1368:52: (iv_ruleIfstatement= ruleIfstatement EOF )
            // InternalX21.g:1369:2: iv_ruleIfstatement= ruleIfstatement EOF
            {
             newCompositeNode(grammarAccess.getIfstatementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIfstatement=ruleIfstatement();

            state._fsp--;

             current =iv_ruleIfstatement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIfstatement"


    // $ANTLR start "ruleIfstatement"
    // InternalX21.g:1375:1: ruleIfstatement returns [EObject current=null] : ( () otherlv_1= 'if' ( (lv_logicExp_2_0= ruleLogicExp ) ) otherlv_3= 'then' ( (lv_exp_4_0= ruleExp ) ) otherlv_5= 'else' ( (lv_elseExp_6_0= ruleExp ) ) otherlv_7= 'end' ) ;
    public final EObject ruleIfstatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        EObject lv_logicExp_2_0 = null;

        EObject lv_exp_4_0 = null;

        EObject lv_elseExp_6_0 = null;



        	enterRule();

        try {
            // InternalX21.g:1381:2: ( ( () otherlv_1= 'if' ( (lv_logicExp_2_0= ruleLogicExp ) ) otherlv_3= 'then' ( (lv_exp_4_0= ruleExp ) ) otherlv_5= 'else' ( (lv_elseExp_6_0= ruleExp ) ) otherlv_7= 'end' ) )
            // InternalX21.g:1382:2: ( () otherlv_1= 'if' ( (lv_logicExp_2_0= ruleLogicExp ) ) otherlv_3= 'then' ( (lv_exp_4_0= ruleExp ) ) otherlv_5= 'else' ( (lv_elseExp_6_0= ruleExp ) ) otherlv_7= 'end' )
            {
            // InternalX21.g:1382:2: ( () otherlv_1= 'if' ( (lv_logicExp_2_0= ruleLogicExp ) ) otherlv_3= 'then' ( (lv_exp_4_0= ruleExp ) ) otherlv_5= 'else' ( (lv_elseExp_6_0= ruleExp ) ) otherlv_7= 'end' )
            // InternalX21.g:1383:3: () otherlv_1= 'if' ( (lv_logicExp_2_0= ruleLogicExp ) ) otherlv_3= 'then' ( (lv_exp_4_0= ruleExp ) ) otherlv_5= 'else' ( (lv_elseExp_6_0= ruleExp ) ) otherlv_7= 'end'
            {
            // InternalX21.g:1383:3: ()
            // InternalX21.g:1384:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getIfstatementAccess().getIfstatementAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,35,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getIfstatementAccess().getIfKeyword_1());
            		
            // InternalX21.g:1394:3: ( (lv_logicExp_2_0= ruleLogicExp ) )
            // InternalX21.g:1395:4: (lv_logicExp_2_0= ruleLogicExp )
            {
            // InternalX21.g:1395:4: (lv_logicExp_2_0= ruleLogicExp )
            // InternalX21.g:1396:5: lv_logicExp_2_0= ruleLogicExp
            {

            					newCompositeNode(grammarAccess.getIfstatementAccess().getLogicExpLogicExpParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_22);
            lv_logicExp_2_0=ruleLogicExp();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIfstatementRule());
            					}
            					set(
            						current,
            						"logicExp",
            						lv_logicExp_2_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.LogicExp");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,36,FOLLOW_10); 

            			newLeafNode(otherlv_3, grammarAccess.getIfstatementAccess().getThenKeyword_3());
            		
            // InternalX21.g:1417:3: ( (lv_exp_4_0= ruleExp ) )
            // InternalX21.g:1418:4: (lv_exp_4_0= ruleExp )
            {
            // InternalX21.g:1418:4: (lv_exp_4_0= ruleExp )
            // InternalX21.g:1419:5: lv_exp_4_0= ruleExp
            {

            					newCompositeNode(grammarAccess.getIfstatementAccess().getExpExpParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_23);
            lv_exp_4_0=ruleExp();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIfstatementRule());
            					}
            					set(
            						current,
            						"exp",
            						lv_exp_4_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Exp");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,37,FOLLOW_10); 

            			newLeafNode(otherlv_5, grammarAccess.getIfstatementAccess().getElseKeyword_5());
            		
            // InternalX21.g:1440:3: ( (lv_elseExp_6_0= ruleExp ) )
            // InternalX21.g:1441:4: (lv_elseExp_6_0= ruleExp )
            {
            // InternalX21.g:1441:4: (lv_elseExp_6_0= ruleExp )
            // InternalX21.g:1442:5: lv_elseExp_6_0= ruleExp
            {

            					newCompositeNode(grammarAccess.getIfstatementAccess().getElseExpExpParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_24);
            lv_elseExp_6_0=ruleExp();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIfstatementRule());
            					}
            					set(
            						current,
            						"elseExp",
            						lv_elseExp_6_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Exp");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_7=(Token)match(input,38,FOLLOW_2); 

            			newLeafNode(otherlv_7, grammarAccess.getIfstatementAccess().getEndKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIfstatement"


    // $ANTLR start "entryRuleParenthesis"
    // InternalX21.g:1467:1: entryRuleParenthesis returns [EObject current=null] : iv_ruleParenthesis= ruleParenthesis EOF ;
    public final EObject entryRuleParenthesis() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleParenthesis = null;


        try {
            // InternalX21.g:1467:52: (iv_ruleParenthesis= ruleParenthesis EOF )
            // InternalX21.g:1468:2: iv_ruleParenthesis= ruleParenthesis EOF
            {
             newCompositeNode(grammarAccess.getParenthesisRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleParenthesis=ruleParenthesis();

            state._fsp--;

             current =iv_ruleParenthesis; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleParenthesis"


    // $ANTLR start "ruleParenthesis"
    // InternalX21.g:1474:1: ruleParenthesis returns [EObject current=null] : ( () otherlv_1= '(' ( (lv_inner_2_0= ruleExp ) ) otherlv_3= ')' ) ;
    public final EObject ruleParenthesis() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_inner_2_0 = null;



        	enterRule();

        try {
            // InternalX21.g:1480:2: ( ( () otherlv_1= '(' ( (lv_inner_2_0= ruleExp ) ) otherlv_3= ')' ) )
            // InternalX21.g:1481:2: ( () otherlv_1= '(' ( (lv_inner_2_0= ruleExp ) ) otherlv_3= ')' )
            {
            // InternalX21.g:1481:2: ( () otherlv_1= '(' ( (lv_inner_2_0= ruleExp ) ) otherlv_3= ')' )
            // InternalX21.g:1482:3: () otherlv_1= '(' ( (lv_inner_2_0= ruleExp ) ) otherlv_3= ')'
            {
            // InternalX21.g:1482:3: ()
            // InternalX21.g:1483:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getParenthesisAccess().getParenthesisAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,15,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getParenthesisAccess().getLeftParenthesisKeyword_1());
            		
            // InternalX21.g:1493:3: ( (lv_inner_2_0= ruleExp ) )
            // InternalX21.g:1494:4: (lv_inner_2_0= ruleExp )
            {
            // InternalX21.g:1494:4: (lv_inner_2_0= ruleExp )
            // InternalX21.g:1495:5: lv_inner_2_0= ruleExp
            {

            					newCompositeNode(grammarAccess.getParenthesisAccess().getInnerExpParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_8);
            lv_inner_2_0=ruleExp();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getParenthesisRule());
            					}
            					set(
            						current,
            						"inner",
            						lv_inner_2_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Exp");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getParenthesisAccess().getRightParenthesisKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleParenthesis"


    // $ANTLR start "entryRuleNumber"
    // InternalX21.g:1520:1: entryRuleNumber returns [EObject current=null] : iv_ruleNumber= ruleNumber EOF ;
    public final EObject entryRuleNumber() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNumber = null;


        try {
            // InternalX21.g:1520:47: (iv_ruleNumber= ruleNumber EOF )
            // InternalX21.g:1521:2: iv_ruleNumber= ruleNumber EOF
            {
             newCompositeNode(grammarAccess.getNumberRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNumber=ruleNumber();

            state._fsp--;

             current =iv_ruleNumber; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNumber"


    // $ANTLR start "ruleNumber"
    // InternalX21.g:1527:1: ruleNumber returns [EObject current=null] : ( () ( (lv_value_1_0= RULE_INT ) ) ) ;
    public final EObject ruleNumber() throws RecognitionException {
        EObject current = null;

        Token lv_value_1_0=null;


        	enterRule();

        try {
            // InternalX21.g:1533:2: ( ( () ( (lv_value_1_0= RULE_INT ) ) ) )
            // InternalX21.g:1534:2: ( () ( (lv_value_1_0= RULE_INT ) ) )
            {
            // InternalX21.g:1534:2: ( () ( (lv_value_1_0= RULE_INT ) ) )
            // InternalX21.g:1535:3: () ( (lv_value_1_0= RULE_INT ) )
            {
            // InternalX21.g:1535:3: ()
            // InternalX21.g:1536:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getNumberAccess().getNumberAction_0(),
            					current);
            			

            }

            // InternalX21.g:1542:3: ( (lv_value_1_0= RULE_INT ) )
            // InternalX21.g:1543:4: (lv_value_1_0= RULE_INT )
            {
            // InternalX21.g:1543:4: (lv_value_1_0= RULE_INT )
            // InternalX21.g:1544:5: lv_value_1_0= RULE_INT
            {
            lv_value_1_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            					newLeafNode(lv_value_1_0, grammarAccess.getNumberAccess().getValueINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getNumberRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNumber"


    // $ANTLR start "entryRuleLet"
    // InternalX21.g:1564:1: entryRuleLet returns [EObject current=null] : iv_ruleLet= ruleLet EOF ;
    public final EObject entryRuleLet() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLet = null;


        try {
            // InternalX21.g:1564:44: (iv_ruleLet= ruleLet EOF )
            // InternalX21.g:1565:2: iv_ruleLet= ruleLet EOF
            {
             newCompositeNode(grammarAccess.getLetRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLet=ruleLet();

            state._fsp--;

             current =iv_ruleLet; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLet"


    // $ANTLR start "ruleLet"
    // InternalX21.g:1571:1: ruleLet returns [EObject current=null] : ( () otherlv_1= 'let' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' ( (lv_def_4_0= ruleExp ) ) otherlv_5= 'in' ( (lv_body_6_0= ruleExp ) ) otherlv_7= 'end' ) ;
    public final EObject ruleLet() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        EObject lv_def_4_0 = null;

        EObject lv_body_6_0 = null;



        	enterRule();

        try {
            // InternalX21.g:1577:2: ( ( () otherlv_1= 'let' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' ( (lv_def_4_0= ruleExp ) ) otherlv_5= 'in' ( (lv_body_6_0= ruleExp ) ) otherlv_7= 'end' ) )
            // InternalX21.g:1578:2: ( () otherlv_1= 'let' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' ( (lv_def_4_0= ruleExp ) ) otherlv_5= 'in' ( (lv_body_6_0= ruleExp ) ) otherlv_7= 'end' )
            {
            // InternalX21.g:1578:2: ( () otherlv_1= 'let' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' ( (lv_def_4_0= ruleExp ) ) otherlv_5= 'in' ( (lv_body_6_0= ruleExp ) ) otherlv_7= 'end' )
            // InternalX21.g:1579:3: () otherlv_1= 'let' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' ( (lv_def_4_0= ruleExp ) ) otherlv_5= 'in' ( (lv_body_6_0= ruleExp ) ) otherlv_7= 'end'
            {
            // InternalX21.g:1579:3: ()
            // InternalX21.g:1580:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getLetAccess().getLetAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,39,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getLetAccess().getLetKeyword_1());
            		
            // InternalX21.g:1590:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalX21.g:1591:4: (lv_name_2_0= RULE_ID )
            {
            // InternalX21.g:1591:4: (lv_name_2_0= RULE_ID )
            // InternalX21.g:1592:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_25); 

            					newLeafNode(lv_name_2_0, grammarAccess.getLetAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getLetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_3=(Token)match(input,40,FOLLOW_10); 

            			newLeafNode(otherlv_3, grammarAccess.getLetAccess().getEqualsSignKeyword_3());
            		
            // InternalX21.g:1612:3: ( (lv_def_4_0= ruleExp ) )
            // InternalX21.g:1613:4: (lv_def_4_0= ruleExp )
            {
            // InternalX21.g:1613:4: (lv_def_4_0= ruleExp )
            // InternalX21.g:1614:5: lv_def_4_0= ruleExp
            {

            					newCompositeNode(grammarAccess.getLetAccess().getDefExpParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_26);
            lv_def_4_0=ruleExp();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getLetRule());
            					}
            					set(
            						current,
            						"def",
            						lv_def_4_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Exp");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,41,FOLLOW_10); 

            			newLeafNode(otherlv_5, grammarAccess.getLetAccess().getInKeyword_5());
            		
            // InternalX21.g:1635:3: ( (lv_body_6_0= ruleExp ) )
            // InternalX21.g:1636:4: (lv_body_6_0= ruleExp )
            {
            // InternalX21.g:1636:4: (lv_body_6_0= ruleExp )
            // InternalX21.g:1637:5: lv_body_6_0= ruleExp
            {

            					newCompositeNode(grammarAccess.getLetAccess().getBodyExpParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_24);
            lv_body_6_0=ruleExp();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getLetRule());
            					}
            					set(
            						current,
            						"body",
            						lv_body_6_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Exp");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_7=(Token)match(input,38,FOLLOW_2); 

            			newLeafNode(otherlv_7, grammarAccess.getLetAccess().getEndKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLet"


    // $ANTLR start "entryRuleVariableAssignment"
    // InternalX21.g:1662:1: entryRuleVariableAssignment returns [EObject current=null] : iv_ruleVariableAssignment= ruleVariableAssignment EOF ;
    public final EObject entryRuleVariableAssignment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariableAssignment = null;


        try {
            // InternalX21.g:1662:59: (iv_ruleVariableAssignment= ruleVariableAssignment EOF )
            // InternalX21.g:1663:2: iv_ruleVariableAssignment= ruleVariableAssignment EOF
            {
             newCompositeNode(grammarAccess.getVariableAssignmentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariableAssignment=ruleVariableAssignment();

            state._fsp--;

             current =iv_ruleVariableAssignment; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariableAssignment"


    // $ANTLR start "ruleVariableAssignment"
    // InternalX21.g:1669:1: ruleVariableAssignment returns [EObject current=null] : ( () otherlv_1= 'new' ( (otherlv_2= RULE_ID ) ) otherlv_3= '[' ( (otherlv_4= RULE_ID ) ) otherlv_5= '=' ( (lv_value_6_0= ruleExp ) ) (otherlv_7= ',' ( (otherlv_8= RULE_ID ) ) otherlv_9= '=' ( (lv_value_10_0= ruleExp ) ) )* otherlv_11= ']' ) ;
    public final EObject ruleVariableAssignment() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        EObject lv_value_6_0 = null;

        EObject lv_value_10_0 = null;



        	enterRule();

        try {
            // InternalX21.g:1675:2: ( ( () otherlv_1= 'new' ( (otherlv_2= RULE_ID ) ) otherlv_3= '[' ( (otherlv_4= RULE_ID ) ) otherlv_5= '=' ( (lv_value_6_0= ruleExp ) ) (otherlv_7= ',' ( (otherlv_8= RULE_ID ) ) otherlv_9= '=' ( (lv_value_10_0= ruleExp ) ) )* otherlv_11= ']' ) )
            // InternalX21.g:1676:2: ( () otherlv_1= 'new' ( (otherlv_2= RULE_ID ) ) otherlv_3= '[' ( (otherlv_4= RULE_ID ) ) otherlv_5= '=' ( (lv_value_6_0= ruleExp ) ) (otherlv_7= ',' ( (otherlv_8= RULE_ID ) ) otherlv_9= '=' ( (lv_value_10_0= ruleExp ) ) )* otherlv_11= ']' )
            {
            // InternalX21.g:1676:2: ( () otherlv_1= 'new' ( (otherlv_2= RULE_ID ) ) otherlv_3= '[' ( (otherlv_4= RULE_ID ) ) otherlv_5= '=' ( (lv_value_6_0= ruleExp ) ) (otherlv_7= ',' ( (otherlv_8= RULE_ID ) ) otherlv_9= '=' ( (lv_value_10_0= ruleExp ) ) )* otherlv_11= ']' )
            // InternalX21.g:1677:3: () otherlv_1= 'new' ( (otherlv_2= RULE_ID ) ) otherlv_3= '[' ( (otherlv_4= RULE_ID ) ) otherlv_5= '=' ( (lv_value_6_0= ruleExp ) ) (otherlv_7= ',' ( (otherlv_8= RULE_ID ) ) otherlv_9= '=' ( (lv_value_10_0= ruleExp ) ) )* otherlv_11= ']'
            {
            // InternalX21.g:1677:3: ()
            // InternalX21.g:1678:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getVariableAssignmentAccess().getVariableAssignmentAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,42,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getVariableAssignmentAccess().getNewKeyword_1());
            		
            // InternalX21.g:1688:3: ( (otherlv_2= RULE_ID ) )
            // InternalX21.g:1689:4: (otherlv_2= RULE_ID )
            {
            // InternalX21.g:1689:4: (otherlv_2= RULE_ID )
            // InternalX21.g:1690:5: otherlv_2= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariableAssignmentRule());
            					}
            				
            otherlv_2=(Token)match(input,RULE_ID,FOLLOW_12); 

            					newLeafNode(otherlv_2, grammarAccess.getVariableAssignmentAccess().getTypeDataDeclCrossReference_2_0());
            				

            }


            }

            otherlv_3=(Token)match(input,21,FOLLOW_3); 

            			newLeafNode(otherlv_3, grammarAccess.getVariableAssignmentAccess().getLeftSquareBracketKeyword_3());
            		
            // InternalX21.g:1705:3: ( (otherlv_4= RULE_ID ) )
            // InternalX21.g:1706:4: (otherlv_4= RULE_ID )
            {
            // InternalX21.g:1706:4: (otherlv_4= RULE_ID )
            // InternalX21.g:1707:5: otherlv_4= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariableAssignmentRule());
            					}
            				
            otherlv_4=(Token)match(input,RULE_ID,FOLLOW_25); 

            					newLeafNode(otherlv_4, grammarAccess.getVariableAssignmentAccess().getAttrInternalParameterCrossReference_4_0());
            				

            }


            }

            otherlv_5=(Token)match(input,40,FOLLOW_10); 

            			newLeafNode(otherlv_5, grammarAccess.getVariableAssignmentAccess().getEqualsSignKeyword_5());
            		
            // InternalX21.g:1722:3: ( (lv_value_6_0= ruleExp ) )
            // InternalX21.g:1723:4: (lv_value_6_0= ruleExp )
            {
            // InternalX21.g:1723:4: (lv_value_6_0= ruleExp )
            // InternalX21.g:1724:5: lv_value_6_0= ruleExp
            {

            					newCompositeNode(grammarAccess.getVariableAssignmentAccess().getValueExpParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_27);
            lv_value_6_0=ruleExp();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVariableAssignmentRule());
            					}
            					add(
            						current,
            						"value",
            						lv_value_6_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Exp");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalX21.g:1741:3: (otherlv_7= ',' ( (otherlv_8= RULE_ID ) ) otherlv_9= '=' ( (lv_value_10_0= ruleExp ) ) )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( (LA16_0==24) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // InternalX21.g:1742:4: otherlv_7= ',' ( (otherlv_8= RULE_ID ) ) otherlv_9= '=' ( (lv_value_10_0= ruleExp ) )
            	    {
            	    otherlv_7=(Token)match(input,24,FOLLOW_3); 

            	    				newLeafNode(otherlv_7, grammarAccess.getVariableAssignmentAccess().getCommaKeyword_7_0());
            	    			
            	    // InternalX21.g:1746:4: ( (otherlv_8= RULE_ID ) )
            	    // InternalX21.g:1747:5: (otherlv_8= RULE_ID )
            	    {
            	    // InternalX21.g:1747:5: (otherlv_8= RULE_ID )
            	    // InternalX21.g:1748:6: otherlv_8= RULE_ID
            	    {

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getVariableAssignmentRule());
            	    						}
            	    					
            	    otherlv_8=(Token)match(input,RULE_ID,FOLLOW_25); 

            	    						newLeafNode(otherlv_8, grammarAccess.getVariableAssignmentAccess().getAttrInternalParameterCrossReference_7_1_0());
            	    					

            	    }


            	    }

            	    otherlv_9=(Token)match(input,40,FOLLOW_10); 

            	    				newLeafNode(otherlv_9, grammarAccess.getVariableAssignmentAccess().getEqualsSignKeyword_7_2());
            	    			
            	    // InternalX21.g:1763:4: ( (lv_value_10_0= ruleExp ) )
            	    // InternalX21.g:1764:5: (lv_value_10_0= ruleExp )
            	    {
            	    // InternalX21.g:1764:5: (lv_value_10_0= ruleExp )
            	    // InternalX21.g:1765:6: lv_value_10_0= ruleExp
            	    {

            	    						newCompositeNode(grammarAccess.getVariableAssignmentAccess().getValueExpParserRuleCall_7_3_0());
            	    					
            	    pushFollow(FOLLOW_27);
            	    lv_value_10_0=ruleExp();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getVariableAssignmentRule());
            	    						}
            	    						add(
            	    							current,
            	    							"value",
            	    							lv_value_10_0,
            	    							"dk.sdu.mmmi.olnor18.x21.X21.Exp");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);

            otherlv_11=(Token)match(input,22,FOLLOW_2); 

            			newLeafNode(otherlv_11, grammarAccess.getVariableAssignmentAccess().getRightSquareBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariableAssignment"


    // $ANTLR start "entryRuleVariableUse"
    // InternalX21.g:1791:1: entryRuleVariableUse returns [EObject current=null] : iv_ruleVariableUse= ruleVariableUse EOF ;
    public final EObject entryRuleVariableUse() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariableUse = null;


        try {
            // InternalX21.g:1791:52: (iv_ruleVariableUse= ruleVariableUse EOF )
            // InternalX21.g:1792:2: iv_ruleVariableUse= ruleVariableUse EOF
            {
             newCompositeNode(grammarAccess.getVariableUseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariableUse=ruleVariableUse();

            state._fsp--;

             current =iv_ruleVariableUse; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariableUse"


    // $ANTLR start "ruleVariableUse"
    // InternalX21.g:1798:1: ruleVariableUse returns [EObject current=null] : ( (otherlv_0= RULE_ID ) ) ;
    public final EObject ruleVariableUse() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;


        	enterRule();

        try {
            // InternalX21.g:1804:2: ( ( (otherlv_0= RULE_ID ) ) )
            // InternalX21.g:1805:2: ( (otherlv_0= RULE_ID ) )
            {
            // InternalX21.g:1805:2: ( (otherlv_0= RULE_ID ) )
            // InternalX21.g:1806:3: (otherlv_0= RULE_ID )
            {
            // InternalX21.g:1806:3: (otherlv_0= RULE_ID )
            // InternalX21.g:1807:4: otherlv_0= RULE_ID
            {

            				if (current==null) {
            					current = createModelElement(grammarAccess.getVariableUseRule());
            				}
            			
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            				newLeafNode(otherlv_0, grammarAccess.getVariableUseAccess().getRefDefinitionCrossReference_0());
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariableUse"


    // $ANTLR start "entryRuleDataTypeAttribute"
    // InternalX21.g:1821:1: entryRuleDataTypeAttribute returns [EObject current=null] : iv_ruleDataTypeAttribute= ruleDataTypeAttribute EOF ;
    public final EObject entryRuleDataTypeAttribute() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataTypeAttribute = null;


        try {
            // InternalX21.g:1821:58: (iv_ruleDataTypeAttribute= ruleDataTypeAttribute EOF )
            // InternalX21.g:1822:2: iv_ruleDataTypeAttribute= ruleDataTypeAttribute EOF
            {
             newCompositeNode(grammarAccess.getDataTypeAttributeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataTypeAttribute=ruleDataTypeAttribute();

            state._fsp--;

             current =iv_ruleDataTypeAttribute; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataTypeAttribute"


    // $ANTLR start "ruleDataTypeAttribute"
    // InternalX21.g:1828:1: ruleDataTypeAttribute returns [EObject current=null] : ( () ( (lv_source_1_0= ruleVariableUse ) ) otherlv_2= '.' ( (otherlv_3= RULE_ID ) ) ) ;
    public final EObject ruleDataTypeAttribute() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        Token otherlv_3=null;
        EObject lv_source_1_0 = null;



        	enterRule();

        try {
            // InternalX21.g:1834:2: ( ( () ( (lv_source_1_0= ruleVariableUse ) ) otherlv_2= '.' ( (otherlv_3= RULE_ID ) ) ) )
            // InternalX21.g:1835:2: ( () ( (lv_source_1_0= ruleVariableUse ) ) otherlv_2= '.' ( (otherlv_3= RULE_ID ) ) )
            {
            // InternalX21.g:1835:2: ( () ( (lv_source_1_0= ruleVariableUse ) ) otherlv_2= '.' ( (otherlv_3= RULE_ID ) ) )
            // InternalX21.g:1836:3: () ( (lv_source_1_0= ruleVariableUse ) ) otherlv_2= '.' ( (otherlv_3= RULE_ID ) )
            {
            // InternalX21.g:1836:3: ()
            // InternalX21.g:1837:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getDataTypeAttributeAccess().getDataTypeAttributeAction_0(),
            					current);
            			

            }

            // InternalX21.g:1843:3: ( (lv_source_1_0= ruleVariableUse ) )
            // InternalX21.g:1844:4: (lv_source_1_0= ruleVariableUse )
            {
            // InternalX21.g:1844:4: (lv_source_1_0= ruleVariableUse )
            // InternalX21.g:1845:5: lv_source_1_0= ruleVariableUse
            {

            					newCompositeNode(grammarAccess.getDataTypeAttributeAccess().getSourceVariableUseParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_28);
            lv_source_1_0=ruleVariableUse();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDataTypeAttributeRule());
            					}
            					set(
            						current,
            						"source",
            						lv_source_1_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.VariableUse");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,43,FOLLOW_3); 

            			newLeafNode(otherlv_2, grammarAccess.getDataTypeAttributeAccess().getFullStopKeyword_2());
            		
            // InternalX21.g:1866:3: ( (otherlv_3= RULE_ID ) )
            // InternalX21.g:1867:4: (otherlv_3= RULE_ID )
            {
            // InternalX21.g:1867:4: (otherlv_3= RULE_ID )
            // InternalX21.g:1868:5: otherlv_3= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDataTypeAttributeRule());
            					}
            				
            otherlv_3=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(otherlv_3, grammarAccess.getDataTypeAttributeAccess().getAttrInternalParameterCrossReference_3_0());
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataTypeAttribute"


    // $ANTLR start "entryRuleComparison"
    // InternalX21.g:1883:1: entryRuleComparison returns [String current=null] : iv_ruleComparison= ruleComparison EOF ;
    public final String entryRuleComparison() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleComparison = null;


        try {
            // InternalX21.g:1883:50: (iv_ruleComparison= ruleComparison EOF )
            // InternalX21.g:1884:2: iv_ruleComparison= ruleComparison EOF
            {
             newCompositeNode(grammarAccess.getComparisonRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleComparison=ruleComparison();

            state._fsp--;

             current =iv_ruleComparison.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComparison"


    // $ANTLR start "ruleComparison"
    // InternalX21.g:1890:1: ruleComparison returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= '=' | kw= '<' | kw= '>' | kw= '<=' | kw= '>=' ) ;
    public final AntlrDatatypeRuleToken ruleComparison() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalX21.g:1896:2: ( (kw= '=' | kw= '<' | kw= '>' | kw= '<=' | kw= '>=' ) )
            // InternalX21.g:1897:2: (kw= '=' | kw= '<' | kw= '>' | kw= '<=' | kw= '>=' )
            {
            // InternalX21.g:1897:2: (kw= '=' | kw= '<' | kw= '>' | kw= '<=' | kw= '>=' )
            int alt17=5;
            switch ( input.LA(1) ) {
            case 40:
                {
                alt17=1;
                }
                break;
            case 44:
                {
                alt17=2;
                }
                break;
            case 45:
                {
                alt17=3;
                }
                break;
            case 46:
                {
                alt17=4;
                }
                break;
            case 47:
                {
                alt17=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // InternalX21.g:1898:3: kw= '='
                    {
                    kw=(Token)match(input,40,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getComparisonAccess().getEqualsSignKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalX21.g:1904:3: kw= '<'
                    {
                    kw=(Token)match(input,44,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getComparisonAccess().getLessThanSignKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalX21.g:1910:3: kw= '>'
                    {
                    kw=(Token)match(input,45,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getComparisonAccess().getGreaterThanSignKeyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalX21.g:1916:3: kw= '<='
                    {
                    kw=(Token)match(input,46,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getComparisonAccess().getLessThanSignEqualsSignKeyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalX21.g:1922:3: kw= '>='
                    {
                    kw=(Token)match(input,47,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getComparisonAccess().getGreaterThanSignEqualsSignKeyword_4());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparison"


    // $ANTLR start "entryRuleLogicExp"
    // InternalX21.g:1931:1: entryRuleLogicExp returns [EObject current=null] : iv_ruleLogicExp= ruleLogicExp EOF ;
    public final EObject entryRuleLogicExp() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLogicExp = null;


        try {
            // InternalX21.g:1931:49: (iv_ruleLogicExp= ruleLogicExp EOF )
            // InternalX21.g:1932:2: iv_ruleLogicExp= ruleLogicExp EOF
            {
             newCompositeNode(grammarAccess.getLogicExpRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLogicExp=ruleLogicExp();

            state._fsp--;

             current =iv_ruleLogicExp; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLogicExp"


    // $ANTLR start "ruleLogicExp"
    // InternalX21.g:1938:1: ruleLogicExp returns [EObject current=null] : ( () ( (lv_left_1_0= ruleExp ) ) ( (lv_comp_2_0= ruleComparison ) ) ( (lv_right_3_0= ruleExp ) ) ) ;
    public final EObject ruleLogicExp() throws RecognitionException {
        EObject current = null;

        EObject lv_left_1_0 = null;

        AntlrDatatypeRuleToken lv_comp_2_0 = null;

        EObject lv_right_3_0 = null;



        	enterRule();

        try {
            // InternalX21.g:1944:2: ( ( () ( (lv_left_1_0= ruleExp ) ) ( (lv_comp_2_0= ruleComparison ) ) ( (lv_right_3_0= ruleExp ) ) ) )
            // InternalX21.g:1945:2: ( () ( (lv_left_1_0= ruleExp ) ) ( (lv_comp_2_0= ruleComparison ) ) ( (lv_right_3_0= ruleExp ) ) )
            {
            // InternalX21.g:1945:2: ( () ( (lv_left_1_0= ruleExp ) ) ( (lv_comp_2_0= ruleComparison ) ) ( (lv_right_3_0= ruleExp ) ) )
            // InternalX21.g:1946:3: () ( (lv_left_1_0= ruleExp ) ) ( (lv_comp_2_0= ruleComparison ) ) ( (lv_right_3_0= ruleExp ) )
            {
            // InternalX21.g:1946:3: ()
            // InternalX21.g:1947:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getLogicExpAccess().getLogicExpAction_0(),
            					current);
            			

            }

            // InternalX21.g:1953:3: ( (lv_left_1_0= ruleExp ) )
            // InternalX21.g:1954:4: (lv_left_1_0= ruleExp )
            {
            // InternalX21.g:1954:4: (lv_left_1_0= ruleExp )
            // InternalX21.g:1955:5: lv_left_1_0= ruleExp
            {

            					newCompositeNode(grammarAccess.getLogicExpAccess().getLeftExpParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_29);
            lv_left_1_0=ruleExp();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getLogicExpRule());
            					}
            					set(
            						current,
            						"left",
            						lv_left_1_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Exp");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalX21.g:1972:3: ( (lv_comp_2_0= ruleComparison ) )
            // InternalX21.g:1973:4: (lv_comp_2_0= ruleComparison )
            {
            // InternalX21.g:1973:4: (lv_comp_2_0= ruleComparison )
            // InternalX21.g:1974:5: lv_comp_2_0= ruleComparison
            {

            					newCompositeNode(grammarAccess.getLogicExpAccess().getCompComparisonParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_10);
            lv_comp_2_0=ruleComparison();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getLogicExpRule());
            					}
            					set(
            						current,
            						"comp",
            						lv_comp_2_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Comparison");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalX21.g:1991:3: ( (lv_right_3_0= ruleExp ) )
            // InternalX21.g:1992:4: (lv_right_3_0= ruleExp )
            {
            // InternalX21.g:1992:4: (lv_right_3_0= ruleExp )
            // InternalX21.g:1993:5: lv_right_3_0= ruleExp
            {

            					newCompositeNode(grammarAccess.getLogicExpAccess().getRightExpParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_right_3_0=ruleExp();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getLogicExpRule());
            					}
            					set(
            						current,
            						"right",
            						lv_right_3_0,
            						"dk.sdu.mmmi.olnor18.x21.X21.Exp");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicExp"

    // Delegated rules


    protected DFA15 dfa15 = new DFA15(this);
    static final String dfa_1s = "\12\uffff";
    static final String dfa_2s = "\3\uffff\1\10\6\uffff";
    static final String dfa_3s = "\1\4\2\uffff\1\20\6\uffff";
    static final String dfa_4s = "\1\52\2\uffff\1\57\6\uffff";
    static final String dfa_5s = "\1\uffff\1\1\1\2\1\uffff\1\4\1\5\1\6\1\7\1\3\1\10";
    static final String dfa_6s = "\12\uffff}>";
    static final String[] dfa_7s = {
            "\1\3\1\1\11\uffff\1\2\22\uffff\1\7\1\6\3\uffff\1\4\2\uffff\1\5",
            "",
            "",
            "\1\10\1\uffff\1\10\3\uffff\1\10\1\uffff\1\10\5\uffff\4\10\2\uffff\3\10\1\uffff\2\10\1\uffff\1\11\4\10",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final short[] dfa_2 = DFA.unpackEncodedString(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final char[] dfa_4 = DFA.unpackEncodedStringToUnsignedChars(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[] dfa_6 = DFA.unpackEncodedString(dfa_6s);
    static final short[][] dfa_7 = unpackEncodedStringArray(dfa_7s);

    class DFA15 extends DFA {

        public DFA15(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 15;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "1262:2: (this_Number_0= ruleNumber | this_Parenthesis_1= ruleParenthesis | this_VariableUse_2= ruleVariableUse | this_Let_3= ruleLet | this_VariableAssignment_4= ruleVariableAssignment | this_Ifstatement_5= ruleIfstatement | this_None_6= ruleNone | this_DataTypeAttribute_7= ruleDataTypeAttribute )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x000000000A185002L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000030000010L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000048C00008030L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000008010L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000004200010L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000001000002L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000001800000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000001800002L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000001040000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x00000000C0000002L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000300000002L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000001400000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000F10000000000L});

}