package p5;
import libx21.*;
import java.util.function.Function;
import java.util.List;
public class P5Main extends GenericMainX21 {
	//
	// Code for input teachers
	//
	private ComputeNode<DataTeacher,DataTeacher> node_teachers = new InputNode<DataTeacher>();
	public void inputTeachers(DataTeacher input) {
		node_teachers.put(input);
	}
	//
	// Code for parameter active_course
	//
	private DataCourse _active_course;
	public void setParameterActive_course(DataCourse value) {
		_active_course = value;
	}
	//
	// Code for node 2
	//
	private ComputeNode <DataTeacher,DataTeacher> node_2 = new AbstractComputeNode<DataTeacher,DataTeacher>() {
		protected DataTeacher function(DataTeacher input) {
			Function<DataTeacher,DataTeacher> f = (DataTeacher _t) -> { return (new DataTeacher().setName((_t.getName())).setAge(((_t.getAge())+(1))).setCourse_taught((_t.getCourse_taught()))); };
			return f.apply((DataTeacher)input);
		}
	};
	//
	// Code for node filter
	//
	private ComputeNode <DataTeacher,DataTeacher> node_filter = new AbstractComputeNode<DataTeacher,DataTeacher>() {
		protected DataTeacher function(DataTeacher input) {
			Function<DataTeacher,DataTeacher> f = (DataTeacher _t) -> { return ((_t.getCourse_taught()).equals((_active_course))?(_t):(null)); };
			return f.apply((DataTeacher)input);
		}
	};
	//
	// Code for node 3
	//
	private ComputeNode <DataTeacher,String> node_3 = new AbstractComputeNode<DataTeacher,String>() {
		protected String function(DataTeacher input) {
			Function<DataTeacher,String> f = (DataTeacher _t) -> { return (_t.getName()); };
			return f.apply((DataTeacher)input);
		}
	};
	//
	// Output nodes
	//
	private OutputNode<DataTeacher> node_processed_people = new OutputNode<DataTeacher>();
	public List<DataTeacher> getProcessed_people() { return node_processed_people.getData(); }
	private OutputNode<String> node_teacher_names = new OutputNode<String>();
	public List<String> getTeacher_names() { return node_teacher_names.getData(); }
	//
	// Helper methods (if any)
	//
	//
	// Initialization of specific nodes
	//
	protected void initializeNodes() {
		super.addNode(node_teachers);
		super.addNode(node_2);
		super.addNode(node_filter);
		super.addNode(node_3);
	}
	//
	// Initialize network as a whole
	//
	protected void initializeNetwork() {
		node_teachers.addOutputNode(node_2);
		// DataTeacher
		node_2.addOutputNode(node_filter);
		node_filter.addOutputNode(node_processed_people);
		node_teachers.addOutputNode(node_3);
		// String
		node_3.addOutputNode(node_teacher_names);
	}
}
