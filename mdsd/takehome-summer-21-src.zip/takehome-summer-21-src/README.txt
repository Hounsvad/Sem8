response-template.tex: template for your response, latex
response-template.docx: template for your reponse, word
ExamRuntime/library: generic classes for use by generated code
ExamRuntime/src: source of X20 programs
ExamRuntime/src/exam-test/test: source of test programs
ExamRuntime/src-gen: generated UNTYPED Java code for the X21 programs
ExamRuntime/src-gen-typed: same but TYPED (i.e., better)
