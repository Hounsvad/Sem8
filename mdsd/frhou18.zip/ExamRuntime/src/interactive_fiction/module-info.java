module interactive_fiction {
	requires org.junit.jupiter.api;
}